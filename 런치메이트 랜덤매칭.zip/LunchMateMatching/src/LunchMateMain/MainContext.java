package LunchMateMain;

import LunchMateUser.*;
import LunchMateParticipation.*;
import LunchMateMatch.*;
import LunchMateRestaurant.*;


// DAO 객체들의 중앙 관리소
// DAO 객체들을 한번에 생성해서 제공 코드일관성+유지보수성 확보

public final class MainContext {
	
    private static final UserDAO userDAO = new JDBCUserDAO();
    
    private static final ParticipationDAO participationDAO = new JDBCParticipationDAO();
    
    private static final MatchDAO matchDAO = new JDBCMatchDAO();
    
    private static final RestaurantDAO restaurantDAO = new JDBCRestaurantDAO();

    public static UserDAO userDAO()
    { return userDAO; }
    
    public static ParticipationDAO participationDAO()
    { return participationDAO; }
    
    public static MatchDAO matchDAO()
    { return matchDAO; }
    
    public static RestaurantDAO restaurantDAO()
    { return restaurantDAO; }

    private MainContext() {}
}