package LunchMateMain;

import javax.swing.SwingUtilities;
import LunchMateGui.WelcomeFrame;

//메인스타트 화면 ->welcomeframe으로 이동
public class MainStart {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new WelcomeFrame().setVisible(true));
    }
}