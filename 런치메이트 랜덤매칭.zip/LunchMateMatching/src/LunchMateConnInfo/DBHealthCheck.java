//package LunchMateConnInfo;
////import LunchMateConnInfo.ConnectionManager;
//import java.sql.*;
//
//public class DBHealthCheck {
//    public static void main(String[] args) {
//        String sql = "SELECT DATABASE() AS db, VERSION() AS ver";
//        try (Connection conn = ConnectionManager.getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql);
//             ResultSet rs = ps.executeQuery()) {
//            if (rs.next()) {
//                System.out.println("DB: " + rs.getString("db"));
//                System.out.println("Version: " + rs.getString("ver"));
//            }
//            System.out.println("MySQL 연결 성공");
//        } catch (Exception e) {
//            System.err.println("MySQL 연결 실패: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//}