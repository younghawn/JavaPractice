package LunchMateConnInfo;

public final class DBConfig {
    public static final String URL =
            "jdbc:mysql://localhost:3306/LunchDB"
            + "?serverTimezone=Asia/Seoul"
            + "&useSSL=false"
            + "&characterEncoding=utf8";
    
    public static final String USER = "root";
    public static final String PASSWORD = "3677";

    private DBConfig() {} // 인스턴스화 방지
}