package LunchMateGui;

import LunchMateUser.UserDAO;
import LunchMateUser.JDBCUserDAO;
import LunchMateUser.UserVO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

//로그인 패널
public class LoginFrame extends JFrame {
	
	    private static final long serialVersionUID = 1L;
		private final JTextField email = new JTextField(22);
	    private final JPasswordField pass = new JPasswordField(22);
	    private final char defaultEchoChar = pass.getEchoChar();
	    
	    public LoginFrame() {
        super("LunchMate - 로그인");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(520, 380);
        setLocationRelativeTo(null);
        setResizable(false);

        // 루트
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BG);
        setContentPane(root);

        // 헤더(그라디언트 바)
        JPanel header = new GradientBar("다시 만나도 즐거운, 점심메이트");
        header.setPreferredSize(new Dimension(520, 90));
        root.add(header, BorderLayout.NORTH);

        // 카드
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(22, 24, 20, 24));
        root.add(wrapCard(card), BorderLayout.CENTER);

        GridBagConstraints c = Theme.gbc();
        int row = 0;

        // 제목
        JLabel title = Theme.h1("로그인");
        c.gridx = 0; c.gridy = row++; c.gridwidth = 2; c.insets = new Insets(0,0,14,0);
        card.add(title, c);
        c.gridwidth = 1;

        // 이메일
        c.gridy = row; c.gridx = 0; c.insets = new Insets(6, 0, 6, 10);
        card.add(Theme.labelRight("이메일"), c);
        c.gridx = 1; c.insets = new Insets(6, 0, 6, 0);
        card.add(Theme.input(email), c);
        row++;

        // 비밀번호 + 보기 토글
        c.gridy = row; c.gridx = 0; c.insets = new Insets(6, 0, 6, 10);
        card.add(Theme.labelRight("비밀번호"), c);
        JPanel passRow = new JPanel(new BorderLayout());
        passRow.setOpaque(false);
        passRow.add(Theme.input(pass), BorderLayout.CENTER);
        
        JCheckBox show = new JCheckBox("표시");
        show.setOpaque(false);
        show.addItemListener(ev -> {
            boolean on = show.isSelected();
            pass.setEchoChar(on ? (char)0 : defaultEchoChar);
        });
        passRow.add(show, BorderLayout.EAST);
        c.gridx = 1; c.insets = new Insets(6, 0, 6, 0);
        card.add(passRow, c);
        row++;

        // 버튼들
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btns.setOpaque(false);
        JButton signupBtn = new RoundedButton("회원가입");
        signupBtn.addActionListener(e -> new SignUpFrame(this).setVisible(true));
        JButton loginBtn = new RoundedButtonPrimary("로그인");
        loginBtn.addActionListener(this::onLogin);
        btns.add(signupBtn);
        btns.add(loginBtn);

        c.gridy = row++; c.gridx = 0; c.gridwidth = 2; c.insets = new Insets(16, 0, 0, 0);
        card.add(btns, c);

        // 키보드 단축키
        getRootPane().setDefaultButton(loginBtn);
        getRootPane().registerKeyboardAction(e -> dispose(),
                KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    private void onLogin(ActionEvent e) {
        try {
            String em = email.getText().trim();
            String pw = new String(pass.getPassword()); // 해시 비교는 DAO 내부 authenticate에서 처리했다고 가정

            UserDAO dao = new JDBCUserDAO();
            UserVO u = ((JDBCUserDAO) dao).authenticate(em, pw);
            if (u == null) {
                JOptionPane.showMessageDialog(this, "이메일 또는 비밀번호가 올바르지 않습니다.");
                return;
            }
            dispose();
            new MainFrame(u).setVisible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "로그인 실패: " + ex.getMessage());
        }
    }

    //스타일 유틸
    static final class Theme {
        static final Color BRAND = new Color(255, 140, 66);
        static final Color BRAND_DK = new Color(230, 110, 40);
        static final Color BG = new Color(246, 247, 249);
        static Font h1Font(Component c) { return c.getFont().deriveFont(Font.BOLD, 22f); }
        static JLabel h1(String text) { JLabel l = new JLabel(text); l.setFont(h1Font(l)); l.setForeground(new Color(40,40,40)); return l; }
        static JLabel labelRight(String t){ JLabel l=new JLabel(t,SwingConstants.RIGHT); l.setPreferredSize(new Dimension(80, 26)); return l; }
        static JComponent input(JComponent comp){ comp.setPreferredSize(new Dimension(260, 34)); comp.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220,220,220)),
                BorderFactory.createEmptyBorder(6,8,6,8))); return comp; }
        
        static GridBagConstraints gbc(){ GridBagConstraints c = new GridBagConstraints(); c.fill = GridBagConstraints.HORIZONTAL; c.weightx=1; return c; }
    }
    
    static JPanel wrapCard(JPanel inner){
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setBackground(Theme.BG);
        inner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(0,0,0,0),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(235,235,235)),
                        BorderFactory.createEmptyBorder(18,18,18,18)
                )));
        wrap.add(inner, new GridBagConstraints());
        return wrap;
    }
    
    static class GradientBar extends JPanel{
        private static final long serialVersionUID = 1L;
		private final String text;
        GradientBar(String t){ this.text=t; setOpaque(false); }
        @Override protected void paintComponent(Graphics g){
            Graphics2D g2=(Graphics2D)g.create();
            int w=getWidth(),h=getHeight();
            g2.setPaint(new GradientPaint(0,0,new Color(255,154,84), w, h, new Color(255,209,148)));
            g2.fillRect(0,0,w,h);
            g2.setColor(new Color(255,255,255,220));
            g2.setFont(getFont().deriveFont(Font.BOLD,16f));
            g2.drawString(text, 16, h-18);
            g2.dispose();
        }
    }
    
    static class RoundedButton extends JButton{
        private static final long serialVersionUID = 1L;
		RoundedButton(String t){ super(t);
            setForeground(new Color(70,70,70));
            setBackground(new Color(245,245,245));
            setFocusPainted(false); setContentAreaFilled(false); setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(10,18,10,18));
        }
		
        @Override protected void paintComponent(Graphics g){
            Graphics2D g2=(Graphics2D)g.create();
            int w=getWidth(),h=getHeight();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0,0,w,h,14,14);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
    
    static class RoundedButtonPrimary extends RoundedButton{
        private static final long serialVersionUID = 1L;
		RoundedButtonPrimary(String t){ super(t); setForeground(Color.WHITE); setBackground(Theme.BRAND); }
        @Override protected void paintComponent(Graphics g){
            Graphics2D g2=(Graphics2D)g.create();
            int w=getWidth(),h=getHeight();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp=new GradientPaint(0,0,Theme.BRAND,0,h,Theme.BRAND_DK);
            g2.setPaint(gp); g2.fillRoundRect(0,0,w,h,14,14);
            super.paintComponent(g2); g2.dispose();
        }
    }
}