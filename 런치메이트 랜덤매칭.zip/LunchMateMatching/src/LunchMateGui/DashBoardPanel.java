package LunchMateGui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;


import LunchMateUser.UserVO;

//대쉬보드 패널
public class DashBoardPanel extends JPanel {

    private static final long serialVersionUID = 1L;
	// 메인테마 
    private static final Color BRAND_GRAD_1 = new Color(255, 154, 84);  
    private static final Color BRAND_GRAD_2 = new Color(255, 209, 148); 
    private static final Color BRAND        = new Color(255, 140, 66);

    private static final Color BG       = new Color(246, 247, 249);
    private static final Color SURFACE  = Color.WHITE;
    private static final Color TEXT     = new Color(40, 40, 40);
    private static final Color MUTED    = new Color(120, 120, 120);
    private static final Color LINE     = new Color(230, 232, 236);

    private static final Font  H2    = new Font("SansSerif", Font.BOLD, 16);
    private static final Font  BODY  = new Font("SansSerif", Font.PLAIN, 14);
    private static final Font  SMALL = new Font("SansSerif", Font.PLAIN, 12);

    private final UserVO currentUser;

    public DashBoardPanel(UserVO user) {
        this.currentUser = user;

        setLayout(new BorderLayout(0, 12));
        setBackground(BG);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        add(buildHeroBlock(), BorderLayout.NORTH);
        add(buildContentBlock(), BorderLayout.CENTER);
    }

    

    private JComponent buildHeroBlock() {
        JPanel wrap = new JPanel(new BorderLayout(0, 12));
        wrap.setOpaque(false);

        // 히어로 배너 
        wrap.add(new HeroPanel(currentUser), BorderLayout.CENTER);

        // 히어로 하단: 좌우 메트릭 2장
        JPanel metrics = new JPanel(new GridLayout(1, 2, 12, 12));
        metrics.setOpaque(false);
        metrics.add(metricCard("오늘 참여자", "128명"));
        metrics.add(metricCard("대기 중 매칭", "34건"));
        wrap.add(metrics, BorderLayout.SOUTH);

        return wrap;
    }

    
    private static class HeroPanel extends JPanel {
        private static final long serialVersionUID = 1L;
		private final String greet;
        private final String sub;

        HeroPanel(UserVO user) {
            setOpaque(false);
            setPreferredSize(new Dimension(0, 140));
            String name = (user != null && user.getName() != null && !user.getName().isBlank())
                    ? user.getName() : "점심메이트";
            greet = "안녕하세요, " + name + "님";
            sub   = "오늘도 새로운 점심 메이트를 만나보세요!";
        }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth(), h = getHeight();
            // 그라디언트 배경
            GradientPaint gp = new GradientPaint(0, 0, BRAND_GRAD_1, w, h, BRAND_GRAD_2);
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, w, h, 18, 18);

            // 좌측 텍스트
            g2.setColor(new Color(255,255,255,235));
            g2.setFont(new Font("SansSerif", Font.BOLD, 24));
            g2.drawString("🍱 점심 메이트", 18, 42);

            g2.setFont(new Font("SansSerif", Font.BOLD, 20));
            g2.drawString(greet, 18, 80);

            g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
            g2.drawString(sub, 18, 106);

            // 우측 장식 (빛방울)
            g2.setComposite(AlphaComposite.SrcOver.derive(0.12f));
            g2.setColor(Color.WHITE);
            for (int i = 0; i < 5; i++) {
                g2.fillOval(w - 50 - i*60, -20, 110, 110);
            }

            g2.dispose();
        }
    }

    private JPanel metricCard(String title, String value) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(SURFACE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(LINE),
                new EmptyBorder(12, 12, 12, 12)
        ));

        JLabel v = new JLabel(value, SwingConstants.CENTER);
        v.setFont(new Font("SansSerif", Font.BOLD, 24));
        v.setForeground(BRAND);

        JLabel t = new JLabel(title, SwingConstants.CENTER);
        t.setFont(SMALL);
        t.setForeground(MUTED);

        p.add(v, BorderLayout.CENTER);
        p.add(t, BorderLayout.SOUTH);
        return p;
    }

    //MAIN CONTENT(상단 2열 + 하단 팁)
    private JComponent buildContentBlock() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setOpaque(false);

        JPanel topRow = new JPanel(new GridLayout(1, 2, 12, 12));
        topRow.setOpaque(false);
        topRow.add(reviewsCard());      // 왼쪽: 사용후기 (별점 좌측)
        topRow.add(restaurantCard());   // 오른쪽: 추천 맛집

        root.add(topRow, BorderLayout.CENTER);
        root.add(tipsCard(), BorderLayout.SOUTH);
        return root;
    }

    //사용후기
    private JPanel reviewsCard() {
        JPanel card = cardShell("사용후기");

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));

        List<String[]> reviews = Arrays.asList(
                new String[]{"5", "신림 · 김*진", "양꼬치 좋아하는 분 만나서 재밌게 먹었어요!"},
                new String[]{"4", "역삼 · 이*우", "회사 근처 숨은 돈가스 맛집 알게 됨 👍"},
                new String[]{"5", "송파 · 박*영", "3인 매칭으로 새로운 팀도 만들었어요 :)"}
        );
        for (String[] r : reviews) {
            list.add(reviewRow(r[0], r[1], r[2]));
            list.add(Box.createVerticalStrut(8));
        }

        JScrollPane sp = new JScrollPane(list);
        sp.setBorder(null);
        card.add(sp, BorderLayout.CENTER);
        return card;
    }

    private JPanel reviewRow(String starCount, String meta, String body) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setBackground(new Color(250, 250, 252));
        row.setBorder(new EmptyBorder(10, 12, 10, 12));

        // 왼쪽: 별점 (아이콘 스타일)
        JLabel stars = new JLabel(renderStars(Integer.parseInt(starCount)));
        stars.setFont(new Font("SansSerif", Font.PLAIN, 16));
        stars.setForeground(new Color(255, 190, 0));

        // 오른쪽: 메타 + 본문
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));

        JLabel metaL = new JLabel(meta);
        metaL.setForeground(MUTED);
        metaL.setFont(SMALL);

        JLabel bodyL = new JLabel(body);
        bodyL.setFont(BODY);

        text.add(metaL);
        text.add(Box.createVerticalStrut(2));
        text.add(bodyL);

        row.add(stars, BorderLayout.WEST);
        row.add(text, BorderLayout.CENTER);
        return row;
    }

    private String renderStars(int n) {
        n = Math.max(0, Math.min(5, n));
        String filled = "★".repeat(n);
        String empty  = "☆".repeat(5 - n);
        return filled + empty;
    }

    //추천맛집
    private JPanel restaurantCard() {
        JPanel card = cardShell("오늘의 추천 맛집");

        String[] cols = {"메뉴", "가게명", "지역"};
        Object[][] rows = {
                {"국밥",   "진국식당", "마포"},
                {"돈가스", "겐쇼쿠",   "역삼"},
                {"샐러드", "그린볼",   "송파"},
                {"햄버거",   "제스티살룬", "연남"},
                {"회", "속초어시장",   "강남"},
                {"양꼬치", "명봉양꼬치",   "건대입구"}
        };

        JTable table = new JTable(new DefaultTableModel(rows, cols) {
            private static final long serialVersionUID = 1L;

			@Override public boolean isCellEditable(int r, int c) { return false; }
        });
        table.setRowHeight(26);
        table.setFont(BODY);
        table.getTableHeader().setFont(SMALL);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new EmptyBorder(8, 8, 8, 8));

        card.add(sp, BorderLayout.CENTER);
        return card;
    }

    //오늘의 점심꿀팁
    private JPanel tipsCard() {
        JPanel card = cardShell("오늘의 점심 꿀팁");
        JTextArea tips = new JTextArea(String.format("""
                • 매칭 잘 되는 시간: 11:30~12:00
                • 인기 메뉴: 제육볶음 / 돈가스 / 순두부
                • %s 기준 예약 많은 지역: 역삼·을지로·합정
                • 첫 만남은 '요즘 꽂힌 메뉴'로 시작!
                """, LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM월 dd일"))));
        tips.setEditable(false);
        tips.setLineWrap(true);
        tips.setWrapStyleWord(true);
        tips.setFont(BODY);
        tips.setBackground(SURFACE);
        tips.setBorder(new EmptyBorder(8, 8, 8, 8));
        card.add(tips, BorderLayout.CENTER);
        return card;
    }

    //공통 카드쉘
    private JPanel cardShell(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(SURFACE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(LINE),
                new EmptyBorder(8, 8, 8, 8)
        ));
        JLabel t = new JLabel(title);
        t.setFont(H2);
        t.setForeground(TEXT);
        t.setBorder(new EmptyBorder(2, 4, 8, 4));
        panel.add(t, BorderLayout.NORTH);
        return panel;
    }
}