package LunchMateGui;

import LunchMateUser.UserDAO;
import LunchMateUser.JDBCUserDAO;
import LunchMateUser.UserVO;
import LunchMateDB.PasswordUtil;
import LunchMateCommon.MapPickerDialog;
import LunchMateConnInfo.ConnectionManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;

public class UserProfileFrame extends JDialog {

    private static final long serialVersionUID = 1L;
	//  UI 필드들
    private final JTextField nameField    = new JTextField(22);
    private final JTextField emailField   = new JTextField(22);
    private final JPasswordField pwField  = new JPasswordField(22); // 비우면 미변경
    private final JComboBox<String> genderBox =
            new JComboBox<>(new String[]{"MALE","FEMALE","OTHER"});
    private final JTextField latField     = new JTextField(10);
    private final JTextField lngField     = new JTextField(10);

    private final JButton btnSave   = new JButton("저장");
    private final JButton btnCancel = new JButton("닫기");
    private final JButton btnMap    = new JButton("지도에서 선택");
    private final JButton btnDelete = new JButton("회원 정보 삭제"); 

    //  상태 
    private final int userId;             // 현재 수정 중인 사용자 PK
    private UserVO current;               // DB에서 불러온 최신 스냅샷
    private final UserDAO userDAO = new JDBCUserDAO();

    // 기본 테마(간단)
    private static final Color BG = new Color(246,247,249);
    private static final Color SURFACE = Color.WHITE;

    //  생성자
    public UserProfileFrame(Frame owner, int userId) {
        super(owner, "프로필 설정", true);
        this.userId = userId;

        setSize(560, 480);
        setLocationRelativeTo(owner);
        setResizable(false);

        setContentPane(buildUI());
        wireActions();

        // 열리자마자 DB에서 최신 값 로드
        SwingUtilities.invokeLater(this::loadFromDB);
    }

    // MainFrame에서 UserVO를 들고 있다면 이 생성자가 편함 
    public UserProfileFrame(Frame owner, UserVO user) {
        this(owner, user.getId() == null ? -1 : user.getId());
    }

    // UI 구성 
    private JPanel buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(255, 238, 224));
        header.setBorder(new EmptyBorder(12,16,12,16));
        JLabel title = new JLabel("🙂 프로필설정");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        header.add(title, BorderLayout.WEST);
        root.add(header, BorderLayout.NORTH);

        // Form
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(SURFACE);
        form.setBorder(new EmptyBorder(16,16,16,16));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8,8,8,8);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;

        int row = 0;

        // 이름
        addRow(form, c, row++, "이름", nameField);

        // 이메일 (수정 가능)
        addRow(form, c, row++, "이메일", emailField);

        // 비밀번호 + 보기 토글
        JPanel pwRow = new JPanel(new BorderLayout());
        pwRow.setOpaque(false);
        pwField.setToolTipText("비워두면 비밀번호는 변경하지 않습니다.");
        pwRow.add(pwField, BorderLayout.CENTER);
        JCheckBox show = new JCheckBox("표시");
        show.setOpaque(false);
        char defaultEcho = pwField.getEchoChar();
        show.addItemListener(ev ->
                pwField.setEchoChar(ev.getStateChange() == ItemEvent.SELECTED ? (char)0 : defaultEcho));
        pwRow.add(show, BorderLayout.EAST);
        addRow(form, c, row++, "비밀번호", pwRow);

        // 성별
        genderBox.setPreferredSize(new Dimension(160, 30));
        addRow(form, c, row++, "성별", genderBox);

        // 좌표 + 지도 버튼
        JPanel coord = new JPanel(new GridBagLayout());
        GridBagConstraints cg = new GridBagConstraints();
        cg.gridy = 0;
        cg.insets = new Insets(0, 0, 0, 8);
        cg.anchor = GridBagConstraints.WEST;

        Dimension fieldSz = new Dimension(140, 30);

        latField.setToolTipText("예: 37.5665");
        latField.setColumns(14);
        latField.setPreferredSize(fieldSz);
        latField.setMinimumSize(fieldSz);

        lngField.setToolTipText("예: 126.9780");
        lngField.setColumns(14);
        lngField.setPreferredSize(fieldSz);
        lngField.setMinimumSize(fieldSz);

        cg.gridx = 0; cg.weightx = 0; cg.fill = GridBagConstraints.NONE;
        coord.add(new JLabel("위도"), cg);
        cg.gridx = 1; cg.weightx = 0.5; cg.fill = GridBagConstraints.HORIZONTAL;
        coord.add(latField, cg);
        cg.gridx = 2; cg.weightx = 0; cg.fill = GridBagConstraints.NONE;
        coord.add(new JLabel("경도"), cg);
        cg.gridx = 3; cg.weightx = 0.5; cg.fill = GridBagConstraints.HORIZONTAL;
        coord.add(lngField, cg);
        cg.gridx = 4; cg.weightx = 0; cg.insets = new Insets(0, 8, 0, 0);
        cg.fill = GridBagConstraints.NONE;
        btnMap.setPreferredSize(new Dimension(130, 30));
        coord.add(btnMap, cg);

        addRow(form, c, row++, "위치", coord);

        JLabel hint = new JLabel("※ 지도 버튼으로 좌표를 쉽게 선택할 수 있습니다.");
        hint.setForeground(new Color(110,110,110));
        c.gridx=0; c.gridy=row++; c.gridwidth=2; form.add(hint, c);
        c.gridwidth=1;

        // Footer buttons
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        footer.setBackground(SURFACE);
        footer.setBorder(new EmptyBorder(12,16,12,16));

        // 삭제 버튼(폰트 검정)
        btnDelete.setForeground(Color.BLACK);
        footer.add(btnDelete);

        footer.add(btnCancel);
        footer.add(btnSave);

        root.add(form, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        return root;
    }

    private void addRow(JPanel form, GridBagConstraints c, int row, String label, JComponent comp) {
        c.gridx=0; c.gridy=row; c.weightx=0; c.fill=GridBagConstraints.NONE; c.anchor = GridBagConstraints.EAST;
        JLabel l = new JLabel(label);
        l.setPreferredSize(new Dimension(90, 26));
        form.add(l, c);
        c.gridx=1; c.weightx=1; c.fill=GridBagConstraints.HORIZONTAL; c.anchor = GridBagConstraints.WEST;
        form.add(comp, c);
    }

    private void wireActions() {
        btnCancel.addActionListener(e -> dispose());

        btnMap.addActionListener(e -> {
            String kakaoJsKey = System.getenv("KAKAO_JS_KEY");
            if (kakaoJsKey == null || kakaoJsKey.isBlank()) {
                kakaoJsKey = System.getProperty("KAKAO_JS_KEY");
            }
            Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
            MapPickerDialog dlg = new MapPickerDialog(owner, kakaoJsKey);
            dlg.setVisible(true);
            Double lat = dlg.getLatitude();
            Double lng = dlg.getLongitude();
            if (lat != null && lng != null) {
                latField.setText(String.valueOf(lat));
                lngField.setText(String.valueOf(lng));
            }
        });

        btnSave.addActionListener(e -> saveToDB());

        // 안전 삭제 (matches/participations → users) + 삭제 후 로그인 화면 이동
        btnDelete.addActionListener(e -> {
            if (current == null || current.getId() == null) {
                JOptionPane.showMessageDialog(this, "삭제할 사용자 정보를 먼저 불러오세요.");
                return;
            }
            int ok = JOptionPane.showConfirmDialog(
                    this,
                    "정말 이 회원을 삭제할까요?\n(관련 매칭/신청 기록도 함께 삭제됩니다.)",
                    "회원 삭제 확인",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );
            if (ok != JOptionPane.OK_OPTION) return;

            try {
                int rows = userDAO.delete(current.getId());
                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "회원 정보가 삭제되었습니다.");
                    //로그인 화면으로 이동
                    goToLoginScreen();
                } else {
                    JOptionPane.showMessageDialog(this, "삭제 대상이 없거나 이미 삭제되었습니다.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        "삭제 실패: " + ex.getMessage(),
                        "오류", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // DB 읽기/쓰기 
    private void loadFromDB() {
        try {
            current = userDAO.findById(userId);
            if (current == null) {
                JOptionPane.showMessageDialog(this, "사용자를 찾을 수 없습니다. (id=" + userId + ")");
                return;
            }
            nameField.setText(nvl(current.getName()));
            emailField.setText(nvl(current.getEmail()));
            pwField.setText(""); // 비밀번호는 비워둠 (입력 시 변경)
            genderBox.setSelectedItem(nvl(current.getGender(), "OTHER"));
            latField.setText(current.getLatitude() == null ? "" : String.valueOf(current.getLatitude()));
            lngField.setText(current.getLongitude() == null ? "" : String.valueOf(current.getLongitude()));
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "프로필 불러오기 실패: " + ex.getMessage());
        }
    }

    private void saveToDB() {
        try {
            if (current == null) {
                JOptionPane.showMessageDialog(this, "먼저 프로필을 불러오세요.");
                return;
            }

            String newName  = nameField.getText().trim();
            String newEmail = emailField.getText().trim();
            String newPw    = new String(pwField.getPassword()).trim();
            String newGender= (String) genderBox.getSelectedItem();
            Double lat = parseDoubleOrNull(latField.getText().trim());
            Double lng = parseDoubleOrNull(lngField.getText().trim());

            if (newName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "이름을 입력하세요.");
                return;
            }
            if (newEmail.isEmpty()) {
                JOptionPane.showMessageDialog(this, "이메일을 입력하세요.");
                return;
            }

            // 이메일 변경이 있으면 선반영 (UNIQUE 충돌 검사 목적)
            if (!newEmail.equalsIgnoreCase(nvl(current.getEmail()))) {
                try (Connection conn = ConnectionManager.getConnection();
                     PreparedStatement ps = conn.prepareStatement(
                             "UPDATE users SET email=? WHERE id=?")) {
                    ps.setString(1, newEmail);
                    ps.setInt(2, current.getId());
                    int upd = ps.executeUpdate();
                    if (upd <= 0) throw new RuntimeException("이메일 업데이트 실패");
                    current.setEmail(newEmail); // 로컬 스냅샷 반영
                } catch (SQLIntegrityConstraintViolationException dup) {
                    JOptionPane.showMessageDialog(this, "이미 사용 중인 이메일입니다.");
                    return;
                }
            }

            // 나머지 필드 업데이트
            UserVO toSave = new UserVO();
            toSave.setId(current.getId());
            toSave.setName(newName);
            toSave.setGender(newGender);
            toSave.setLatitude(lat);
            toSave.setLongitude(lng);

            if (newPw.isEmpty()) {
                toSave.setPasswordHash(current.getPasswordHash());
            } else {
                toSave.setPasswordHash(PasswordUtil.sha256(newPw));
            }

            int rows = userDAO.update(toSave);
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "저장되었습니다.");
                current = userDAO.findById(current.getId());
                pwField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "변경된 내용이 없습니다.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "저장 실패: " + ex.getMessage());
        }
    }
    
    private void goToLoginScreen() {
        //현재 다이얼로그 닫기
        dispose();

        //소유자(메인 프레임)도 닫기
        Window owner = SwingUtilities.getWindowAncestor(this);
        if (owner != null) owner.dispose();

        //세션/컨텍스트가 있다면 현재 유저 비우기
        try {
            Class<?> ctxCls = Class.forName("LunchMateGui.MainContext");
            Object ctx = ctxCls.getMethod("getInstance").invoke(null);
            ctxCls.getMethod("setCurrentUser", Class.forName("LunchMateUser.UserVO")).invoke(ctx, new Object[]{null});
        } catch (Throwable ignore) { /* 없으면 패스 */ }

        //로그인 화면 띄우기
        SwingUtilities.invokeLater(() -> {
            try {
            	// 프로젝트에 있는 로그인/웰컴 프레임
            	JFrame login = new LoginFrame(); 
                login.setLocationRelativeTo(null);
                login.setVisible(true);
            } catch (Throwable t) {
                t.printStackTrace();
            }
        });
    }

    //유틸 
    private static String nvl(String s) { return s == null ? "" : s; }
    private static String nvl(String s, String d) { return s == null ? d : s; }

    private static Double parseDoubleOrNull(String s) {
        if (s == null || s.isBlank()) return null;
        try { return Double.valueOf(s); } catch (Exception e) { return null; }
    }
}