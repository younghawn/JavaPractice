package LunchMateGui;

import LunchMateParticipation.ParticipationDAO;
import LunchMateParticipation.JDBCParticipationDAO;
import LunchMateParticipation.ParticipationVO;
import LunchMateUser.UserVO;

// 매칭 즉시(1분 지연) 실행을 위해 필요
import LunchMateMatch.MatchingService;
import LunchMateNotification.JDBCEmailNotificationDAO;
import LunchMateMatch.JDBCMatchDAO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
// 1분 지연 실행용
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

//  참가 신청 패널 
//  지역 선택 없이 UserVO의 위도/경도 사용
//  위치 변경은 프로필 설정에서 안내
//  신청 -> participations 저장
//  (옵션) 이 패널 내부에서 1분 뒤 매칭 한 번 시도

public class ParticipationPanel extends JPanel {
	
    private static final long serialVersionUID = 1L;

    // 지리 기준(로컬 1회 매칭용) — 필요 시 숫자만 조정
    private static final double DEFAULT_CENTER_LAT = 37.5705;
    private static final double DEFAULT_CENTER_LNG = 126.9832;
    // 반경(킬로미터)
    private static final double DEFAULT_RADIUS_KM  = 3.0;

    // 1분 지연 실행기(패널 전용, 데몬)
    private static final ScheduledExecutorService LOCAL_DELAY =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "panel-match-delay");
                t.setDaemon(true);
                return t;
            });

    //테마
    private static final Color BRAND      = new Color(255, 140, 66);
    private static final Color BRAND_DK   = new Color(230, 110, 40);
    private static final Color CTA        = new Color(255, 120, 0);
    private static final Color BG         = new Color(246, 247, 249);
    private static final Color SURFACE    = Color.WHITE;
    private static final Color TEXT       = new Color(40, 40, 40);
    private static final Color MUTED      = new Color(120, 120, 120);
    private static final Color LINE       = new Color(230, 232, 236);

    private static final Font  H2   = new Font("SansSerif", Font.BOLD, 16);
    private static final Font  BODY = new Font("SansSerif", Font.PLAIN, 14);
    private static final Font  SMALL= new Font("SansSerif", Font.PLAIN, 12);

    // 모델/DAO
    private final UserVO currentUser;
    private final ParticipationDAO dao = new JDBCParticipationDAO();

    // 폼 위젯 
    private final JSpinner spDate = new JSpinner(new SpinnerDateModel());
    private final JComboBox<String> cbSlot = new JComboBox<>(new String[]{
            "11:00-11:30","11:30-12:00","12:00-12:30",
            "12:30-13:00","13:00-13:30","13:30-14:00"
    });
    // 좌표 표시(읽기 전용)
    private final JTextField latField = new JTextField();
    private final JTextField lngField = new JTextField();

    // 테이블
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID","날짜","시간","지역(또는 좌표)","신청시각"}, 0) {
        private static final long serialVersionUID = 1L;
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(tableModel);

    public ParticipationPanel(UserVO user) {
        this.currentUser = user;

        setOpaque(true);
        setBackground(BG);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(16,16,16,16));

        add(buildHero(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);

        initFormDefaults();
        reloadMyParticipations();
    }

    // UI
    private JComponent buildHero() {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);

        JPanel hero = new JPanel() {
            private static final long serialVersionUID = 1L;
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                int w = getWidth(), h = getHeight();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(255,154,84), w, h, new Color(255,209,148));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, w, h, 18, 18);

                g2.setColor(new Color(255,255,255,235));
                g2.setFont(new Font("SansSerif", Font.BOLD, 18));
                g2.drawString("🗓 점심 매칭 신청", 16, 34);

                String name = (currentUser != null && currentUser.getName()!=null && !currentUser.getName().isBlank())
                        ? currentUser.getName() : "점심메이트";
                g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
                g2.drawString("안녕하세요, " + name + "님! 날짜와 시간만 고르면 신청됩니다.", 16, 58);

                g2.setComposite(AlphaComposite.SrcOver.derive(0.14f));
                g2.setColor(Color.white);
                for (int i = 0; i < 6; i++) g2.fillOval(w - 60 - i*60, -20, 110, 110);
                g2.dispose();
            }
        };
        hero.setOpaque(false);
        hero.setPreferredSize(new Dimension(0, 80));

        wrap.add(hero, BorderLayout.CENTER);
        wrap.setBorder(new EmptyBorder(0,0,12,0));
        return wrap;
    }

    private JComponent buildBody() {
        JPanel body = new JPanel(new GridBagLayout());
        body.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(0, 0, 0, 12);
        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1.0;

        // ===== 좌측: 신청 폼 카드 =====
        JPanel formCard = card();
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints fc = new GridBagConstraints();
        fc.insets = new Insets(8, 8, 8, 8);
        fc.fill = GridBagConstraints.HORIZONTAL;
        fc.weightx = 1;

        JLabel lbDate = label("날짜");
        spDate.setEditor(new JSpinner.DateEditor(spDate, "yyyy-MM-dd"));
        styleInput(spDate);

        JLabel lbSlot = label("시간 슬롯");
        styleInput(cbSlot);

        JLabel lbCoord = label("위치 (위도/경도)");
        latField.setEditable(false);
        lngField.setEditable(false);
        latField.setFont(BODY);
        lngField.setFont(BODY);

        Dimension coordSize = new Dimension(320, 36);
        latField.setPreferredSize(coordSize);
        lngField.setPreferredSize(coordSize);
        latField.setMinimumSize(coordSize);
        lngField.setMinimumSize(coordSize);

        latField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230,233,238),1,true),
                new EmptyBorder(6,8,6,8)
        ));
        lngField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230,233,238),1,true),
                new EmptyBorder(6,8,6,8)
        ));

        JPanel coord = new JPanel(new GridBagLayout());
        coord.setOpaque(false);
        GridBagConstraints cg = new GridBagConstraints();
        cg.insets = new Insets(0,0,6,8);
        cg.anchor = GridBagConstraints.WEST;
        cg.fill = GridBagConstraints.HORIZONTAL;
        cg.weightx = 1;

        cg.gridx = 0; cg.gridy = 0;
        coord.add(new JLabel("위도"), cg);
        cg.gridx = 1;
        coord.add(latField, cg);

        cg.gridx = 0; cg.gridy = 1;
        coord.add(new JLabel("경도"), cg);
        cg.gridx = 1;
        coord.add(lngField, cg);

        JLabel guide = new JLabel(
                "<html><span style='color:#777;'>현재 저장된 위치가 사용됩니다.<br>" +
                "위를 변경하려면 <b>프로필 설정</b>에서 좌표를 수정해 주세요.</span></html>");
        guide.setFont(SMALL);

        JButton btnApply = primary("✅ 참여 신청");
        btnApply.setBackground(CTA);
        btnApply.setOpaque(true);
        btnApply.setContentAreaFilled(true);
        btnApply.setPreferredSize(new Dimension(160, 42));
        btnApply.addActionListener(e -> onApply());

        int y = 0;
        addFormRow(formCard, fc, y++, lbDate, spDate);
        addFormRow(formCard, fc, y++, lbSlot, cbSlot);
        addFormRow(formCard, fc, y++, lbCoord, coord);

        fc.gridx = 0; fc.gridy = y++; fc.gridwidth = 2;
        formCard.add(guide, fc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        btnRow.setOpaque(false);
        btnRow.add(btnApply);
        fc.gridx = 0; fc.gridy = y; fc.gridwidth = 2;
        formCard.add(btnRow, fc);

        //우측: 내 신청 내역 카드
        JPanel tableCard = card();
        tableCard.setLayout(new BorderLayout());

        JLabel th = new JLabel("내 신청 내역");
        th.setFont(H2);
        th.setBorder(new EmptyBorder(10,12,6,12));

        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.setRowHeight(28);
        table.setFont(BODY);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        table.setFillsViewportHeight(true);
        table.setShowGrid(true);
        table.setGridColor(new Color(240, 242, 246));
        table.getColumnModel().getColumn(0).setPreferredWidth(56);
        table.getColumnModel().getColumn(1).setPreferredWidth(110);
        table.getColumnModel().getColumn(2).setPreferredWidth(120);
        table.getColumnModel().getColumn(3).setPreferredWidth(260);
        table.getColumnModel().getColumn(4).setPreferredWidth(180);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new EmptyBorder(0,12,12,12));
        sp.setMinimumSize(new Dimension(760, 380));
        sp.setPreferredSize(new Dimension(820, 440));
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        JPanel tableTop = new JPanel(new BorderLayout());
        tableTop.setOpaque(false);
        JButton btnDelete = secondary("선택 삭제");
        btnDelete.addActionListener(e -> onDeleteSelected());
        tableTop.add(th, BorderLayout.WEST);
        tableTop.add(btnDelete, BorderLayout.EAST);

        tableCard.add(tableTop, BorderLayout.NORTH);
        tableCard.add(sp, BorderLayout.CENTER);

        c.gridx = 0; c.gridy = 0; c.weightx = 0.45;
        body.add(formCard, c);

        c.gridx = 1; c.gridy = 0; c.weightx = 0.55; c.insets = new Insets(0,0,0,0);
        body.add(tableCard, c);

        return body;
    }

    private void addFormRow(JPanel form, GridBagConstraints fc, int row, JComponent label, JComponent comp) {
        fc.gridx = 0; fc.gridy = row; fc.gridwidth = 1; fc.weightx = 0; fc.fill = GridBagConstraints.NONE;
        form.add(label, fc);
        fc.gridx = 1; fc.gridy = row; fc.gridwidth = 1; fc.weightx = 1; fc.fill = GridBagConstraints.HORIZONTAL;
        form.add(comp, fc);
    }

    //로직
    private void initFormDefaults() {
        spDate.setValue(new Date());

        LocalTime now = LocalTime.now();
        String pick;
        if (now.isBefore(LocalTime.of(11,15))) pick = "11:00-11:30";
        else if (now.isBefore(LocalTime.of(11,45))) pick = "11:30-12:00";
        else if (now.isBefore(LocalTime.of(12,15))) pick = "12:00-12:30";
        else if (now.isBefore(LocalTime.of(12,45))) pick = "12:30-13:00";
        else if (now.isBefore(LocalTime.of(13,15))) pick = "13:00-13:30";
        else pick = "13:30-14:00";
        cbSlot.setSelectedItem(pick);

        if (currentUser != null) {
            latField.setText(currentUser.getLatitude()  != null ? String.valueOf(currentUser.getLatitude())  : "미설정");
            lngField.setText(currentUser.getLongitude() != null ? String.valueOf(currentUser.getLongitude()) : "미설정");
        } else {
            latField.setText("미설정");
            lngField.setText("미설정");
        }
        latField.setToolTipText("예: 37.5665");
        lngField.setToolTipText("예: 126.9780");
    }

    private void onApply() {
        if (currentUser == null || currentUser.getId() == null) {
            JOptionPane.showMessageDialog(this, "로그인 정보가 없습니다.", "오류", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (currentUser.getLatitude() == null || currentUser.getLongitude() == null) {
            JOptionPane.showMessageDialog(this, "프로필에 위치(위도/경도)를 먼저 저장해주세요.", "확인", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate date = ((Date) spDate.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        String slot   = String.valueOf(cbSlot.getSelectedItem());

        //과거 날짜/과거 슬롯 방지 (미래 날짜는 허용)
        LocalDate today = LocalDate.now();
        if (date.isBefore(today)) {
            JOptionPane.showMessageDialog(this, "지난 날짜는 신청할 수 없습니다.", "확인", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (date.equals(today)) {
            LocalTime now = LocalTime.now();
            LocalTime end = LocalTime.parse(slot.split("-")[1]);
            if (now.isAfter(end)) {
                JOptionPane.showMessageDialog(this, "이미 종료된 시간대입니다. 현재 이후의 슬롯을 선택해주세요.", "확인", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        String regionStr = String.format("lat:%.6f, lng:%.6f",
                currentUser.getLatitude(), currentUser.getLongitude());

        ParticipationVO vo = new ParticipationVO(currentUser.getId(), date, slot, regionStr);
        try {
            int n = dao.insert(vo);
            if (n > 0) {
                JOptionPane.showMessageDialog(this, "신청 완료! (1분 내 매칭 시도)");

             
                LOCAL_DELAY.schedule(() -> {
                    try {
                        MatchingService svc = new MatchingService(dao, new JDBCMatchDAO());
                        var made = svc.run(date, slot, DEFAULT_CENTER_LAT, DEFAULT_CENTER_LNG, DEFAULT_RADIUS_KM);
                        System.out.printf("[Panel] delayed matching tried for %s %s -> created=%d%n", date, slot, made.size());

                        // 매칭이 생성됐으면 이메일 발송 + 이력 저장
                        if (!made.isEmpty()) {
                            var emailDao = new JDBCEmailNotificationDAO(); // 
                            var mailSvc  = new LunchMateNotification.EmailService(emailDao);
                            for (var m : made) {
                                try {
                                    mailSvc.sendMatchEmails(m.getId());
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }, 1, TimeUnit.MINUTES);
                

                reloadMyParticipations();
            } else {
                JOptionPane.showMessageDialog(this, "신청에 실패했습니다.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "신청 처리 중 오류: " + ex.getMessage(),
                    "오류", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void onDeleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "삭제할 행을 선택해주세요.");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        int ok = JOptionPane.showConfirmDialog(this, "정말 삭제할까요?", "확인", JOptionPane.OK_CANCEL_OPTION);
        if (ok != JOptionPane.OK_OPTION) return;

        try {
            dao.deleteById(id);
            reloadMyParticipations();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "삭제 실패: " + ex.getMessage(), "오류", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void reloadMyParticipations() {
        tableModel.setRowCount(0);
        if (currentUser == null || currentUser.getId() == null) return;

        try {
            List<ParticipationVO> list = dao.findByUser(currentUser.getId());
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            DateTimeFormatter tf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            for (ParticipationVO p : list) {
                String date = (p.getParticipationDate() != null) ? p.getParticipationDate().format(df) : "";
                String slot = p.getTimeSlot();
                String region = p.getRegion();
                String ts = (p.getParticipatedAt()!=null) ? p.getParticipatedAt().format(tf) : "";
                tableModel.addRow(new Object[]{ p.getId(), date, slot, region, ts });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "목록 불러오기 오류: " + ex.getMessage(), "오류", JOptionPane.ERROR_MESSAGE);
        }
    }

    //유틸

    private JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(SURFACE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(LINE),
                new EmptyBorder(14,16,14,16)
        ));
        return p;
    }

    private JLabel label(String s) {
        JLabel l = new JLabel(s);
        l.setFont(SMALL);
        l.setForeground(MUTED);
        return l;
    }

    private void styleInput(JComponent c) {
        c.setFont(BODY);
        c.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 233, 238), 1, true),
                new EmptyBorder(6, 8, 6, 8)
        ));
        c.setPreferredSize(new Dimension(260, 36));
    }

    private JButton primary(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("SansSerif", Font.BOLD, 15));
        b.setForeground(Color.WHITE);
        b.setBackground(BRAND);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(10,16,10,16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.addChangeListener(e -> b.setBackground(b.getModel().isPressed() ? BRAND_DK : CTA));
        return b;
    }

    private JButton secondary(String text) {
        JButton b = new JButton(text);
        b.setFont(BODY);
        b.setForeground(TEXT);
        b.setBackground(new Color(245,245,245));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8,12,8,12));
        return b;
    }
}