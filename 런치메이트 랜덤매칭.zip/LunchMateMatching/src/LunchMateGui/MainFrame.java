package LunchMateGui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import LunchMateRestaurant.JDBCRestaurantDAO;

import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import LunchMateUser.UserVO;

//메인패널
public class MainFrame extends JFrame {

    private static final long serialVersionUID = 1L;

	private final UserVO currentUser;
	//마우스 클릭 했을때 효과 상수
	private static final Color NAV_BG        = Color.WHITE;
	private static final Color NAV_HOVER_BG  = new Color(245, 247, 250);
	private static final Color NAV_ACTIVE_BG = new Color(233, 238, 245);
	private static final Color NAV_BORDER    = new Color(235, 237, 240);

    //  중앙 영역 카드 전환용
    private final CardLayout contentLayout = new CardLayout();
    private final JPanel contentHost = new JPanel(contentLayout);

    //  타임보드 라벨 & 타이머
    private JLabel lblDate;
    private JLabel lblTime;
    private Timer  clockTimer;

    public MainFrame(UserVO v) {
    	
        this.currentUser = v;
        setTitle("점심 메이트 — 랜덤 매칭 시스템");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 760);
        setLocationRelativeTo(null);

        // ====== 전체 레이아웃 ======
        setLayout(new BorderLayout());

        // ====== 상단 타이틀바 ======
        JPanel appBar = new JPanel(new BorderLayout());
        appBar.setBorder(new EmptyBorder(8, 16, 8, 16));
        appBar.setBackground(Color.WHITE);

        JPanel titleBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        titleBox.setOpaque(false);

        JLabel appIcon = new JLabel("🍱");
        appIcon.setFont(appIcon.getFont().deriveFont(40f));

        JLabel title = new JLabel("점심 메이트");
        title.setFont(new Font("Pretendard", Font.BOLD, 35));
        title.setForeground(new Color(40, 40, 40));

        JLabel subtitle = new JLabel("랜덤 매칭 시스템");
        subtitle.setFont(new Font("Pretendard", Font.PLAIN, 15));
        subtitle.setForeground(new Color(120, 120, 120));

        JPanel titleText = new JPanel();
        titleText.setLayout(new BoxLayout(titleText, BoxLayout.Y_AXIS));
        titleText.setOpaque(false);
        titleText.add(title);
        titleText.add(subtitle);

        titleBox.add(appIcon);
        titleBox.add(titleText);

        //  오른쪽 상단: 타임보드(날짜/시간)
        JPanel rightBox = buildClockPanel();

        appBar.add(titleBox, BorderLayout.WEST);
        appBar.add(rightBox, BorderLayout.EAST);
        add(appBar, BorderLayout.NORTH);

        // ====== 좌측 사이드바 ======
        JPanel side = new JPanel();
        side.setLayout(new BorderLayout());
        side.setPreferredSize(new Dimension(240, getHeight()));
        side.setBackground(new Color(248, 249, 251));

        JPanel sideTop = new JPanel(new BorderLayout());
        sideTop.setOpaque(false);
        sideTop.setBorder(new EmptyBorder(16, 16, 8, 16));
        JLabel sideHeader = new JLabel("사이드바");
        sideHeader.setFont(new Font("Pretendard", Font.BOLD, 20));
        sideHeader.setForeground(new Color(110, 114, 120));
        sideTop.add(sideHeader, BorderLayout.NORTH);

        JPanel nav = new JPanel();
        nav.setOpaque(false);
        nav.setLayout(new GridLayout(0, 1, 0, 8));
        nav.setBorder(new EmptyBorder(8, 12, 16, 12));

        nav.add(makeNavButton("🏠 대시보드", e -> contentLayout.show(contentHost, "dashboard")));
        nav.add(makeNavButton("🗓 매칭 신청", e -> contentLayout.show(contentHost, "participation")));
        nav.add(makeNavButton("🤝 매칭 현황", e -> contentLayout.show(contentHost, "matchResult")));
        nav.add(makeNavButton("📍 맛집 지도", e -> contentLayout.show(contentHost, "restaurantMap")));
        nav.add(Box.createVerticalStrut(8));
        nav.add(makeNavButton("🙂 프로필 설정", e -> new UserProfileFrame(this, currentUser).setVisible(true)));

        sideTop.add(nav, BorderLayout.CENTER);
        side.add(sideTop, BorderLayout.CENTER);

        JPanel sideBottom = new JPanel(new BorderLayout());
        sideBottom.setOpaque(false);
        sideBottom.setBorder(new EmptyBorder(8, 16, 16, 16));
        JLabel foot = new JLabel("v0.1  •  Java Swing");
        foot.setFont(new Font("Pretendard", Font.PLAIN, 12));
        foot.setForeground(new Color(140, 144, 150));
        sideBottom.add(foot, BorderLayout.WEST);
        side.add(sideBottom, BorderLayout.SOUTH);

        add(side, BorderLayout.WEST);

        //중앙 컨텐츠(대시보드)
        contentHost.add(new DashBoardPanel(currentUser), "dashboard");
        contentHost.add(new ParticipationPanel(currentUser), "participation");
        contentHost.add(new MatchResultPanel(currentUser), "matchResult");
        contentHost.add(new RestaurantMapPanel(currentUser, new JDBCRestaurantDAO()), "restaurantMap");
        contentLayout.show(contentHost, "dashboard");
        add(contentHost, BorderLayout.CENTER);
        
        //타이머 시작
        startClock();
    }

    // 네비게이션 버튼(좌측 사이드바) (버튼 클릭시 효과)
    private JButton makeNavButton(String text, java.awt.event.ActionListener action) {
    	 JButton b = new JButton(text);
    	    b.setFocusPainted(false);
    	    b.setHorizontalAlignment(SwingConstants.LEFT);
    	    b.setBackground(NAV_BG);
    	    b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    	    b.setContentAreaFilled(true);
    	    b.setOpaque(true);
    	    b.setFont(new Font("Pretendard", Font.PLAIN, 16));
    	    b.setBorder(BorderFactory.createCompoundBorder(
    	            BorderFactory.createLineBorder(NAV_BORDER),
    	            new EmptyBorder(12, 14, 12, 14)   
    	    ));
    	    
    	    // 클릭,호버 효과
	        b.addMouseListener(new java.awt.event.MouseAdapter() {
	            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
	                if (!b.getModel().isPressed()) b.setBackground(NAV_HOVER_BG);
            }
	            
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                b.setBackground(NAV_BG);
            }
            
            @Override public void mousePressed(java.awt.event.MouseEvent e) {
                b.setBackground(NAV_ACTIVE_BG);
                // 살짝 안으로 눌린 느낌
                b.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(NAV_BORDER),
                        new EmptyBorder(13, 15, 11, 13) // 위/왼쪽 +1, 아래/오른쪽 -1
                ));
            }
            
            @Override public void mouseReleased(java.awt.event.MouseEvent e) {
                b.setBackground(b.getBounds().contains(e.getPoint()) ? NAV_HOVER_BG : NAV_BG);
                b.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(NAV_BORDER),
                        new EmptyBorder(12, 14, 12, 14)
                ));
            }
        });
        b.addActionListener(action);

        return b;
    }

    //타임보드(날짜/시간) UI
    private JPanel buildClockPanel() {
        // 라벨
        lblDate = new JLabel("0000-00-00 (월)");
        lblTime = new JLabel("00:00:00");

        // 스타일: 타임테이블 느낌의 카드
        JPanel box = new JPanel(new GridBagLayout());
        box.setOpaque(true);
        box.setBackground(Color.WHITE);
        box.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 232, 236), 1, true),
                new EmptyBorder(8, 12, 8, 12)
        ));

        lblDate.setFont(new Font("JetBrains Mono", Font.PLAIN, 12)); // 모노 폰트 선호(없으면 기본으로 표시)
        lblDate.setForeground(new Color(120, 120, 120));

        lblTime.setFont(new Font("JetBrains Mono", Font.BOLD, 18));
        lblTime.setForeground(new Color(40, 40, 40));

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.EAST;
        c.insets = new Insets(0, 0, 2, 0);
        box.add(lblDate, c);

        c.gridy = 1;
        box.add(lblTime, c);

        JPanel wrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        wrap.setOpaque(false);
        wrap.add(box);
        return wrap;
    }

    private void startClock() {
        DateTimeFormatter DF = DateTimeFormatter.ofPattern("yyyy-MM-dd (E)", Locale.KOREAN);
        DateTimeFormatter TF = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.KOREAN);

        // 최초 1회 업데이트
        Runnable tick = () -> {
            LocalDateTime now = LocalDateTime.now();
            lblDate.setText(now.format(DF));
            lblTime.setText(now.format(TF));
        };
        tick.run();

        // 1초마다 갱신
        clockTimer = new Timer(1000, e -> tick.run());
        clockTimer.setRepeats(true);
        clockTimer.start();
    }

    @Override
    public void dispose() {
        if (clockTimer != null) clockTimer.stop();
        super.dispose();
    }
}