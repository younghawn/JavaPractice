package LunchMateGui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

public class WelcomeFrame extends JFrame {

    private static final long serialVersionUID = 1L;

	public WelcomeFrame() {
        super("LunchMate - 환영합니다");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(780, 540);
        setLocationRelativeTo(null);

        JComponent hero   = createHeroSection();
        JComponent center = createCenterBranding();
        JComponent footer = createFooterButtons();

        JPanel root = new JPanel(new BorderLayout());
        root.add(hero, BorderLayout.NORTH);
        root.add(center, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);

        getRootPane().registerKeyboardAction(e -> dispose(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    private static Font uiFont(String key, int style, float size) {
        Font f = UIManager.getFont(key);
        if (f == null) f = new Font("Dialog", Font.PLAIN, Math.round(size));
        return f.deriveFont(style, size);
    }

    private JComponent createHeroSection() {
        return new GradientHeroPanel();
    }

    private JComponent createCenterBranding() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(20, 24, 8, 24));
        panel.setOpaque(false);

        LogoCanvas logo = new LogoCanvas();
        logo.setPreferredSize(new Dimension(740, 180));

        JLabel tagline = new JLabel("시간대/지역 기반으로 오늘의 점심 메이트를 랜덤 매칭합니다.", SwingConstants.CENTER);
        tagline.setFont(uiFont("Label.font", Font.PLAIN, 16f));
        tagline.setForeground(new Color(70, 70, 70));
        tagline.setBorder(new EmptyBorder(6, 0, 0, 0));

        panel.add(logo, BorderLayout.CENTER);
        panel.add(tagline, BorderLayout.SOUTH);
        return panel;
    }

    private JComponent createFooterButtons() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 18));
        p.setOpaque(false);

        final Dimension BTN_SIZE = new Dimension(170, 46);
        final Font BTN_FONT = uiFont("Button.font", Font.BOLD, 16f);

        JButton start = new RoundedButton("시작하기");
        start.setFont(BTN_FONT);
        start.setPreferredSize(BTN_SIZE);
        start.addActionListener(e -> {
            // 기존 dispose() → setVisible(false) 로 변경
            setVisible(false);
            new LoginFrame().setVisible(true);
        });

        JButton info = new RoundedButton("서비스 소개");
        info.setFont(BTN_FONT);
        info.setPreferredSize(BTN_SIZE);
        info.addActionListener(e ->
                JOptionPane.showMessageDialog(this,
                        "점심 메이트 랜덤 매칭 시스템\n• 시간대/지역/성별 조건 반영\n• 메뉴 추천 & 맛집 지도 링크",
                        "LunchMate 소개", JOptionPane.INFORMATION_MESSAGE));

        JButton exit = new RoundedButton("종료");
        exit.setFont(BTN_FONT);
        exit.setPreferredSize(BTN_SIZE);
        exit.addActionListener(e -> dispose());

        p.add(start);
        p.add(info);
        p.add(exit);
        return p;
    }

    static class GradientHeroPanel extends JPanel {
        private static final long serialVersionUID = 1L;
		@Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            int w = getWidth(), h = getHeight();

            GradientPaint gp = new GradientPaint(0, 0, new Color(255, 154, 84),
                                                 w, h, new Color(255, 209, 148));
            g2.setPaint(gp);
            g2.fillRect(0, 0, w, h);

            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.12f));
            g2.setColor(Color.white);
            for (int i = 0; i < 6; i++) g2.fillOval(-120 + i * 160, -110, 260, 260);

            g2.dispose();
        }
        @Override
        public Dimension getPreferredSize() { return new Dimension(780, 200); }
    }

    static class LogoCanvas extends JComponent {
        private static final long serialVersionUID = 1L;
		private float pulse = 0f;
        private boolean up = true;
        private final Timer timer;

        public LogoCanvas() {
            setOpaque(false);
            timer = new Timer(35, e -> {
                pulse += (up ? 0.02f : -0.02f);
                if (pulse > 1f) { pulse = 1f; up = false; }
                if (pulse < 0f) { pulse = 0f; up = true; }
                repaint();
            });
            timer.start();
            addHierarchyListener(ev -> {
                if ((ev.getChangeFlags() & HierarchyEvent.DISPLAYABILITY_CHANGED) != 0) {
                    if (!isDisplayable()) timer.stop();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth(), h = getHeight();
            g2.setColor(new Color(252, 252, 252));
            g2.fillRoundRect(0, 0, w, h, 24, 24);

            int cx = w / 2;
            int cy = h / 2 + 6;
            float plateR = 56 + 2 * (float)Math.sin(pulse * Math.PI);

            g2.setColor(new Color(0, 0, 0, 30));
            g2.fillOval((int)(cx - plateR) + 3, (int)(cy - plateR) + 6, (int)(2*plateR), (int)(2*plateR));

            g2.setPaint(new GradientPaint(cx, cy - plateR, new Color(255, 255, 255),
                                          cx, cy + plateR, new Color(245, 245, 245)));
            g2.fillOval((int)(cx - plateR), (int)(cy - plateR), (int)(2*plateR), (int)(2*plateR));
            float inner = plateR * 0.72f;
            g2.setColor(new Color(255, 255, 255));
            g2.fillOval((int)(cx - inner), (int)(cy - inner), (int)(2*inner), (int)(2*inner));

            Color brand = new Color(255, 140, 66);
            Color gray  = new Color(110, 110, 115);
            Color stroke= new Color(70, 70, 75);
            drawAvatar(g2, cx - 20, cy, 1.0f, brand, stroke);
            drawAvatar(g2, cx + 20, cy, 1.0f, gray,  stroke);

            Font f1 = WelcomeFrame.uiFont("Label.font", Font.BOLD, 26f);
            Font f2 = WelcomeFrame.uiFont("Label.font", Font.BOLD, 40f);
            g2.setFont(f1);
            g2.setColor(new Color(60, 60, 60));
            g2.drawString("점심메이트 랜덤매칭", cx - 100, cy - 64);

            g2.setFont(f2);
            g2.setColor(new Color(255, 140, 66));
            g2.drawString("LunchMate", cx - 106, cy + 72);

            g2.dispose();
        }

        private void drawAvatar(Graphics2D g2, int cx, int cy, float scale, Color fill, Color outline) {
            Graphics2D g = (Graphics2D) g2.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g.setColor(new Color(0, 0, 0, 40));
            g.fill(new Ellipse2D.Float(cx - 18*scale, cy + 10*scale, 36*scale, 10*scale));

            float r = 8f * scale;
            Shape head = new Ellipse2D.Float(cx - r, cy - 12f*scale - r, 2*r, 2*r);
            g.setColor(fill); g.fill(head);
            g.setColor(outline); g.setStroke(new BasicStroke(1.6f * scale)); g.draw(head);

            float bw = 28f * scale, bh = 16f * scale;
            Shape body = new RoundRectangle2D.Float(cx - bw/2f, cy - 2f*scale, bw, bh, 10f*scale, 10f*scale);
            g.setColor(fill); g.fill(body);
            g.setColor(outline); g.draw(body);

            g.setStroke(new BasicStroke(1.1f * scale));
            g.setColor(new Color(255, 255, 255, 110));
            g.draw(new Line2D.Float(cx - bw/2f + 3f*scale, cy, cx - bw/2f + 12f*scale, cy - 3f*scale));

            g.dispose();
        }
    }

    static class RoundedButton extends JButton {
        private static final long serialVersionUID = 1L;

		public RoundedButton(String text) {
            super(text);
            setFocusPainted(false);
            setContentAreaFilled(false);
            setForeground(Color.white);
            setBackground(new Color(255, 140, 66));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(BorderFactory.createEmptyBorder(10, 22, 10, 22));
            setOpaque(false);

            if ("시작하기".equals(text)) {
                getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "enter");
                getActionMap().put("enter", new AbstractAction() {
                    private static final long serialVersionUID = 1L;

					@Override public void actionPerformed(ActionEvent e) { doClick(); }
                });
            }
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { setBackground(new Color(255, 122, 46)); repaint(); }
                @Override public void mouseExited (MouseEvent e) { setBackground(new Color(255, 140, 66)); repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            g2.setPaint(new GradientPaint(0, 0, getBackground(), 0, h, getBackground().darker()));
            g2.fillRoundRect(0, 0, w, h, 18, 18);
            super.paintComponent(g2);
            g2.dispose();
        }

        @Override
        public void updateUI() {
            super.updateUI();
            Font f = UIManager.getFont("Button.font");
            if (f == null) f = getFont();
            if (f == null) f = new Font("Dialog", Font.BOLD, 14);
            setFont(f.deriveFont(Font.BOLD, 14f));
        }
    }
}