package LunchMateGui;

import LunchMateConnInfo.ConnectionManager;
import LunchMateUser.UserVO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


// 매칭 결과 패널
// matches 테이블을 직접 조회하여 현재 사용자(user_id)가 속한 매칭을 보여준다.
// 좌측: 필터 + 매칭 리스트 / 우측: 선택 매칭 상세 (상대방 프로필 카드 + 간이 지도)
// 다른 DAO/VO에 의존하지 않고 JDBC로만 동작

public class MatchResultPanel extends JPanel {

    private static final long serialVersionUID = 1L;

    // ---- 테마 ----
    private static final Color BG         = new Color(246, 247, 249);
    private static final Color SURFACE    = Color.WHITE;
    private static final Color MUTED      = new Color(120, 120, 120);
    private static final Color LINE       = new Color(230, 232, 236);
    private static final Color BRAND      = new Color(255, 140, 66);
    private static final Color BRAND_DK   = new Color(230, 110, 40);

    private static final Font  H1   = new Font("SansSerif", Font.BOLD, 20);
    private static final Font  H2   = new Font("SansSerif", Font.BOLD, 16);
    private static final Font  BODY = new Font("SansSerif", Font.PLAIN, 14);
    private static final Font  SMALL= new Font("SansSerif", Font.PLAIN, 12);

    private final UserVO currentUser;

    // UI
    private final JButton btnRefresh = new JButton("새로고침");
    //선택 매칭 삭제 버튼
    private final JButton btnDelete = new JButton("매칭 삭제");

    private final JTable table;
    private final DefaultTableModel tableModel;
    private final JPanel detailPanel;

    // 내부 모델: 테이블의 행과 1:1 매핑
    private final List<MatchRow> rows = new ArrayList<>();

    public MatchResultPanel(UserVO currentUser) {
        this.currentUser = currentUser;

        setOpaque(true);
        setBackground(BG);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(16,16,16,16));

        // 헤더
        add(buildHeader(), BorderLayout.NORTH);

        // 본문: 좌(리스트) / 우(상세)
        JPanel body = new JPanel(new GridBagLayout());
        body.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(0, 0, 0, 12);
        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1.0;

        // 좌: 카드 + 테이블
        JPanel listCard = card();
        listCard.setLayout(new BorderLayout(0, 8));
        listCard.add(buildFilterBar(), BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new String[]{"ID","날짜","시간","장소","인원","메뉴"}, 0) {
            private static final long serialVersionUID = 1L;
            
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        styleTable(table);
        listCard.add(new JScrollPane(table), BorderLayout.CENTER);

        c.gridx = 0; c.gridy = 0; c.weightx = 0.55;
        body.add(listCard, c);

        // 우: 상세 패널
        detailPanel = card();
        detailPanel.setLayout(new BorderLayout());
        detailPanel.add(emptyDetail(), BorderLayout.CENTER);

        c.gridx = 1; c.gridy = 0; c.weightx = 0.45; c.insets = new Insets(0,0,0,0);
        body.add(detailPanel, c);

        add(body, BorderLayout.CENTER);

        // 이벤트
        btnRefresh.addActionListener(e -> reload());
        btnDelete.addActionListener(e -> onDeleteSelected()); 
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) showSelectedDetail();
        });

        // 최초 로드
        reload();
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel hero = new JPanel() {
            private static final long serialVersionUID = 1L;

			@Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                int w = getWidth(), h = getHeight();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(255,154,84), w, h, new Color(255,209,148));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, w, h, 18, 18);
                g2.setColor(new Color(255,255,255,235));
                g2.setFont(H1);
                g2.drawString("🤝 매칭 현황", 16, 36);
                g2.setFont(BODY);
                g2.drawString("내가 포함된 매칭 결과를 확인해 보세요.", 16, 60);
                g2.dispose();
            }
        };
        hero.setPreferredSize(new Dimension(0, 80));
        hero.setOpaque(false);

        header.add(hero, BorderLayout.CENTER);
        header.setBorder(new EmptyBorder(0,0,12,0));
        return header;
    }

    private JComponent buildFilterBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(false);
        bar.setBorder(new EmptyBorder(8, 8, 0, 8));

 

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        styleDanger(btnDelete);   //삭제 버튼 스타일
        stylePrimary(btnRefresh);
        right.add(btnDelete);     //새로고침 왼쪽에 배치
        right.add(btnRefresh);

        
        bar.add(right, BorderLayout.EAST);

        return bar;
    }

    private JPanel emptyDetail() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        JLabel l = new JLabel("좌측 리스트에서 매칭을 선택하세요.");
        l.setFont(BODY);
        l.setForeground(MUTED);
        p.add(l);
        return p;
    }

    private void showSelectedDetail() {
        int row = table.getSelectedRow();
        if (row < 0 || row >= rows.size()) {
            detailPanel.removeAll();
            detailPanel.add(emptyDetail(), BorderLayout.CENTER);
            detailPanel.revalidate();
            detailPanel.repaint();
            return;
        }
        MatchRow m = rows.get(row);
        detailPanel.removeAll();
        detailPanel.add(buildDetail(m), BorderLayout.CENTER);
        detailPanel.revalidate();
        detailPanel.repaint();
    }

    private JComponent buildDetail(MatchRow m) {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);

        // 상단 기본 정보
        JPanel head = new JPanel(new GridBagLayout());
        head.setOpaque(false);
        head.setBorder(new EmptyBorder(12,12,12,12));

        GridBagConstraints c = new GridBagConstraints();
        c.gridx=0; c.gridy=0; c.anchor=GridBagConstraints.WEST; c.insets=new Insets(0,0,6,0);

        JLabel title = new JLabel("매칭 상세");
        title.setFont(H2);
        head.add(title, c);

        c.gridy++;
        JLabel info = new JLabel(String.format("날짜 %s  ·  시간 %s  ·  인원 %d명  ·  메뉴 %s",
                m.date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                m.timeSlot,
                m.groupSize,
                (m.menu != null ? m.menu : "-")));
        info.setFont(BODY);
        head.add(info, c);

        c.gridy++;
        JLabel place = new JLabel("장소: " + (m.region != null ? m.region : "-"));
        place.setFont(BODY);
        place.setForeground(new Color(70,70,70));
        head.add(place, c);

        wrap.add(head, BorderLayout.NORTH);

        // 상대방 카드들 + 지도
        JPanel center = new JPanel(new BorderLayout(0,8));
        center.setOpaque(false);

        JPanel people = new JPanel(new GridLayout(0,1,0,8));
        people.setBorder(new EmptyBorder(0,12,0,12));
        people.setOpaque(false);

        // 지도에 뿌릴 사용자 좌표를 위해 수집
        List<UserInfo> allUsers = new ArrayList<>();

        for (Integer uid : m.participantUserIds) {
            if (uid == null) continue;
            UserInfo u = fetchUser(uid);
            if (u != null) allUsers.add(u);
            // 나 자신 제외하고 카드 표시
            if (currentUser != null && currentUser.getId() != null && uid.equals(currentUser.getId())) continue;
            people.add(buildUserCard(u));
        }
        if (people.getComponentCount() == 0) {
            people.add(buildMutedCard("상대방 정보가 없습니다."));
        }

        center.add(people, BorderLayout.NORTH);

        // 지도
        MapParams mp = parseRegion(m.region);
        JPanel mapPanel = new MiniMapPanel(mp.centerLat, mp.centerLng, mp.radiusKm, allUsers);
        mapPanel.setPreferredSize(new Dimension(10, 260));
        mapPanel.setBorder(new EmptyBorder(8,12,12,12));
        center.add(mapPanel, BorderLayout.CENTER);

        wrap.add(center, BorderLayout.CENTER);
        return wrap;
    }

    private JPanel buildUserCard(UserInfo u) {
        JPanel card = card();
        card.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,8,6,8);
        c.anchor = GridBagConstraints.WEST;

        JLabel avatar = new JLabel("👤");
        avatar.setFont(new Font("SansSerif", Font.PLAIN, 28));
        c.gridx=0; c.gridy=0; c.gridheight=3; c.insets=new Insets(6,6,6,12);
        card.add(avatar, c);

        c.gridheight=1;
        c.gridx=1; c.gridy=0;
        JLabel name = new JLabel(u != null && u.name != null ? u.name : "(알 수 없음)");
        name.setFont(new Font("SansSerif", Font.BOLD, 15));
        card.add(name, c);

        c.gridy=1;
        String idAndGender = String.format("ID: %s   ·   성별: %s",
                (u != null && u.id != null ? u.id : "-"),
                (u != null && u.gender != null ? u.gender : "-"));
        JLabel meta1 = new JLabel(idAndGender);
        meta1.setFont(SMALL);
        meta1.setForeground(MUTED);
        card.add(meta1, c);

        c.gridy=2;
        String coord = (u != null && u.latitude != null && u.longitude != null)
                ? String.format("위도 %.6f  ·  경도 %.6f", u.latitude, u.longitude) : "좌표 미등록";
        JLabel coords = new JLabel(coord);
        coords.setFont(SMALL);
        coords.setForeground(new Color(100,100,100));
        card.add(coords, c);

        return card;
    }

    private JPanel buildMutedCard(String text) {
        JPanel card = card();
        card.setLayout(new BorderLayout());
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setFont(BODY);
        l.setForeground(MUTED);
        card.add(l, BorderLayout.CENTER);
        return card;
    }

    //데이터 로딩
    private void reload() {
        rows.clear();
        tableModel.setRowCount(0);

        if (currentUser == null || currentUser.getId() == null) {
            JOptionPane.showMessageDialog(this, "로그인 정보가 없습니다.", "오류", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<MatchRow> data = fetchMatchesForUser(currentUser.getId());
        for (MatchRow m : data) {
            rows.add(m);
            tableModel.addRow(new Object[]{
                    m.id,
                    m.date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                    m.timeSlot,
                    (m.region != null ? m.region : "-"),
                    m.groupSize,
                    (m.menu != null ? m.menu : "-")
            });
        }

        // 상세 초기화
        detailPanel.removeAll();
        detailPanel.add(rows.isEmpty() ? emptyDetail() : buildDetail(rows.get(0)), BorderLayout.CENTER);
        detailPanel.revalidate();
        detailPanel.repaint();

        if (!rows.isEmpty()) {
            table.setRowSelectionInterval(0,0);
        }
    }

    
//     현재 사용자(userId)가 포함된 매칭을 조회.   
    private List<MatchRow> fetchMatchesForUser(int userId) {
        List<MatchRow> list = new ArrayList<>();

        String sql =
            "SELECT id, match_date, time_slot, region, user_id_a, user_id_b, user_id_c, group_size, menu, created_at " +
            "FROM matches " +
            "WHERE (user_id_a = ? OR user_id_b = ? OR (user_id_c IS NOT NULL AND user_id_c = ?)) " +
            "ORDER BY match_date DESC, time_slot ASC, created_at DESC";

        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            int i = 1;
            ps.setInt(i++, userId);
            ps.setInt(i++, userId);
            ps.setInt(i++, userId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MatchRow m = new MatchRow();
                    m.id        = rs.getInt("id");
                    java.sql.Date d = rs.getDate("match_date");
                    m.date      = (d != null ? d.toLocalDate() : null);
                    m.timeSlot  = rs.getString("time_slot");
                    m.region    = rs.getString("region");
                    m.userAId   = getNullableInt(rs, "user_id_a");
                    m.userBId   = getNullableInt(rs, "user_id_b");
                    m.userCId   = getNullableInt(rs, "user_id_c");
                    m.groupSize = rs.getInt("group_size");
                    m.menu      = rs.getString("menu");

                    m.participantUserIds = new ArrayList<>();
                    if (m.userAId != null) m.participantUserIds.add(m.userAId);
                    if (m.userBId != null) m.participantUserIds.add(m.userBId);
                    if (m.userCId != null) m.participantUserIds.add(m.userCId);

                    list.add(m);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "매칭 불러오기 오류: " + ex.getMessage(),
                    "오류", JOptionPane.ERROR_MESSAGE);
        }
        return list;
    }

    private Integer getNullableInt(ResultSet rs, String col) throws SQLException {
        int v = rs.getInt(col);
        return rs.wasNull() ? null : v;
    }

    private UserInfo fetchUser(int userId) {
        // gender 컬럼이 없어도 동작해야 하므로 넉넉히 SELECT하고, 없으면 읽기만 건너뜀
        String sql = "SELECT id, name, email, latitude, longitude, gender FROM users WHERE id = ?";
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    UserInfo u = new UserInfo();
                    u.id = rs.getInt("id");
                    u.name = safeGet(rs, "name");
                    u.email = safeGet(rs, "email");
                    Object latObj = rs.getObject("latitude");
                    Object lngObj = rs.getObject("longitude");
                    u.latitude = (latObj instanceof Number) ? ((Number) latObj).doubleValue() : null;
                    u.longitude= (lngObj instanceof Number) ? ((Number) lngObj).doubleValue() : null;
                    u.gender = safeGet(rs, "gender");
                    return u;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private String safeGet(ResultSet rs, String col) {
        try {
            return rs.getString(col);
        } catch (SQLException e) {
            return null;
        }
    }

    //유틸 UI
    private JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(SURFACE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(LINE),
                new EmptyBorder(14,16,14,16)
        ));
        return p;
    }

    private void styleTable(JTable t) {
        t.setRowHeight(28);
        t.setFont(BODY);
        t.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        t.setFillsViewportHeight(true);
        t.setShowGrid(true);
        t.setGridColor(new Color(240, 242, 246));
        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        t.getColumnModel().getColumn(0).setPreferredWidth(60);   // ID
        t.getColumnModel().getColumn(1).setPreferredWidth(100);  // 날짜
        t.getColumnModel().getColumn(2).setPreferredWidth(120);  // 시간
        t.getColumnModel().getColumn(3).setPreferredWidth(260);  // 장소
        t.getColumnModel().getColumn(4).setPreferredWidth(60);   // 인원
        t.getColumnModel().getColumn(5).setPreferredWidth(120);  // 메뉴
    }

    private void stylePrimary(AbstractButton b) {
        b.setFont(BODY);
        b.setForeground(Color.WHITE);
        b.setBackground(BRAND);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8,12,8,12));
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.addChangeListener(e -> b.setBackground(b.getModel().isPressed() ? BRAND_DK : BRAND));
    }

    //삭제 버튼 스타일
    private void styleDanger(AbstractButton b) {
        b.setFont(BODY);
        b.setForeground(Color.WHITE);
        Color DANGER = new Color(220, 72, 60);
        Color DANGER_DK = new Color(190, 55, 45);
        b.setBackground(DANGER);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8,12,8,12));
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.addChangeListener(e -> b.setBackground(b.getModel().isPressed() ? DANGER_DK : DANGER));
    }

    //내부 DTO 

    private static class MatchRow {
        int id;
        LocalDate date;
        String timeSlot;
        String region;
        Integer userAId, userBId, userCId;
        int groupSize;
        String menu;
        List<Integer> participantUserIds;
    }

    private static class UserInfo {
        Integer id;
        String name;
        @SuppressWarnings("unused")
		String email;
        String gender;
        Double latitude;
        Double longitude;
    }

    //간단한 지도 표현용

    private static class MapParams {
        Double centerLat;
        Double centerLng;
        Double radiusKm;
        MapParams(Double clat, Double clng, Double rkm) {
            this.centerLat = clat; this.centerLng = clng; this.radiusKm = rkm;
        }
    }

    private MapParams parseRegion(String region) {
        if (region == null) return new MapParams(null, null, null);

        // 형식 1: center(37.570500,126.983200)±3.0km
        Pattern p1 = Pattern.compile("center\\s*\\(\\s*([\\-\\d\\.]+)\\s*,\\s*([\\-\\d\\.]+)\\s*\\)\\s*±\\s*([\\d\\.]+)\\s*km",
                Pattern.CASE_INSENSITIVE);
        Matcher m1 = p1.matcher(region);
        if (m1.find()) {
            try {
                double lat = Double.parseDouble(m1.group(1));
                double lng = Double.parseDouble(m1.group(2));
                double rkm = Double.parseDouble(m1.group(3));
                return new MapParams(lat, lng, rkm);
            } catch (NumberFormatException ignore) {}
        }

        // 형식 2: lat:37.57..., lng:126.98...
        Pattern p2 = Pattern.compile("lat\\s*:\\s*([\\-\\d\\.]+)\\s*,\\s*lng\\s*:\\s*([\\-\\d\\.]+)", Pattern.CASE_INSENSITIVE);
        Matcher m2 = p2.matcher(region);
        if (m2.find()) {
            try {
                double lat = Double.parseDouble(m2.group(1));
                double lng = Double.parseDouble(m2.group(2));
                return new MapParams(lat, lng, null);
            } catch (NumberFormatException ignore) {}
        }

        return new MapParams(null, null, null);
    }

  
//     	외부 맵 API 없이 Graphics2D로 간단히 그려주는 미니맵.
//      중심 좌표(노란 점), 반경(있으면 원), 사용자들(파란 점)
//      위경도 → 화면 좌표 변환은 단순 선형 스케일링
    private static class MiniMapPanel extends JPanel {
        private static final long serialVersionUID = 1L;
		private final Double centerLat, centerLng, radiusKm;
        private final List<UserInfo> users;

        MiniMapPanel(Double centerLat, Double centerLng, Double radiusKm, List<UserInfo> users) {
            this.centerLat = centerLat;
            this.centerLng = centerLng;
            this.radiusKm  = radiusKm;
            this.users     = (users != null ? users : new ArrayList<>());
            setOpaque(false);
        }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            int w = getWidth(), h = getHeight();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // 배경 카드 느낌
            g2.setColor(new Color(250,250,250));
            g2.fillRoundRect(0,0,w,h,12,12);
            g2.setColor(new Color(230,230,230));
            g2.drawRoundRect(0,0,w-1,h-1,12,12);

            if (centerLat == null || centerLng == null) {
                drawCenteredText(g2, w, h, "지도를 표시할 좌표 정보가 없습니다.");
                g2.dispose();
                return;
            }

            // 사용자 좌표 범위 계산 (중심 기준 ±0.02도 범위를 기본 뷰포트로)
            double pad = 0.02;
            double minLat = centerLat - pad, maxLat = centerLat + pad;
            double minLng = centerLng - pad, maxLng = centerLng + pad;

            for (UserInfo u : users) {
                if (u == null || u.latitude == null || u.longitude == null) continue;
                minLat = Math.min(minLat, u.latitude);
                maxLat = Math.max(maxLat, u.latitude);
                minLng = Math.min(minLng, u.longitude);
                maxLng = Math.max(maxLng, u.longitude);
            }

            //람다에서 참조할 "불변 복사본" 생성 (final/effectively-final)
            final double finalMinLat = minLat;
            final double finalMaxLat = maxLat;
            final double finalMinLng = minLng;
            final double finalMaxLng = maxLng;

            // 좌표 → 화면 변환 함수
            final double latRange = Math.max(1e-6, finalMaxLat - finalMinLat);
            final double lngRange = Math.max(1e-6, finalMaxLng - finalMinLng);
            int padPix = 24;
            double sx = (w - 2.0 * padPix) / lngRange;
            double sy = (h - 2.0 * padPix) / latRange;

            java.util.function.BiFunction<Double, Double, Point> project = (lat, lng) -> {
                int x = (int) (padPix + (lng - finalMinLng) * sx);
                int y = (int) (h - padPix - (lat - finalMinLat) * sy);
                return new Point(x, y);
            };

            // 반경 원(있을 때만) — 화면 스케일 비례 원 표시(대략값)
            Point pc = project.apply(centerLat, centerLng);
            if (radiusKm != null && radiusKm > 0) {
                int r = (int) Math.max(20, Math.min(w, h) * 0.3);
                g2.setColor(new Color(255, 215, 0, 40));
                g2.fillOval(pc.x - r, pc.y - r, r*2, r*2);
                g2.setColor(new Color(255, 180, 0, 160));
                g2.drawOval(pc.x - r, pc.y - r, r*2, r*2);
            }

            // 중심 포인트
            g2.setColor(new Color(255, 200, 0));
            g2.fillOval(pc.x - 6, pc.y - 6, 12, 12);
            g2.setColor(new Color(255, 150, 0));
            g2.drawOval(pc.x - 6, pc.y - 6, 12, 12);

            // 사용자들
            for (UserInfo u : users) {
                if (u == null || u.latitude == null || u.longitude == null) continue;
                Point p = project.apply(u.latitude, u.longitude);
                g2.setColor(new Color(52, 120, 246));
                g2.fillOval(p.x - 5, p.y - 5, 10, 10);
                g2.setColor(new Color(30, 90, 210));
                g2.drawOval(p.x - 5, p.y - 5, 10, 10);

                // 간단 라벨(이름/ID)
                g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
                g2.setColor(new Color(60,60,60));
                String label = (u.name != null ? u.name : String.valueOf(u.id));
                g2.drawString(label, p.x + 6, p.y - 6);
            }

            g2.dispose();
        }

        private void drawCenteredText(Graphics2D g2, int w, int h, String s) {
            g2.setColor(new Color(120,120,120));
            g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
            FontMetrics fm = g2.getFontMetrics();
            int x = (w - fm.stringWidth(s)) / 2;
            int y = (h - fm.getHeight()) / 2 + fm.getAscent();
            g2.drawString(s, x, y);
        }
    }

    //삭제 로직
    private void onDeleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0 || row >= rows.size()) {
            JOptionPane.showMessageDialog(this, "삭제할 매칭을 선택하세요.", "알림", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (currentUser == null || currentUser.getId() == null) {
            JOptionPane.showMessageDialog(this, "로그인 정보가 없습니다.", "오류", JOptionPane.ERROR_MESSAGE);
            return;
        }

        MatchRow m = rows.get(row);
        int ok = JOptionPane.showConfirmDialog(
                this,
                "선택한 매칭(ID: " + m.id + ")을 삭제할까요?\n이 작업은 되돌릴 수 없습니다.",
                "확인",
                JOptionPane.OK_CANCEL_OPTION
        );
        if (ok != JOptionPane.OK_OPTION) return;

        String sql =
            "DELETE FROM matches " +
            "WHERE id = ? " +
            "  AND (user_id_a = ? OR user_id_b = ? OR (user_id_c IS NOT NULL AND user_id_c = ?))";

        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            int i = 1;
            ps.setInt(i++, m.id);
            ps.setInt(i++, currentUser.getId());
            ps.setInt(i++, currentUser.getId());
            ps.setInt(i,   currentUser.getId());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                JOptionPane.showMessageDialog(this, "삭제되었습니다.");
                reload();
            } else {
                JOptionPane.showMessageDialog(this,
                        "삭제할 수 없었습니다. (권한이 없거나 이미 삭제됨)",
                        "알림",
                        JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "삭제 중 오류: " + ex.getMessage(),
                    "오류", JOptionPane.ERROR_MESSAGE);
        }
    }
}