package LunchMateGui;

import LunchMateUser.UserDAO;
import LunchMateUser.JDBCUserDAO;
import LunchMateUser.UserVO;

import javax.swing.*;

import LunchMateDB.PasswordUtil;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;

import LunchMateCommon.MapPickerDialog;

public class SignUpFrame extends JDialog {
	
    private static final long serialVersionUID = 1L;
	private final JTextField name  = new JTextField(22);
    private final JTextField email = new JTextField(22);
    private final JPasswordField pass = new JPasswordField(22);
    private final JComboBox<String> gender = new JComboBox<>(new String[]{"MALE","FEMALE","OTHER"});

    // 좌표 입력(선택)
    private final JTextField latitudeField  = new JTextField(10);
    private final JTextField longitudeField = new JTextField(10);

    //비밀번호 표시 토글용 기본 echo char
    private final char defaultEchoChar;

    public SignUpFrame(Frame owner) {
        super(owner, "회원가입", true);
        setSize(580, 520);             
        setLocationRelativeTo(owner);
        setResizable(false);

        Character uiEcho = (Character) UIManager.get("PasswordField.echoChar");
        defaultEchoChar = (uiEcho != null) ? uiEcho.charValue() : '\u2022';

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BG);
        setContentPane(root);

        JPanel header = new GradientBar("환영해요! 점심메이트 가입");
        header.setPreferredSize(new Dimension(580, 90));
        root.add(header, BorderLayout.NORTH);

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        root.add(wrapCard(card), BorderLayout.CENTER);

        GridBagConstraints c = Theme.gbc();
        int row = 0;

        // 제목
        JLabel title = Theme.h1("회원가입");
        c.gridx = 0; c.gridy = row++; c.gridwidth = 2; c.insets = new Insets(0,0,16,0);
        card.add(title, c);
        c.gridwidth = 1;

        // 이름
        c.gridy = row; c.gridx = 0; c.insets = new Insets(6, 0, 6, 14);
        card.add(Theme.labelRight("이름"), c);
        c.gridx = 1; c.insets = new Insets(6, 0, 6, 0);
        card.add(Theme.input(name), c);
        row++;

        // 이메일
        c.gridy = row; c.gridx = 0; c.insets = new Insets(6, 0, 6, 14);
        card.add(Theme.labelRight("이메일"), c);
        c.gridx = 1; c.insets = new Insets(6, 0, 6, 0);
        card.add(Theme.input(email), c);
        row++;

        // 비밀번호 + 보기 토글
        c.gridy = row; c.gridx = 0; c.insets = new Insets(6, 0, 6, 14);
        card.add(Theme.labelRight("비밀번호"), c);

        JPanel pwRow = new JPanel(new BorderLayout());
        pwRow.setOpaque(false);
        pass.setEchoChar(defaultEchoChar);
        pwRow.add(Theme.input(pass), BorderLayout.CENTER);

        JCheckBox show = new JCheckBox("표시");
        show.setOpaque(false);
        show.addItemListener(ev -> {
            boolean checked = (ev.getStateChange() == ItemEvent.SELECTED);
            pass.setEchoChar(checked ? (char)0 : defaultEchoChar);
        });
        pwRow.add(show, BorderLayout.EAST);

        c.gridx = 1; c.insets = new Insets(6, 0, 6, 0);
        card.add(pwRow, c);
        row++;

        // 성별
        c.gridy = row; c.gridx = 0; c.insets = new Insets(6, 0, 6, 14);
        card.add(Theme.labelRight("성별"), c);
        c.gridx = 1; c.insets = new Insets(6, 0, 6, 0);
        gender.setPreferredSize(new Dimension(180, 34));
        card.add(gender, c);
        row++;

        // ───────────────── 좌표(선택) 행: 가로 정렬 & 동일 높이/폭로 맞춤
        c.gridy = row; c.gridx = 0; c.insets = new Insets(6, 0, 6, 14);
        card.add(Theme.labelRight("현재 위치 입력"), c);

        JPanel coordRow = new JPanel(new GridBagLayout());
        coordRow.setOpaque(false);
        GridBagConstraints cg = new GridBagConstraints();
        cg.gridy = 0;
        cg.insets = new Insets(0, 0, 0, 8);

        // 위도
        latitudeField.setToolTipText("예: 37.5665");
        latitudeField.setPreferredSize(new Dimension(140, 34));           
        JComponent latComp = Theme.input(latitudeField);
        latComp.setPreferredSize(new Dimension(140, 34));                  
        cg.gridx = 0; cg.weightx = 0; cg.fill = GridBagConstraints.NONE;
        coordRow.add(latComp, cg);

        // 경도
        longitudeField.setToolTipText("예: 126.9780");
        longitudeField.setPreferredSize(new Dimension(140, 34));
        JComponent lngComp = Theme.input(longitudeField);
        lngComp.setPreferredSize(new Dimension(140, 34));
        cg.gridx = 1; cg.weightx = 0; cg.fill = GridBagConstraints.NONE;
        coordRow.add(lngComp, cg);

        // 지도 버튼
        JButton pickOnMap = new RoundedButton("지도에서 선택");
        pickOnMap.setPreferredSize(new Dimension(130, 34));
        pickOnMap.addActionListener(ev -> openMapPicker());
        cg.gridx = 2; cg.weightx = 0; cg.fill = GridBagConstraints.NONE;
        coordRow.add(pickOnMap, cg);

        // 여유 공간(오른쪽 끝까지 밀착 정렬 보장용)
        cg.gridx = 3; cg.weightx = 1; cg.fill = GridBagConstraints.HORIZONTAL; cg.insets = new Insets(0,0,0,0);
        coordRow.add(Box.createHorizontalStrut(1), cg);

        c.gridx = 1; c.insets = new Insets(6, 0, 6, 0);
        card.add(coordRow, c);
        row++;

        // 안내
        JLabel hint = new JLabel("※ 현재 위치 입력(필수)! 지도로 찍으면 좌표값이 자동 입력됩니다.");
        hint.setForeground(new Color(110,110,110));
        c.gridy = row++; c.gridx = 0; c.gridwidth = 2; c.insets = new Insets(2, 100, 6, 0);
        card.add(hint, c);
        c.gridwidth = 1;

        // 버튼들
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btns.setOpaque(false);
        JButton cancel = new RoundedButton("취소");
        cancel.addActionListener(e -> dispose());
        JButton save = new RoundedButtonPrimary("가입하기");
        save.addActionListener(this::onSignUp);
        btns.add(cancel); btns.add(save);

        c.gridy = row; c.gridx = 0; c.gridwidth = 2; c.insets = new Insets(16, 0, 0, 0);
        card.add(btns, c);

        // 단축키
        getRootPane().setDefaultButton(save);
        getRootPane().registerKeyboardAction(e -> dispose(),
                KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    private void openMapPicker() {
        String kakaoJsKey = System.getenv("KAKAO_JS_KEY");
        if (kakaoJsKey == null || kakaoJsKey.isBlank()) {
            kakaoJsKey = System.getProperty("KAKAO_JS_KEY");
        }
        Frame parent = (Frame) SwingUtilities.getWindowAncestor(this);
        MapPickerDialog dlg = new MapPickerDialog(parent, kakaoJsKey);
        dlg.setVisible(true);

        Double lat = dlg.getLatitude();
        Double lng = dlg.getLongitude();
        if (lat != null && lng != null) {
            latitudeField.setText(String.valueOf(lat));
            longitudeField.setText(String.valueOf(lng));
        }
    }

    private void onSignUp(ActionEvent e) {
        try {
            String nm = name.getText().trim();
            String em = email.getText().trim();
            String pw = new String(pass.getPassword()).trim();
            String gd = (String) gender.getSelectedItem();

            // 좌표 입력 원문 문자열 (공란 체크를 위함)
            String latStr = latitudeField.getText().trim();
            String lngStr = longitudeField.getText().trim();

            // 빈값 검사
            if (nm.isEmpty()) {
                JOptionPane.showMessageDialog(this, "이름을 입력하세요.");
                name.requestFocus();
                return;
            }
            if (em.isEmpty()) {
                JOptionPane.showMessageDialog(this, "이메일을 입력하세요.");
                email.requestFocus();
                return;
            }
            if (pw.isEmpty()) {
                JOptionPane.showMessageDialog(this, "비밀번호를 입력하세요.");
                pass.requestFocus();
                return;
            }
            if (gd == null || gd.isBlank()) {
                JOptionPane.showMessageDialog(this, "성별을 선택하세요.");
                gender.requestFocus();
                return;
            }
            if (latStr.isEmpty() || lngStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "현재 위치(위도/경도)를 입력하거나 지도에서 선택하세요.");
                if (latStr.isEmpty()) latitudeField.requestFocus(); else longitudeField.requestFocus();
                return;
            }

            // 2) 숫자 및 범위 유효성 검사
            Double lat = parseDoubleOrNull(latStr);
            Double lng = parseDoubleOrNull(lngStr);
            if (lat == null || lng == null) {
                JOptionPane.showMessageDialog(this, "위도/경도는 숫자여야 합니다. 예) 위도 37.5665, 경도 126.9780");
                if (lat == null) latitudeField.requestFocus(); else longitudeField.requestFocus();
                return;
            }
            if (lat < -90 || lat > 90) {
                JOptionPane.showMessageDialog(this, "위도는 -90 ~ 90 사이여야 합니다.");
                latitudeField.requestFocus();
                return;
            }
            if (lng < -180 || lng > 180) {
                JOptionPane.showMessageDialog(this, "경도는 -180 ~ 180 사이여야 합니다.");
                longitudeField.requestFocus();
                return;
            }

            // (선택) 아주 간단한 이메일 형태 체크
            if (!em.contains("@") || !em.contains(".")) {
                JOptionPane.showMessageDialog(this, "이메일 형식을 확인해주세요.");
                email.requestFocus();
                return;
            }

            // 3) 비밀번호 해시 후 VO 구성
            String hashed = PasswordUtil.sha256(pw);

            UserVO v = new UserVO(nm, em, hashed, gd);
            v.setLatitude(lat);
            v.setLongitude(lng);

            // 4) 저장
            UserDAO dao = new JDBCUserDAO();
            int rows = dao.insert(v);
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "가입 완료!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "가입 실패");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "가입 실패: " + ex.getMessage());
        }
    }

    private static Double parseDoubleOrNull(String s) {
        if (s == null || s.isEmpty()) return null;
        try { return Double.valueOf(s); } catch (Exception e) { return null; }
    }

    //스타일 유틸
    static final class Theme {
        static final Color BRAND    = new Color(255, 140, 66);
        static final Color BRAND_DK = new Color(230, 110, 40);
        static final Color BG       = new Color(246, 247, 249);

        static Font h1Font(Component c) { return c.getFont().deriveFont(Font.BOLD, 22f); }
        static JLabel h1(String text) { JLabel l = new JLabel(text); l.setFont(h1Font(l)); l.setForeground(new Color(40,40,40)); return l; }
        static JLabel labelRight(String t){ JLabel l=new JLabel(t,SwingConstants.RIGHT); l.setPreferredSize(new Dimension(90, 26)); return l; }
        static JComponent input(JComponent comp){
            comp.setPreferredSize(new Dimension(280, 34));
            comp.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220,220,220)),
                BorderFactory.createEmptyBorder(6,8,6,8)
            ));
            return comp;
        }
        static GridBagConstraints gbc(){ GridBagConstraints c = new GridBagConstraints(); c.fill = GridBagConstraints.HORIZONTAL; c.weightx=1; return c; }
    }

    static JPanel wrapCard(JPanel inner){
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setBackground(Theme.BG);
        inner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(235,235,235)),
                BorderFactory.createEmptyBorder(18,18,18,18)
        ));
        wrap.add(inner, new GridBagConstraints());
        return wrap;
    }

    static class GradientBar extends JPanel{
        private static final long serialVersionUID = 1L;
		private final String text;
        GradientBar(String t){ this.text=t; setOpaque(false); }
        
        @Override protected void paintComponent(Graphics g){
            Graphics2D g2=(Graphics2D)g.create();
            int w=getWidth(),h=getHeight();
            g2.setPaint(new GradientPaint(0,0,new Color(255,154,84), w, h, new Color(255,209,148)));
            g2.fillRect(0,0,w,h);
            g2.setColor(new Color(255,255,255,230));
            g2.setFont(getFont().deriveFont(Font.BOLD,16f));
            g2.drawString(text, 16, h-18);
            g2.dispose();
        }
    }

    static class RoundedButton extends JButton{
        private static final long serialVersionUID = 1L;
		RoundedButton(String t){ super(t);
            setForeground(new Color(70,70,70));
            setBackground(new Color(245,245,245));
            setFocusPainted(false); setContentAreaFilled(false); setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(10,18,10,18));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
        @Override protected void paintComponent(Graphics g){
            Graphics2D g2=(Graphics2D)g.create();
            int w=getWidth(),h=getHeight();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0,0,w,h,14,14);
            super.paintComponent(g2);
            g2.dispose();
        }
    }

    static class RoundedButtonPrimary extends RoundedButton{
        private static final long serialVersionUID = 1L;
		RoundedButtonPrimary(String t){ super(t); setForeground(Color.WHITE); setBackground(Theme.BRAND); }
		
        @Override protected void paintComponent(Graphics g){
            Graphics2D g2=(Graphics2D)g.create();
            int w=getWidth(),h=getHeight();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp=new GradientPaint(0,0,Theme.BRAND,0,h,Theme.BRAND_DK);
            g2.setPaint(gp); g2.fillRoundRect(0,0,w,h,14,14);
            super.paintComponent(g2); g2.dispose();
        }
    }
}