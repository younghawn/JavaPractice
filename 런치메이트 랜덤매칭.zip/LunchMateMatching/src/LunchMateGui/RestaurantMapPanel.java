package LunchMateGui;

import LunchMateUser.UserVO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import LunchMateRestaurant.RestaurantDAO;
import LunchMateRestaurant.RestaurantVO;

import java.awt.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

// JavaFX 임포트 (JFXPanel로 WebView 임베드)
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

// ★ JS ↔ Java 브릿지용
import netscape.javascript.JSObject;


//  맛집 지도 패널 (카카오 지도 JS SDK 사용)
//  JFXPanel 안에 WebView를 임베드하여 HTML/JS 로드
//  RestaurantDAO에서 받아온 데이터로 마커 생성

public class RestaurantMapPanel extends JPanel {

    private static final long serialVersionUID = 1L;

    // UI
    private final JTextField tfCenterLat = new JTextField(10);
    private final JTextField tfCenterLng = new JTextField(10);
    private final JSpinner spRadiusKm   = new JSpinner(new SpinnerNumberModel(2.0, 0.3, 20.0, 0.1));
    private final JButton btnReload     = new JButton("새로고침");
    private final JFXPanel fxPanel      = new JFXPanel();

    // 상태
    private final RestaurantDAO dao;      // DB 접근 (구현 주입)
    private final UserVO currentUser;
    private volatile WebEngine webEngine; // FX Thread에서 접근

    public RestaurantMapPanel(UserVO user, RestaurantDAO dao) {
        this.currentUser = user;
        this.dao = dao;

        setLayout(new BorderLayout());
        setOpaque(true);

        add(buildHeader(), BorderLayout.NORTH);
        add(buildBody(), BorderLayout.CENTER);

        // 초기 중심 좌표 설정: UserVO → 없으면 솔데스크
        double centerLat = (currentUser != null && currentUser.getLatitude()  != null) ? currentUser.getLatitude()  : 37.5705;
        double centerLng = (currentUser != null && currentUser.getLongitude() != null) ? currentUser.getLongitude() : 126.9832;
        tfCenterLat.setText(String.valueOf(centerLat));
        tfCenterLng.setText(String.valueOf(centerLng));

        // JavaFX 초기화 및 첫 렌더링
        initFXAndLoad(centerLat, centerLng, ((Number) spRadiusKm.getValue()).doubleValue());
        wireActions();
    }

    private JComponent buildHeader() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBorder(new EmptyBorder(10, 12, 10, 12));

        JLabel title = new JLabel("📍맛집 지도");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        bar.add(title, BorderLayout.WEST);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        controls.add(new JLabel("위도"));
        controls.add(tfCenterLat);
        controls.add(new JLabel("경도"));
        controls.add(tfCenterLng);
        controls.add(new JLabel("반경(km)"));
        ((JSpinner.NumberEditor) spRadiusKm.getEditor()).getTextField().setColumns(4);
        controls.add(spRadiusKm);
        controls.add(btnReload);
        bar.add(controls, BorderLayout.EAST);

        return bar;
    }

    private JComponent buildBody() {
        JPanel p = new JPanel(new BorderLayout());
        p.add(fxPanel, BorderLayout.CENTER);
        return p;
    }

    private void wireActions() {
        btnReload.addActionListener(e -> {
            Double lat = parseD(tfCenterLat.getText());
            Double lng = parseD(tfCenterLng.getText());
            double rkm = ((Number) spRadiusKm.getValue()).doubleValue();
            if (lat == null || lng == null) {
                JOptionPane.showMessageDialog(this, "위도/경도를 올바르게 입력하세요.");
                return;
            }
            reloadMap(lat, lng, rkm);
        });
    }

    private void initFXAndLoad(double centerLat, double centerLng, double radiusKm) {
        Platform.setImplicitExit(false);
        Platform.runLater(() -> {
            WebView webView = new WebView();
            webEngine = webView.getEngine();
            fxPanel.setScene(new Scene(webView));

            // ★ 페이지 로드 완료 시 JS 브릿지(window.javaBridge) 등록
            webEngine.getLoadWorker().stateProperty().addListener((obs, o, s) -> {
                switch (s) {
                    case SUCCEEDED -> {
                        try {
                            JSObject win = (JSObject) webEngine.executeScript("window");
                            win.setMember("javaBridge", new JsBridge()); // JS에서 window.javaBridge 로 접근
                        } catch (Throwable ignore) {}
                    }
                    default -> {}
                }
            });

            loadHtmlIntoWebView(centerLat, centerLng, radiusKm);
        });
    }

    private void reloadMap(double centerLat, double centerLng, double radiusKm) {
        Platform.runLater(() -> loadHtmlIntoWebView(centerLat, centerLng, radiusKm));
    }

    /** DAO에서 맛집 데이터를 로딩하여 HTML을 생성하고 WebView에 로드 */
    private void loadHtmlIntoWebView(double centerLat, double centerLng, double radiusKm) {
        try {
            // 사용자별 데이터만 조회
            int uid = (currentUser != null && currentUser.getId() != null) ? currentUser.getId() : 0;

            List<RestaurantVO> restaurants;
            try {
                restaurants = dao.findNearByUser(uid, centerLat, centerLng, radiusKm);
            } catch (UnsupportedOperationException uoe) {
                restaurants = dao.findAllByUser(uid);
            }

            // 2) 카카오 JS 키
            String kakaoJsKey = firstNonBlank(System.getenv("KAKAO_JS_KEY"), System.getProperty("KAKAO_JS_KEY"));
            if (kakaoJsKey == null || kakaoJsKey.isBlank()) {
                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(
                        this,
                        "KAKAO_JS_KEY 환경변수(또는 VM옵션 -DKAKAO_JS_KEY)가 설정되어 있지 않습니다.",
                        "카카오 키 필요",
                        JOptionPane.WARNING_MESSAGE
                ));
            }

            // 3) HTML 만들기 & 로드
            String html = buildKakaoMapHtml(kakaoJsKey, centerLat, centerLng, radiusKm, restaurants);
            webEngine.loadContent(html, "text/html");
        } catch (Exception ex) {
            ex.printStackTrace();
            SwingUtilities.invokeLater(() ->
                JOptionPane.showMessageDialog(this, "지도를 불러오는 중 오류: " + ex.getMessage(),
                        "오류", JOptionPane.ERROR_MESSAGE));
        }
    }

    /** 카카오 JS SDK만 사용하는 HTML 작성 */
    private String buildKakaoMapHtml(String kakaoJsKey,
                                     double centerLat,
                                     double centerLng,
                                     double radiusKm,
                                     List<RestaurantVO> data) {
        String safeKey = (kakaoJsKey == null ? "" : kakaoJsKey.trim());

        // 레스토랑 목록을 JS 객체 배열로 직렬화
        StringBuilder jsArray = new StringBuilder("[");
        boolean first = true;
        for (RestaurantVO r : data) {
            if (r == null) continue;
            Double lat = r.getLatitude();
            Double lng = r.getLongitude();
            if (lat == null || lng == null) continue;

            if (!first) jsArray.append(",");
            first = false;

            jsArray.append("{")
                  .append(kv("id", r.getId()))
                  .append(kv("name", r.getName(), true))
                  .append(kv("address", r.getAddress(), true))
                  .append(kv("lat", lat))
                  .append(kv("lng", lng))
                  .append("}");
        }
        jsArray.append("]");

        String html = """
            <!doctype html>
            <html lang="ko">
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <title>맛집 지도</title>
              <style>
                html, body { height:100%; margin:0; }
                #map { width:100%; height:100%; }

                /* ===== 네이버 스타일 말풍선 라벨 ===== */
                .place {
                  position: relative;
                  background: #ffffff;
                  border: 1px solid #dfe3e8;
                  border-radius: 14px;
                  padding: 10px 14px 10px 44px;
                  box-shadow: 0 6px 16px rgba(0,0,0,0.12);
                  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, 'Apple SD Gothic Neo', 'Noto Sans KR', '맑은 고딕', 'Malgun Gothic', sans-serif;
                  color: #222;
                  white-space: nowrap;
                  transform: translateY(-14px);
                  cursor: pointer;
                }
                .place:after{
                  content:"";
                  position:absolute; left:22px; bottom:-8px;
                  width: 0; height: 0;
                  border-left:8px solid transparent;
                  border-right:8px solid transparent;
                  border-top:8px solid #ffffff;
                  filter: drop-shadow(0 -1px 0 #dfe3e8);
                }
                .place .icon {
                  position:absolute; left:10px; top:50%;
                  width:24px; height:24px; margin-top:-12px;
                  border-radius:50%;
                  background:#1976d2;
                  display:flex; align-items:center; justify-content:center;
                  color:#fff; font-size:14px; font-weight:bold;
                }
                .place .title { font-weight:700; font-size:15px; line-height:1.2; }
                .place .addr  { margin-top:2px; font-size:12px; color:#6b7280; }
                .place.hover  { box-shadow: 0 10px 24px rgba(0,0,0,0.18); transform: translateY(-16px) scale(1.02); }

                .legend {
                  position:absolute; left:10px; bottom:10px;
                  background: rgba(255,255,255,.9);
                  border:1px solid #e5e7eb; border-radius:8px;
                  padding:6px 10px; font-size:12px; color:#374151;
                }
              </style>
              %KAKAO_SDK%
            </head>
            <body>
              <div id="map"></div>
              <div class="legend">반경 %RADIUS_KM% km · 지도를 클릭해 새 식당을 등록하세요</div>
              <script>
                // 모든 초기화를 Kakao SDK 로드 이후에 실행
                kakao.maps.load(function(){
                  const CENTER = { lat: %CLAT%, lng: %CLNG% };
                  const RADIUS_M = %RADIUS_M%;
                  const ITEMS = %ITEMS%;

                  const map = new kakao.maps.Map(document.getElementById('map'), {
                    center: new kakao.maps.LatLng(CENTER.lat, CENTER.lng),
                    level: 5
                  });

                  // 중심 마커(작게)
                  new kakao.maps.Marker({ position: new kakao.maps.LatLng(CENTER.lat, CENTER.lng), map: map });

                  // 반경 원
                  const circle = new kakao.maps.Circle({
                    center: new kakao.maps.LatLng(CENTER.lat, CENTER.lng),
                    radius: RADIUS_M,
                    strokeWeight: 2, strokeColor: '#FF9800', strokeOpacity: 0.9, strokeStyle: 'dash',
                    fillColor: '#FFB74D', fillOpacity: 0.15
                  });
                  circle.setMap(map);

                  // bounds 맞추기
                  const bounds = new kakao.maps.LatLngBounds();
                  bounds.extend(new kakao.maps.LatLng(CENTER.lat, CENTER.lng));

                  // 라벨(커스텀 오버레이) 생성 — 클릭 시 지도 중앙으로 이동
                  ITEMS.forEach(item => {
                    const pos = new kakao.maps.LatLng(item.lat, item.lng);
                    const html =
                      '<div class="place" onclick="focusPlace(' + item.lat + ',' + item.lng + ')" ' +
                      '     onmouseenter="hoverOn(this)" onmouseleave="hoverOff(this)">' +
                        '<div class="icon">🍽</div>' +
                        '<div class="title">' + escapeHtml(item.name || "(이름없음)") + '</div>' +
                        '<div class="addr">' + escapeHtml(item.address || "") + '</div>' +
                      '</div>';

                    const overlay = new kakao.maps.CustomOverlay({ position: pos, content: html, yAnchor: 1, zIndex: 3 });
                    overlay.setMap(map);
                    bounds.extend(pos);
                  });

                  if (ITEMS.length > 0) map.setBounds(bounds, 40, 40, 40, 40);

                  // ===== 안정화 로직: 드래그/줌 중 클릭 무시 & 줌 직후 쿨다운 =====
                  let isDragging = false;
                  let suppressClickUntil = 0; // Date.now() 기준

                  kakao.maps.event.addListener(map, 'dragstart', function(){ isDragging = true; });
                  kakao.maps.event.addListener(map, 'dragend',   function(){ isDragging = false; });
                  kakao.maps.event.addListener(map, 'zoom_changed', function(){
                    suppressClickUntil = Date.now() + 250; // 줌 직후 250ms 동안 클릭 무시
                  });

                  // ===== 지도 클릭 → 임시 마커 + Java로 좌표 전달(재시도 포함) =====
                  let tempMarker = null;
                  kakao.maps.event.addListener(map, 'click', function(e){
                    // 드래그 중이거나 줌 직후에는 무시
                    if (isDragging || Date.now() < suppressClickUntil) return;

                    const ll = e.latLng;
                    if (tempMarker) tempMarker.setMap(null);
                    tempMarker = new kakao.maps.Marker({ position: ll, map: map, draggable: false });

                    // 브릿지 호출은 약간의 지연 + 재시도
                    safeNotifyJava(ll.getLat(), ll.getLng(), 0);
                  });

                  // 헬퍼(UI)
                  window.hoverOn  = function(el){ el.classList.add('hover'); }
                  window.hoverOff = function(el){ el.classList.remove('hover'); }

                  // 말풍선 클릭 시 지도 중앙으로 이동
                  window.focusPlace = function(lat, lng){
                    const p = new kakao.maps.LatLng(lat, lng);
                    map.panTo(p);
                  }

                  // JS → Java 브릿지 안정 호출(최대 10회, 80ms 간격)
                  window.safeNotifyJava = function(lat, lng, retry){
                    try {
                      if (window.javaBridge && typeof window.javaBridge.onMapClick === 'function') {
                        // 작은 지연을 주어 WebView/EDT 타이밍 안정화
                        return setTimeout(function(){ window.javaBridge.onMapClick(lat, lng); }, 0);
                      }
                    } catch (e) { /* ignore */ }
                    if (retry < 10) {
                      setTimeout(function(){ safeNotifyJava(lat, lng, retry + 1); }, 80);
                    }
                  }

                  function escapeHtml(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
                }); // kakao.maps.load end
              </script>
            </body>
            </html>
            """;

        String sdkTag = safeKey.isEmpty()
                ? "<!-- KAKAO_JS_KEY 미설정: 스크립트를 로드하지 않습니다. -->"
                : "<script type=\"text/javascript\" src=\"https://dapi.kakao.com/v2/maps/sdk.js?appkey="
                  + urlEnc(safeKey) + "&autoload=false\"></script>";

        html = html.replace("%KAKAO_SDK%", sdkTag)
                   .replace("%CLAT%", String.valueOf(centerLat))
                   .replace("%CLNG%", String.valueOf(centerLng))
                   .replace("%RADIUS_M%", String.valueOf(Math.round(radiusKm * 1000.0)))
                   .replace("%RADIUS_KM%", String.valueOf(radiusKm))
                   .replace("%ITEMS%", jsArray.toString());

        return html;
    }

    //JS → Java 브릿지: 지도 클릭 시 호출됨
    public final class JsBridge {
        // JavaFX WebView가 이 public 메서드를 찾아 호출함
        public void onMapClick(double lat, double lng) {
            SwingUtilities.invokeLater(() -> openAddDialog(lat, lng));
        }
    }
    //사용자가 맛집등록을 할때 될때가 있고, 안될떄가 있는 이유,
    
    // 지도 클릭 이벤트가 드래그·확대/축소 중이거나 WebView-Java 브릿지 타이밍이 꼬일 때 다이얼로그 호출이 무시돼서,
    // 등록창이 나올 때도 있고 안 나올 때도 있는 거예요.

    //좌표 받아서 식당 입력 다이얼로그 띄우고 DB 저장
    private void openAddDialog(double lat, double lng) {
        JTextField tfName = new JTextField(20);
        JTextField tfMenu = new JTextField(20);
        JTextField tfAddr = new JTextField(24);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4,4,4,4);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx=0; c.gridy=0; form.add(new JLabel("식당명"), c);
        c.gridx=1; form.add(tfName, c);
        c.gridx=0; c.gridy=1; form.add(new JLabel("메뉴"), c);
        c.gridx=1; form.add(tfMenu, c);
        c.gridx=0; c.gridy=2; form.add(new JLabel("주소"), c);
        c.gridx=1; form.add(tfAddr, c);
        c.gridx=0; c.gridy=3; form.add(new JLabel("위도"), c);
        c.gridx=1; form.add(new JLabel(String.valueOf(lat)), c);
        c.gridx=0; c.gridy=4; form.add(new JLabel("경도"), c);
        c.gridx=1; form.add(new JLabel(String.valueOf(lng)), c);

        int ok = JOptionPane.showConfirmDialog(this, form, "새 맛집 등록", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (ok != JOptionPane.OK_OPTION) return;

        String name = tfName.getText().trim();
        String menu = tfMenu.getText().trim();
        String addr = tfAddr.getText().trim();
        if (name.isEmpty() || menu.isEmpty() || addr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "식당명/메뉴/주소를 모두 입력하세요.");
            return;
        }
        if (currentUser == null || currentUser.getId() == null) {
            JOptionPane.showMessageDialog(this, "로그인 정보가 없어 저장할 수 없습니다.");
            return;
        }

        try {
            RestaurantVO vo = new RestaurantVO();
            vo.setUserId(currentUser.getId());//유저별 저장
            vo.setName(name);
            vo.setMenu(menu);
            vo.setAddress(addr);
            vo.setLatitude(lat);
            vo.setLongitude(lng);

            int rows = dao.insert(vo);
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "저장되었습니다!");
                // 현재 중심/반경으로 리로드
                Double clat = parseD(tfCenterLat.getText());
                Double clng = parseD(tfCenterLng.getText());
                double rkm = ((Number) spRadiusKm.getValue()).doubleValue();
                if (clat != null && clng != null) reloadMap(clat, clng, rkm);
            } else {
                JOptionPane.showMessageDialog(this, "저장 실패(변경 없음)");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "저장 실패: " + ex.getMessage());
        }
    }

    // ----- 문자열 유틸 -----
    private static String kv(String key, Object val) {
        return "\"" + esc(key) + "\":" + (val == null ? "null" : String.valueOf(val)) + ",";
    }
    private static String kv(String key, String val, boolean quote) {
        String v = (val == null ? "" : val);
        return "\"" + esc(key) + "\":" + (quote ? "\"" + esc(v) + "\"" : esc(v)) + ",";
    }
    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
    private static String urlEnc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }
    private static Double parseD(String s) {
        try { return Double.valueOf(s.trim()); } catch (Exception e) { return null; }
    }
    private static String firstNonBlank(String a, String b) {
        return (a != null && !a.isBlank()) ? a : (b != null && !b.isBlank() ? b : null);
    }
}