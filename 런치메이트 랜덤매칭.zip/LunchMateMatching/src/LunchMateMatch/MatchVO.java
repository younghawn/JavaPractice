package LunchMateMatch;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;


//matches 테이블 VO
 
public class MatchVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    private LocalDate matchDate;    
    private String timeSlot;        
    private String region;          
    private Integer userIdA;        
    private Integer userIdB;        
    private Integer userIdC;        //3인 매칭일때만
    private Integer groupSize;      //group_size (2 or 3)
    private String menu;            
    private LocalDateTime createdAt;

    public MatchVO() {}

    public MatchVO(LocalDate matchDate, String timeSlot, String region,
                   Integer userIdA, Integer userIdB, Integer userIdC,
                   Integer groupSize, String menu) {
        this.matchDate = matchDate;
        this.timeSlot = timeSlot;
        this.region = region;
        this.userIdA = userIdA;
        this.userIdB = userIdB;
        this.userIdC = userIdC;
        this.groupSize = groupSize;
        this.menu = menu;
    }

    // 게터/세터 
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public LocalDate getMatchDate() { return matchDate; }
    public void setMatchDate(LocalDate matchDate) { this.matchDate = matchDate; }

    public String getTimeSlot() { return timeSlot; }
    public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public Integer getUserIdA() { return userIdA; }
    public void setUserIdA(Integer userIdA) { this.userIdA = userIdA; }

    public Integer getUserIdB() { return userIdB; }
    public void setUserIdB(Integer userIdB) { this.userIdB = userIdB; }

    public Integer getUserIdC() { return userIdC; }
    public void setUserIdC(Integer userIdC) { this.userIdC = userIdC; }

    public Integer getGroupSize() { return groupSize; }
    public void setGroupSize(Integer groupSize) { this.groupSize = groupSize; }

    public String getMenu() { return menu; }
    public void setMenu(String menu) { this.menu = menu; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MatchVO)) return false;
        MatchVO m = (MatchVO) o;
        return Objects.equals(id, m.id);
    }
    @Override public int hashCode() { return Objects.hash(id); }
}