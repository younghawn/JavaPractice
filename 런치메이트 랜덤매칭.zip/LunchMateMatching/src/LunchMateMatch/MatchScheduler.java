package LunchMateMatch;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


// 	매칭 스케줄러 (기본: 1분 주기)
//  매 1분마다 오늘의 모든 슬롯을 순회 
//  이미 종료된 슬롯은 스킵
//  같은 날 같은 슬롯의 중복 생성을 막기 위해 processedToday 캐시 사용
//  MatchingService.run(…) 호출로 반경 기반 매칭 생성
//  before/after count로 신규 생성 개수 로그

public class MatchScheduler {

    private static final String[] SLOTS = {
        "11:00-11:30","11:30-12:00","12:00-12:30",
        "12:30-13:00","13:00-13:30","13:30-14:00"
    };
    
    //스케쥴러 주기 1분 
    private static final long PERIOD_MINUTES = 1L;

    private final double centerLat;
    private final double centerLng;
    private final double radiusKm;

    private final MatchingService service;
    //단일스레드
    private final ScheduledExecutorService ses =
        Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "match-scheduler");
            t.setDaemon(true);
            return t;
        });
    
    //중복실행 방지용 캐시
    private final Set<String> processedToday = new HashSet<>();
    private LocalDate processedDate = LocalDate.now();

    public MatchScheduler(MatchingService service,
                          double centerLat,
                          double centerLng,
                          double radiusKm) {
        this.service   = service;
        this.centerLat = centerLat;
        this.centerLng = centerLng;
        this.radiusKm  = radiusKm;
    }

    public void start() {
        ses.scheduleWithFixedDelay(this::tick, 0, PERIOD_MINUTES, TimeUnit.MINUTES);
        
    }

    public void stop() {
        ses.shutdownNow();
        
    }
    
    //주기적으로 호출 
    private void tick() {
        try {
            final LocalDate today = LocalDate.now();
            final LocalTime now   = LocalTime.now();

            resetCacheIfDateChanged(today);

            for (String slot : SLOTS) {
                if (!shouldAttemptSlot(today, now, slot)) {
                    continue; // 지난 슬롯 또는 이미 생성됨
                }
                processSlot(today, slot);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //날짜가 바뀌면 캐시 초기화
    private void resetCacheIfDateChanged(LocalDate today) {
        if (!today.equals(processedDate)) {
            processedDate = today;
            processedToday.clear();
        }
    }
    
    //특정슬롯을 시도해야될지 판단 
    private boolean shouldAttemptSlot(LocalDate today, LocalTime now, String slot) {
        if (isPastSlot(now, slot)) {
            return false; // 이미 끝난 슬롯
        }
        String key = slotKey(today, slot);
        return !processedToday.contains(key);
    }
    
    //실제슬롯처리
    private void processSlot(LocalDate today, String slot) {
        String key = slotKey(today, slot);
        try {
            int before = safeCountMatches(today, slot);
            

            service.run(today, slot, centerLat, centerLng, radiusKm);

            int after  = safeCountMatches(today, slot);
            int created = Math.max(0, after - before);
            

            if (created > 0) processedToday.add(key);
        } catch (Exception e) { 
            e.printStackTrace();
        }
    }
    
    //현재시간 슬롯이 이미 종료되었는지 확인
    private boolean isPastSlot(LocalTime now, String slot) {
        LocalTime end = parseSlotEnd(slot);
        return now.isAfter(end);
    }
    
    //날짜형태 캐시키
    private String slotKey(LocalDate date, String slot) {
        return date + "|" + slot;
    }
    
    //
    private LocalTime parseSlotEnd(String slot) {
        String[] parts = slot.split("-");
        return LocalTime.parse(parts[1]);
    }
    
    //매칭수를 안전하게 조회
    private int safeCountMatches(LocalDate date, String slot) {
        try {
            return service.countMatches(date, slot);
        } catch (Throwable ignore) {
            return 0;
        }
    }
}