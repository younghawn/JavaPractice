package LunchMateMatch;

import LunchMateConnInfo.ConnectionManager;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class JDBCMatchDAO implements MatchDAO {
	
	//매칭 데이터 등록
    @Override
    public int insert(MatchVO vo) throws Exception {
        String sql = "INSERT INTO matches(match_date,time_slot,region,user_id_a,user_id_b,user_id_c,group_size,menu) " +
                     "VALUES (?,?,?,?,?,?,?,?)";
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setDate(1, Date.valueOf(vo.getMatchDate()));
            ps.setString(2, vo.getTimeSlot());
            ps.setString(3, vo.getRegion());
            ps.setInt(4, vo.getUserIdA());
            ps.setInt(5, vo.getUserIdB());
            if (vo.getUserIdC() != null) ps.setInt(6, vo.getUserIdC());
            else ps.setNull(6, Types.INTEGER);
            ps.setInt(7, vo.getGroupSize());
            ps.setString(8, vo.getMenu());

            int n = ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) vo.setId(keys.getInt(1));
            }
            return n;
        }
    }
    
    //매칭 목록 조회(날짜,시간)
    @Override
    public List<MatchVO> findByDateSlot(LocalDate date, String timeSlot) throws Exception {
        String sql = "SELECT * FROM matches WHERE match_date=? AND time_slot=? ORDER BY id DESC";
        List<MatchVO> list = new ArrayList<>();
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            ps.setString(2, timeSlot);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }
    
    //매칭 취소
    @Override
    public int deleteById(int id) throws Exception {
    	String sql = "DELETE FROM matches WHERE id=?";
        try (Connection c = ConnectionManager.getConnection();
        		PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    //매칭개수 카운트
    @Override
    public int countByDateSlot(LocalDate date, String timeSlot) throws Exception {
        String sql = "SELECT COUNT(*) FROM matches WHERE match_date=? AND time_slot=?";
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            ps.setString(2, timeSlot);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // ---------- 내부 매핑 ----------
    private MatchVO map(ResultSet rs) throws SQLException {
        MatchVO v = new MatchVO();
        v.setId(rs.getInt("id"));
        v.setMatchDate(rs.getDate("match_date").toLocalDate());
        v.setTimeSlot(rs.getString("time_slot"));
        v.setRegion(rs.getString("region"));
        v.setUserIdA(rs.getInt("user_id_a"));
        v.setUserIdB(rs.getInt("user_id_b"));
        int c = rs.getInt("user_id_c");
        v.setUserIdC(rs.wasNull() ? null : c);
        v.setGroupSize(rs.getInt("group_size"));
        v.setMenu(rs.getString("menu"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) v.setCreatedAt(ts.toLocalDateTime());
        return v;
    }
}