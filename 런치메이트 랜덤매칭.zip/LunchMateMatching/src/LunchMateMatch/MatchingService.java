package LunchMateMatch;

import LunchMateParticipation.ParticipationDAO;
import LunchMateParticipation.ParticipationVO;

//이메일 발송 기능
import LunchMateNotification.EmailService;

import java.time.LocalDate;
import java.util.*;

public class MatchingService {

    private final ParticipationDAO participationDAO;
    private final MatchDAO matchDAO;
    private final Random rand = new Random();

    //이메일 서비스(주입 받으면 발송/로그까지 수행)
    private final EmailService emailService;

    // 기존 생성자 유지(이메일 없음: 순정)
    public MatchingService(ParticipationDAO participationDAO, MatchDAO matchDAO) {
        this(participationDAO, matchDAO, null);
    }

    //이메일 서비스 주입용 생성자
    public MatchingService(ParticipationDAO participationDAO, MatchDAO matchDAO, EmailService emailService) {
        this.participationDAO = participationDAO;
        this.matchDAO = matchDAO;
        this.emailService = emailService;
    }
    
    //매칭 개수조회 
    public int countMatches(LocalDate date, String timeSlot) throws Exception {
        return matchDAO.countByDateSlot(date, timeSlot);
    }
    
    //매칭 실행
    public List<MatchVO> run(LocalDate date,
                             String timeSlot,
                             double centerLat,
                             double centerLng,
                             double radiusKm) throws Exception {
    	//해당 날짜·슬롯·반경 내 참가자 조회
        List<ParticipationVO> candidates =
                participationDAO.findByDateSlotNear(date, timeSlot, centerLat, centerLng, radiusKm);
        
        //후보자가 2명 미만이면 매칭 불가
        if (candidates == null || candidates.size() < 2) {
            return Collections.emptyList();
        }
        //랜덤 무작위 매칭
        Collections.shuffle(candidates, rand);

        List<MatchVO> created = new ArrayList<>();
        String regionText = String.format("center(%.6f,%.6f)±%.1fkm", centerLat, centerLng, radiusKm);
        
        //2~3명 그룹매칭
        for (int i = 0; i < candidates.size(); ) {
            ParticipationVO a = candidates.get(i++);
            if (i >= candidates.size()) break;
            ParticipationVO b = candidates.get(i++);
            ParticipationVO c = (i < candidates.size()) ? candidates.get(i++) : null;

            String menu = pickMenuRandom();
            MatchVO m = new MatchVO(
                    date, timeSlot, regionText,
                    a.getUserId(), b.getUserId(),
                    (c != null ? c.getUserId() : null),
                    (c != null ? 3 : 2),
                    menu
            );

            int matchId = matchDAO.insert(m); //생성된 match PK
            created.add(m);

            // 이메일 서비스가 주입되어 있으면 발송 + email_notifications 기록
            if (emailService != null && matchId > 0) {
                try {
                    emailService.sendMatchEmails(matchId);
                } catch (Exception ex) {
                    System.err.println("[MatchingService] email send failed for matchId=" + matchId + " : " + ex);
                    ex.printStackTrace();
                }
            }
        }
        return created;
    }
    //랜덤 메뉴 추천 
    private String pickMenuRandom() {
        String[] menus = {"김치찌개","비빔밥","돈카츠","파스타","샐러드","햄버거","우동","초밥","삼계탕","회","양꼬치","삼겹살","소고기","떡볶이"};
        return menus[rand.nextInt(menus.length)];
    }
}