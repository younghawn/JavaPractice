package LunchMateMatch;

import java.time.LocalDate;
import java.util.List;

public interface MatchDAO {
	
	//매칭 정보 등록
	int insert(MatchVO vo) throws Exception;
	
	//특정 날짜 + 시간 슬롯에 해당하는 매칭들 조회
    List<MatchVO> findByDateSlot(LocalDate date, String timeSlot) throws Exception;
    
    //매칭 취소. 
    int deleteById(int id) throws Exception;

    // 날짜+슬롯 기준 매칭 수 조회
    int countByDateSlot(LocalDate date, String timeSlot) throws Exception;
    
}
