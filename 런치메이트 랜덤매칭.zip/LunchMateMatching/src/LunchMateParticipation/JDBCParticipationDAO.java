package LunchMateParticipation;

import LunchMateConnInfo.ConnectionManager;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class JDBCParticipationDAO implements ParticipationDAO {

    @Override
    public int insert(ParticipationVO vo) throws Exception {
        String sql = "INSERT INTO participations(user_id,participation_date,time_slot,region) VALUES (?,?,?,?)";
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, vo.getUserId());
            ps.setDate(2, Date.valueOf(vo.getParticipationDate()));
            ps.setString(3, vo.getTimeSlot());
            ps.setString(4, vo.getRegion());
            int updated = ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) vo.setId(keys.getInt(1));
            }
            return updated;
        }
    }

    @Override
    public boolean existsByUserDateSlot(int userId, LocalDate date, String timeSlot) throws Exception {
        String sql = "SELECT 1 FROM participations WHERE user_id=? AND participation_date=? AND time_slot=? LIMIT 1";
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setDate(2, Date.valueOf(date));
            ps.setString(3, timeSlot);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    @Override
    public List<ParticipationVO> findByUser(int userId) throws Exception {
        String sql = "SELECT * FROM participations WHERE user_id=? ORDER BY participation_date DESC, time_slot";
        List<ParticipationVO> list = new ArrayList<>();
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    @Override
    public List<ParticipationVO> findByDateSlotRegion(LocalDate date, String timeSlot, String region) throws Exception {
        String sql = "SELECT * FROM participations WHERE participation_date=? AND time_slot=? AND region=?";
        List<ParticipationVO> list = new ArrayList<>();
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            ps.setString(2, timeSlot);
            ps.setString(3, region);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    @Override
    public int deleteById(int id) throws Exception {
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM participations WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    // 날짜/슬롯 + 중심좌표 반경 km 내 후보 조회 (users 좌표 조인 + Haversine)하버사인 공식
    // VO를 바꾸지 않기 위해 거리/좌표는 SELECT에만 사용하고 매핑은 participations 컬럼만 사용
    // sql 쿼리를 좌표로 부터 반경계산(3km)
    @Override
    public List<ParticipationVO> findByDateSlotNear(LocalDate date,
                                                    String timeSlot,
                                                    double centerLat,
                                                    double centerLng,
                                                    double radiusKm) throws Exception {
        // MySQL Haversine (km)
        String sql =
            "SELECT p.*," +
            "       (6371 * ACOS( " +
            "           COS(RADIANS(?)) * COS(RADIANS(u.latitude)) * " +
            "           COS(RADIANS(u.longitude) - RADIANS(?)) + " +
            "           SIN(RADIANS(?)) * SIN(RADIANS(u.latitude)) " +
            "       )) AS distance_km " +
            "FROM participations p " +
            "JOIN users u ON u.id = p.user_id " +
            "WHERE p.participation_date = ? " +
            "  AND p.time_slot = ? " +
            "  AND u.latitude IS NOT NULL " +
            "  AND u.longitude IS NOT NULL " +
            "HAVING distance_km <= ? " +
            "ORDER BY distance_km ASC, p.participated_at ASC";

        List<ParticipationVO> list = new ArrayList<>();
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            // 중심점 파라미터 (lat, lng, lat)
            ps.setDouble(1, centerLat);
            ps.setDouble(2, centerLng);
            ps.setDouble(3, centerLat);
            // 날짜/슬롯
            ps.setDate(4, Date.valueOf(date));
            ps.setString(5, timeSlot);
            // 반경(km)
            ps.setDouble(6, radiusKm);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    // distance_km은 SELECT/HAVING에서만 사용, VO에는 넣지 않음
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    // ===== 내부 매핑 =====
    private ParticipationVO map(ResultSet rs) throws SQLException {
        ParticipationVO v = new ParticipationVO();
        v.setId(rs.getInt("id"));
        v.setUserId(rs.getInt("user_id"));
        Date d = rs.getDate("participation_date");
        if (d != null) v.setParticipationDate(d.toLocalDate());
        v.setTimeSlot(rs.getString("time_slot"));
        v.setRegion(rs.getString("region"));
        Timestamp t = rs.getTimestamp("participated_at");
        if (t != null) v.setParticipatedAt(t.toLocalDateTime());
        return v;
    }
}