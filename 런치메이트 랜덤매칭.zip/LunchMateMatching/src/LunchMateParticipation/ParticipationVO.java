package LunchMateParticipation;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;


// ParticipationVO → participations 테이블
//
//역할: 하루 중 특정 시간대에 점심을 함께할 의사를 등록한 신청 정보
//	 •매칭을 실행할 때, 참가자 리스트의 원본이 되는 데이터.
//
//주요 필드
//	•	id : PK
//	•	userId : 신청자(UserVO) FK
//	•	participationDate : 신청 날짜 (YYYY-MM-DD)
//	•	timeSlot : 신청 시간대 (예: 11:00-11:30)
//	•	region : 희망 지역(구/동 단위)
//	•	participatedAt : 실제 신청 버튼 누른 시각

//participations 테이블용 VO 
public class ParticipationVO implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	
	 private Integer id;
	 private Integer userId;
	 private LocalDate participationDate; 
	 private String timeSlot;            
	 private String region;               
	 private LocalDateTime participatedAt;
	
	 public ParticipationVO() {} // 
	
	 // Panel 등에서 insert 용도로 많이 쓰는 생성자
	 public ParticipationVO(Integer userId, LocalDate participationDate, String timeSlot, String region) {
	     this.userId = userId;
	     this.participationDate = participationDate;
	     this.timeSlot = timeSlot;
	     this.region = region;
	 }
	
	 public ParticipationVO(Integer id, Integer userId, LocalDate participationDate, String timeSlot,
	                        String region, LocalDateTime participatedAt) {
	     this.id = id;
	     this.userId = userId;
	     this.participationDate = participationDate;
	     this.timeSlot = timeSlot;
	     this.region = region;
	     this.participatedAt = participatedAt;
	 }
	
	 // 게터/세터
	 public Integer getId() { return id; }
	 public void setId(Integer id) { this.id = id; }
	
	 public Integer getUserId() { return userId; }
	 public void setUserId(Integer userId) { this.userId = userId; }
	
	 public LocalDate getParticipationDate() { return participationDate; }
	 public void setParticipationDate(LocalDate participationDate) { this.participationDate = participationDate; }
	
	 public String getTimeSlot() { return timeSlot; }
	 public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }
	
	 public String getRegion() { return region; }
	 public void setRegion(String region) { this.region = region; }
	
	 public LocalDateTime getParticipatedAt() { return participatedAt; }
	 public void setParticipatedAt(LocalDateTime participatedAt) { this.participatedAt = participatedAt; }
	
	 // equals/hashCode: (userId, date, slot) 기준
	 @Override
	 public boolean equals(Object o) {
	     if (this == o) return true;
	     if (!(o instanceof ParticipationVO)) return false;
	     ParticipationVO that = (ParticipationVO) o;
	     return Objects.equals(userId, that.userId)
	         && Objects.equals(participationDate, that.participationDate)
	         && Objects.equals(timeSlot, that.timeSlot);
	 }
	
	 @Override
	 public int hashCode() { return Objects.hash(userId, participationDate, timeSlot); }
	
	 
	 //toString()은 객체를 문자열로 표현할 때 쓰이는 규칙.
	 @Override
	 public String toString() {
	     return "ParticipationVO{" +
	             "id=" + id +
	             ", userId=" + userId +
	             ", participationDate=" + participationDate +
	             ", timeSlot='" + timeSlot + '\'' +
	             ", region='" + region + '\'' +
	             ", participatedAt=" + participatedAt +
	             '}';
	 	}
	}