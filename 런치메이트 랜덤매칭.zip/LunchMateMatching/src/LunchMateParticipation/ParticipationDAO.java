package LunchMateParticipation;

import java.time.LocalDate;
import java.util.List;

public interface ParticipationDAO {
	
	//참여 신청 등록. (user_id, date, time_slot, region) UNIQUE 제약으로 중복 방지 
    int insert(ParticipationVO vo) throws Exception;
    
    //이미 같은 날짜/슬롯으로 신청했는지 여부 체크(중복 신청 방지).
    boolean existsByUserDateSlot(int userId, LocalDate date, String timeSlot) throws Exception;
    
    // 내 참여 내역 조회(히스토리 화면). 최근순 정렬 권장. 
    List<ParticipationVO> findByUser(int userId) throws Exception;
    
    // 매칭 후보 조회: 특정 날짜/슬롯/지역의 참여자들 가져오기.
    List<ParticipationVO> findByDateSlotRegion(LocalDate date, String timeSlot, String region) throws Exception;
    
    // 매칭 신청 취소. 
    int deleteById(int id) throws Exception;
    
    // 날짜/슬롯 + 중심 좌표로 반경 km 내 참여자 조회 (users 좌표 조인 + 거리 계산)(sql 쿼리로 계산)
    List<ParticipationVO> findByDateSlotNear(LocalDate date,String timeSlot,double centerLat,
            double centerLng,
            double radiusKm
    ) throws Exception;
}