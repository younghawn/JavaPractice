package LunchMateCommon;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import java.util.Properties;


// 이메일 발송 테스트 코드

public class PingMailNaver {

    
    public static void main(String[] args) {
       
        // (2) 테스트 자격 정보 (네이버 "앱 비밀번호" 사용 권장)
        final String username = System.getProperty("MAIL_USERNAME", "yohw601@naver.com");
        final String password = System.getProperty("MAIL_PASSWORD", "QYHX6JTKH5FT");

        // (3) 수신자: 본인 메일로 핑(수신확인용)
        final String to = System.getProperty("MAIL_TO", username);

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");   // TLS
        props.put("mail.smtp.host", "smtp.naver.com");
        props.put("mail.smtp.port", "587");

        try {
            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });

            Message msg = new MimeMessage(session);
            // 보내는 사람: 네이버 정책상 계정과 동일하게
            msg.setFrom(new InternetAddress(username, "Ping Tester"));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            msg.setSubject("[PING] Jakarta Mail / Naver SMTP");
            msg.setText("네이버 SMTP 핑 테스트입니다. 시간이 보이면 TLS/인증 정상!");

            Transport.send(msg);
            System.out.println("✅ 메일 발송 성공: " + to);
        } catch (Exception e) {
            System.err.println("❌ 메일 발송 실패: " + e);
            e.printStackTrace();
        }
    }
}