package LunchMateCommon;

import javax.swing.*;
import java.awt.*;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.concurrent.Worker.State;
import netscape.javascript.JSObject;

//1.포트 번호(58888) 고정 이유
//	JavaFX WebView는 보안 정책 때문에 로컬 파일(file://) 로 로드한 JS에서 window.javaBridge 같은 Java ↔ JS 브릿지를 제대로 실행하기 어려움.
//	그래서 HttpServer를 띄워 http://localhost:58888/map 으로 페이지를 서비스하면 브라우저(WebView) 환경과 동일하게 동작.
//	포트를 고정하면 프로젝트 내 어디서든 URL을 예측 가능하게 사용할 수 있어 관리가 편함.

//2.HTML로 변환한 이유
//	카카오 지도는 JS SDK 기반 → 반드시 HTML + JavaScript 환경에서 동작.
//	Java Swing만으로는 지도 API를 직접 사용할 수 없으므로, HTML 페이지를 만들어 WebView에 로드하는 방식으로 연동.
//  이렇게 하면 JS에서 클릭 이벤트 → Java 브릿지 → Swing 코드로 좌표를 전달할 수 있음.


//  카카오 지도 좌표 선택 다이얼로그 (Swing + JavaFX WebView)
//  - localhost:58888/map 에서 HTML을 서빙하여 WebView로 로드
//  - 카카오 지도 시작중심: 솔데스크 종로본점


public class MapPickerDialog extends JDialog {

	private static final long serialVersionUID = 1L;
	
	// 포트번호 58888고정 
	// → WebView가 로컬 HTML 파일을 보지 않고 "http://localhost:58888/map" 으로 접속
    private static final int    HTTP_PORT      = 58888;
    // 솔데스트 위도
    private static final double CENTER_LAT     = 37.569368491884;  
    // 솔데스크 경도
    private static final double CENTER_LNG     = 126.98585089037;  
    // 지도 확대 레벨(작을수록 확대)
    private static final int    MAP_LEVEL      = 4;                  

    // 필드
    private final String kakaoAppKey;           
    private final JFXPanel jfxPanel = new JFXPanel();
    private volatile Double pickedLat;          
    private volatile Double pickedLng;
    
    //내장 HTTP 서버(로컬에서 HTML 제공)
    private HttpServer server;

    // 생성(다이얼로그 UI)
    public MapPickerDialog(Frame owner, String kakaoAppKey) {
        super(owner, "지도에서 위치 선택", true);
        this.kakaoAppKey = chooseKey(kakaoAppKey);

        setSize(720, 520);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        // WebView 영역
        add(jfxPanel, BorderLayout.CENTER);

        // 하단 버튼
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnCancel = new JButton("취소");
        btnCancel.addActionListener(e -> dispose());
        JButton btnOk = new JButton("선택 완료");
        btnOk.addActionListener(e -> dispose());
        bottom.add(btnCancel);
        bottom.add(btnOk);
        add(bottom, BorderLayout.SOUTH);

        // 윈도우 닫을 때 서버 정리
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed (java.awt.event.WindowEvent e) { stopServer(); }
            @Override public void windowClosing(java.awt.event.WindowEvent e) { stopServer(); }
        });

        initFX();
    }

    //외부 조회용 getter
    public Double getLatitude()  { return pickedLat; }
    public Double getLongitude() { return pickedLng; }

    //키 선택: -D(KAKAO_JS_KEY) > 환경변수 > 인자 
    private static String chooseKey(String key) {
        String k = System.getProperty("KAKAO_JS_KEY");
        if (k != null && !k.isBlank()) return k;
        k = System.getenv("KAKAO_JS_KEY");
        if (k != null && !k.isBlank()) return k;
        return key; // 마지막으로 생성자 인자
    }

    //JavaFX 초기화 & 페이지 로드 
    private void initFX() {
        Platform.setImplicitExit(false);
        Platform.runLater(() -> {
            try {
                startServer(); // http://localhost:58888 고정

                WebView webView = new WebView();
                WebEngine engine = webView.getEngine();

                // macOS WebKit 호환성 높은 UA
                engine.setUserAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                        + "AppleWebKit/605.1.15 (KHTML, like Gecko) "
                        + "Version/17.0 Safari/605.1.15");

                // JS ↔ Java 브릿지 등록(로드 완료 시)
                engine.getLoadWorker().stateProperty().addListener((obs, old, cur) -> {
                    if (cur == State.SUCCEEDED) {
                        try {
                            JSObject win = (JSObject) engine.executeScript("window");
                            win.setMember("javaBridge", new JSBridge());
                        } catch (Throwable ignored) { }
                    }
                });

                engine.load("http://localhost:" + HTTP_PORT + "/map");
                jfxPanel.setScene(new Scene(webView));
            } catch (Exception ex) {
                ex.printStackTrace();
                SwingUtilities.invokeLater(() ->
                    JOptionPane.showMessageDialog(this, "지도 초기화 실패: " + ex.getMessage())
                );
            }
        });
    }

    //JS에서 호출할 브릿지
    public class JSBridge {
        public void onPick(double lat, double lng) {
            pickedLat = lat;
            pickedLng = lng;
        }
    }

    //로컬 HTTP 서버
    private void startServer() throws Exception {
        if (server != null) return;

        server = HttpServer.create(new InetSocketAddress("localhost", HTTP_PORT), 0);
        server.createContext("/map", new HttpHandler() {
            @Override public void handle(HttpExchange exchange) {
                try {
                    byte[] bytes = buildHtml(kakaoAppKey).getBytes(StandardCharsets.UTF_8);
                    exchange.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");
                    exchange.sendResponseHeaders(200, bytes.length);
                    try (OutputStream os = exchange.getResponseBody()) { os.write(bytes); }
                } catch (Exception e) {
                    try { exchange.sendResponseHeaders(500, -1); } catch (Exception ignored) {}
                }
            }
        });
        server.start();
    }

    private void stopServer() {
        if (server != null) { server.stop(0); server = null; }
    }

    //지도 HTML
    private String buildHtml(String appKey) {
        // 문서 단순화: onload에서 kakao.maps.load로 initMap 호출
        return """
		<!doctype html>
		<html lang="ko">
		<head>
		<meta charset="UTF-8">
		<meta name="referrer" content="origin-when-cross-origin">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>좌표 선택</title>
		<style>
		  html, body, #map { width:100%%; height:100%%; margin:0; padding:0; }
		  .hint   { position:absolute; top:10px; left:10px; background:#fff; padding:8px 10px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,.1); font-family:Arial, sans-serif; font-size:12px; }
		  .coords { position:absolute; bottom:10px; left:10px; background:#fff; padding:6px 10px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,.1); font-family:Arial, sans-serif; font-size:12px; }
		</style>
		</head>
		<body>
		<div id="map"></div>
		<div class="hint">지도를 클릭하면 마커가 찍히고 좌표가 선택됩니다.</div>
		<div class="coords" id="coords">위도: -, 경도: -</div>
		
		<script>
		  function initMap(){
		    var center = new kakao.maps.LatLng(%f, %f); // 솔데스크 
		    var map = new kakao.maps.Map(document.getElementById('map'), {
		      center: center, level: %d
		    });
		
		    var marker = new kakao.maps.Marker({ position: center });
		    marker.setMap(map);
		    document.getElementById('coords').innerText =
		      '위도: ' + center.getLat().toFixed(6) + ' , 경도: ' + center.getLng().toFixed(6);
		
		    kakao.maps.event.addListener(map, 'click', function(e) {
		      var latlng = e.latLng;
		      marker.setPosition(latlng);
		      var lat = latlng.getLat(), lng = latlng.getLng();
		      document.getElementById('coords').innerText =
		        '위도: ' + lat.toFixed(6) + ' , 경도: ' + lng.toFixed(6);
		      if (window.javaBridge && typeof window.javaBridge.onPick === 'function') {
		        window.javaBridge.onPick(lat, lng);
		      }
		    });
		  }
		</script>
		<script src="https://dapi.kakao.com/v2/maps/sdk.js?appkey=%s&libraries=services&autoload=false"
		        onload="kakao.maps.load(initMap)"></script>
		</body>
		</html>
		""".formatted(CENTER_LAT, CENTER_LNG, MAP_LEVEL, appKey);
		    }
		}