package LunchMateNotification;

import LunchMateConnInfo.ConnectionManager;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;


// 매칭 이메일 발송 서비스 

public class EmailService {
	//명시적 타입으로 선언한 이유!
	//한 번 할당되면 다시 변경되지 않음 → EmailService 안에서 항상 같은 DAO 객체를 사용하도록 보장.
	//"이메일 서비스는 하나의 DAO로만 동작한다"
    private final EmailNotificationDAO notificationDAO; 

    public EmailService(EmailNotificationDAO dao) {
        this.notificationDAO = dao;
    }

    //특정 매치 ID에 대해 모든 참여자에게 메일 발송 + 이메일 이력 저장 
    public void sendMatchEmails(int matchId) throws Exception {
        System.out.println("[EmailService] sendMatchEmails start, matchId=" + matchId);

        MatchData m = loadMatch(matchId);
        if(m == null) throw new IllegalStateException("match not found: id=" + matchId);

        // 참여자 로드
        List<UserData> users = new ArrayList<>();
        if (m.userIdA != null) users.add(loadUser(m.userIdA));
        if (m.userIdB != null) users.add(loadUser(m.userIdB));
        if (m.userIdC != null) users.add(loadUser(m.userIdC));
        users.removeIf(Objects::isNull);

        if (users.isEmpty()) {
            System.out.println("[EmailService] no users to notify for matchId=" + matchId);
            return;
        }

        for (UserData recipient : users) {
            List<String> partners = users.stream()
                    .filter(u -> !Objects.equals(u.id, recipient.id))
                    .map(this::formatPartnerLabel)
                    .collect(Collectors.toList());

            // 메일 제목/본문 생성 (DB에는 저장하지 않음)
            String subject = MailTemplate.subject(m.date, m.timeSlot);
            String html = MailTemplate.htmlBody(
                    recipient.name,
                    m.date,
                    m.timeSlot,
                    m.region,
                    m.menu,
                    partners,
                    "약속 시간에 맞춰 즐거운 식사되세요!"
            );

            //이메일 이력 PENDING 저장
            EmailNotificationVO vo = new EmailNotificationVO();
            vo.setUserId(recipient.id);
            vo.setMatchId(matchId);
            vo.setStatus("PENDING");

            // insert 가 id(자동증가) 를 vo.setId로 채워주도록 JDBC DAO 구현되어 있음
            notificationDAO.insert(vo);
            int notifId = vo.getId();
            System.out.println("[EmailService] queued email record: userId=" + recipient.id + ", matchId=" + matchId + ", notifId=" + notifId);

            //실제 메일 발송
            try {
                // 수신 주소 검증 (없으면 실패 처리)
                if (recipient.email == null || recipient.email.isBlank()) {
                    throw new MessagingException("recipient email is empty");
                }

                sendMail(recipient.email, subject, html);
                System.out.println("[EmailService] mail sent OK -> " + recipient.email);

                // 성공: status='SENT' 로 업데이트 (DAO가 sent_at = CURRENT_TIMESTAMP 세팅)
                notificationDAO.updateStatus(notifId, "SENT");
            } catch (Exception sendErr) {
                System.err.println("[EmailService] mail send FAIL -> " + recipient.email + " : " + sendErr.getMessage());

                // 실패: status='FAILED'
                try {
                    notificationDAO.updateStatus(notifId, "FAILED");
                } catch (Exception daoErr) {
                    System.err.println("[EmailService] status update failed: " + daoErr.getMessage());
                }
            }
        }
    }

    //메일 발송
    private void sendMail(String to, String subject, String htmlBody) throws MessagingException {
        MailConfig cfg = MailConfig.load();
        Session session = cfg.createSession();

        Message msg = new MimeMessage(session);

        try {
            msg.setFrom(new InternetAddress(cfg.username, cfg.fromName));
        } catch (java.io.UnsupportedEncodingException e) {
            msg.setFrom(new InternetAddress(cfg.username));
        }
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        msg.setSubject(subject);
        msg.setContent(htmlBody, "text/html; charset=UTF-8");

        Transport.send(msg);
    }

    //DB 로딩
    private MatchData loadMatch(int matchId) throws SQLException {
        String sql = """
            SELECT id, match_date, time_slot, region,
                   user_id_a, user_id_b, user_id_c, group_size, menu
              FROM matches
             WHERE id = ?
        """;
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, matchId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                MatchData m = new MatchData();
                m.id        = rs.getInt("id");
                java.sql.Date d = rs.getDate("match_date");
                m.date      = (d != null ? d.toLocalDate() : null);
                m.timeSlot  = rs.getString("time_slot");
                m.region    = rs.getString("region");
                m.userIdA   = getNullableInt(rs, "user_id_a");
                m.userIdB   = getNullableInt(rs, "user_id_b");
                m.userIdC   = getNullableInt(rs, "user_id_c");
                m.groupSize = rs.getInt("group_size");
                m.menu      = rs.getString("menu");
                return m;
            }
        }
    }

    private UserData loadUser(int userId) throws SQLException {
        String sql = "SELECT id, name, email, gender, latitude, longitude FROM users WHERE id = ?";
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                UserData u = new UserData();
                u.id = rs.getInt("id");
                u.name = rs.getString("name");
                u.email = rs.getString("email");
                try { u.gender = rs.getString("gender"); } catch (SQLException ignore) {}
                try {
                    Object lat = rs.getObject("latitude");
                    Object lng = rs.getObject("longitude");
                    u.latitude  = (lat instanceof Number) ? ((Number) lat).doubleValue() : null;
                    u.longitude = (lng instanceof Number) ? ((Number) lng).doubleValue() : null;
                } catch (SQLException ignore) {}
                return u;
            }
        }
    }

    private Integer getNullableInt(ResultSet rs, String col) throws SQLException {
        int v = rs.getInt(col);
        return rs.wasNull() ? null : v;
    }

    private String formatPartnerLabel(UserData u) {
        String namePart = (u.name != null && !u.name.isBlank())
                ? u.name + "(" + u.id + ")"
                : String.valueOf(u.id);
        String gender = (u.gender != null && !u.gender.isBlank()) ? u.gender : "-";
        return namePart + " · " + gender;
    }

    //내부 DTO
    //내부 DTO(MatchData, UserData)는 이메일 서비스 로직 전용 데이터 그릇
    //DB 엔티티 전체를 쓰지 않고 필요한 필드만 모아 가볍게 처리하려고 만든 것.
    //외부에 공개되지 않고 EmailService 내부에서만 쓰이는 점 때문에 private static class로 정의.
    private static class MatchData {
        @SuppressWarnings("unused")
		int id;
        LocalDate date;
        String timeSlot;
        String region;
        Integer userIdA, userIdB, userIdC;
        @SuppressWarnings("unused")
		int groupSize;
        String menu;
    }

    private static class UserData {
        Integer id;
        String name;
        String email;
        String gender;
        @SuppressWarnings("unused")
		Double latitude;
        @SuppressWarnings("unused")
		Double longitude;
    }

    //SMTP 설정
    //메일 서버(예: Gmail, Naver 등)와 연결하기 위한 발신 서버 주소·포트·계정 정보를
    //지정해 이메일을 보낼 수 있도록 해주는 설정
    private static class MailConfig {
        final String host;
        final String port;
        final String username;
        final String password;
        final String fromName;

        private MailConfig(String host, String port, String username, String password, String fromName) {
            this.host = host;
            this.port = port;
            this.username = username;
            this.password = password;
            this.fromName = (fromName == null || fromName.isBlank()) ? "LunchMate" : fromName;
        }

        static MailConfig load() {
            String host = "smtp.naver.com";
            String port = "587";
            String user = "yohw601@naver.com";   // 네이버 메일 주소
            String pass = "QYHX6JTKH5FT";        // '앱 비밀번호'
            String name = "🍱점심메이트🍱";

            return new MailConfig(host, port, user, pass, name);
        }

        Session createSession() {
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.port", port);
            return Session.getInstance(props, new Authenticator() {
                @Override protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });
        }
    }
}