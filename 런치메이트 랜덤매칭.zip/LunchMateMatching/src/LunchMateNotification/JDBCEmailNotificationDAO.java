package LunchMateNotification;

import LunchMateConnInfo.ConnectionManager;
import java.sql.*;

public class JDBCEmailNotificationDAO implements EmailNotificationDAO {

    @Override
    public int insert(EmailNotificationVO vo) throws Exception {
        
        final String sql =
            "INSERT INTO email_notifications (user_id, match_id, status) " +
            "VALUES (?, ?, ?)";

        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, vo.getUserId());
            ps.setInt(2, vo.getMatchId());
            ps.setString(3, vo.getStatus());

            int updated = ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) vo.setId(keys.getInt(1));
            }
            return updated;
        }
    }

    @Override
    public int updateStatus(int id, String status) throws Exception {
        // 상태 변경 규칙:
        // SENT  :이메일 전송 성공
        // PENDING:재시도, 발송 대기중 
        // FAILED:이메일 전송 실패 
        final String sql =
            "UPDATE email_notifications " +
            "   SET status = ?, " +
            "       sent_at = CASE " +
            "                   WHEN ? = 'SENT' THEN CURRENT_TIMESTAMP " +
            "                   WHEN ? = 'PENDING' THEN NULL " +
            "                   ELSE sent_at " +
            "                 END " +
            " WHERE id = ?";

        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setString(2, status); 
            ps.setString(3, status); 
            ps.setInt(4, id);
            return ps.executeUpdate();
        }
    }
}