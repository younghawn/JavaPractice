package LunchMateNotification;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;


//EmailNotificationVO → email_notifications 테이블
//
//역할: 매칭 결과·추천 메뉴를 이메일로 발송한 내역 관리
//	•	발송 상태 추적, 재발송 등에도 사용.
//
//주요 필드
//	•	id : PK
//	•	userId : 수신자 FK
//	•	matchId : 해당 매칭 FK
//	•	status : 발송 상태(PENDING, SENT, FAILED)
//	•	sentAt : 발송 시각
//	•	createdAt : 기록 생성 시각

//Serializable      → 객체를 직렬화/역직렬화 가능하게 함
//serialVersionUID  → 직렬화 버전 호환성 유지

public class EmailNotificationVO implements Serializable {
	
    private static final long serialVersionUID = 1L;

    private Integer id;
    private Integer userId;
    private Integer matchId;
    private String status;           // 'PENDING','SENT','FAILED'
    private LocalDateTime sentAt;    // nullable(널값이 될수도 있다)
    private LocalDateTime createdAt;

    public EmailNotificationVO() {}

    public EmailNotificationVO(Integer userId, Integer matchId, String status) {
        this.userId = userId; this.matchId = matchId; this.status = status;
    }

    public EmailNotificationVO(Integer id, Integer userId, Integer matchId, String status,
                               LocalDateTime sentAt, LocalDateTime createdAt) {
        this(userId, matchId, status);
        this.id = id; this.sentAt = sentAt; this.createdAt = createdAt;
    }

    // 게터/세터
    public Integer getId() {return id; }
    public void setId(Integer id) { this.id = id; }
    
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    
    public Integer getMatchId() { return matchId; }
    public void setMatchId(Integer matchId) { this.matchId = matchId; }
 
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public LocalDateTime getSentAt() { return sentAt; }
    public void setSentAt(LocalDateTime sentAt) { this.sentAt = sentAt; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    // equals/hashCode: id 우선, 없으면 (userId, matchId, status, sentAt) 임시 조합
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EmailNotificationVO)) return false;
        EmailNotificationVO that = (EmailNotificationVO) o;
        if (this.id != null && that.id != null) return Objects.equals(this.id, that.id);
        return Objects.equals(userId, that.userId) &&
               Objects.equals(matchId, that.matchId) &&
               Objects.equals(status, that.status) &&
               Objects.equals(sentAt, that.sentAt);
    }
    @Override
    public int hashCode() {
        return (id != null) ? Objects.hash(id) : Objects.hash(userId, matchId, status, sentAt);
    }

    //toString()은 객체를 문자열로 표현할 때 쓰이는 규칙.
    @Override
    public String toString() {
    	return "EmailNotificationVO{" +
                "id=" + id +
                ", userId=" + userId +
                ", matchId=" + matchId +
                ", status='" + status + '\'' +
                ", sentAt=" + sentAt +
                ", createdAt=" + createdAt +
                '}';
    }
}