package LunchMateNotification;

public interface EmailNotificationDAO {
	
    // 발송 예약(PENDING) 기록 저장. 매칭 생성 직후 큐 성격으로 적재
    int insert(EmailNotificationVO vo) throws Exception;

    // 상태 변경(PENDING→SENT/FAILED). 
    int updateStatus(int id, String status) throws Exception;
}