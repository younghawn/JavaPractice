package LunchMateNotification;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;


//  매칭 안내 메일 템플릿 (심플+카드형, 인라인 CSS)
// 	subject(date, timeSlot)
//  htmlBody(recipientName, date, timeSlot, region, menu, partners, extraNote)
//  인자/시그니처는 기존 그대로 유지합니다.

public final class MailTemplate {

    private MailTemplate() {}

    public static String subject(LocalDate date, String timeSlot) {
        String ds = date != null ? date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : "";
        return "🍱 점심메이트 매칭 안내 - " + ds + " " + (timeSlot != null ? timeSlot : "");
    }

    /**
     * @param recipientName  수신자 이름(없으면 공란 허용)
     * @param date           매칭 날짜
     * @param timeSlot       시간대
     * @param region         장소 표기 (예: "center(37.570500,126.983200)±3.0km" 또는 "lat:..., lng:...")
     * @param menu           추천 메뉴(없으면 "-")
     * @param partners       상대 참여자 이름/아이디(자기 자신 제외)의 간단 라벨 리스트
     * @param extraNote      추가 안내 문구(옵션)
     */
    public static String htmlBody(String recipientName,
                                  LocalDate date,
                                  String timeSlot,
                                  String region,
                                  String menu,
                                  List<String> partners,
                                  String extraNote) {

        String ds        = date != null ? date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : "-";
        String safeMenu  = (menu != null && !menu.isBlank()) ? menu : "-";
        String safeReg   = (region != null && !region.isBlank()) ? region : "-";
        String helloName = (recipientName != null && !recipientName.isBlank()) ? recipientName + "님 안녕하세요!" : "안녕하세요!";
        String slot      = (timeSlot != null && !timeSlot.isBlank()) ? timeSlot : "-";
        String pList     = (partners != null && !partners.isEmpty())
                ? partners.stream().collect(Collectors.joining(", "))
                : "-";
        String note      = (extraNote != null) ? extraNote : "";

        // 브랜드 컬러(버튼/배지/헤더에 사용)
        String BRAND = "#FF8C42";  // rgb(255,140,66)
        String BRAND_DARK = "#E46F20";

        return ("""
        <!doctype html>
        <html>
        <head>
          <meta charset="UTF-8">
          <meta name="color-scheme" content="light only">
          <meta name="supported-color-schemes" content="light">
          <title>점심메이트 매칭 안내</title>
        </head>
        <body style="margin:0;padding:0;background:#f5f6f8;">
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%%" style="background:#f5f6f8;">
          <tr>
            <td align="center" style="padding:24px 12px;">
              <!-- 카드 -->
              <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="560" style="max-width:560px;background:#ffffff;border:1px solid #eee;border-radius:14px;overflow:hidden;">
                <!-- 헤더 배너 -->
                <tr>
                  <td style="background:%1$s;padding:18px 22px;color:#fff;">
                    <table role="presentation" width="100%%" cellspacing="0" cellpadding="0" border="0">
                      <tr>
                        <td style="font-size:20px;font-weight:700;letter-spacing:.2px;">🍱 점심메이트 매칭 확정</td>
                        <td align="right" style="font-size:12px;opacity:.95;">%2$s</td>
                      </tr>
                    </table>
                  </td>
                </tr>

                <!-- 인사 -->
                <tr>
                  <td style="padding:20px 22px 6px 22px;font-family:system-ui,Segoe UI,Roboto,Apple SD Gothic Neo,Helvetica,Arial,sans-serif;color:#222;font-size:16px;line-height:1.6;">
                    <strong>%3$s</strong><br>
                    점심메이트 매칭 결과를 안내드립니다. 아래 정보를 확인해 주세요.
                  </td>
                </tr>

                <!-- 핵심 요약 배지 -->
                <tr>
                  <td style="padding:8px 22px 6px 22px;">
                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%%" style="border-collapse:collapse;">
                      <tr>
                        <td style="padding:10px 0;">
                          <span style="display:inline-block;margin:2px 6px 2px 0;padding:8px 12px;border-radius:999px;background:#fff1e8;color:#333;border:1px solid %1$s;font-size:13px;">📅 %2$s</span>
                          <span style="display:inline-block;margin:2px 6px 2px 0;padding:8px 12px;border-radius:999px;background:#fff1e8;color:#333;border:1px solid %1$s;font-size:13px;">⏰ %4$s</span>
                          <span style="display:inline-block;margin:2px 6px 2px 0;padding:8px 12px;border-radius:999px;background:#eef6ff;color:#1f3b7b;border:1px solid #cfe3ff;font-size:13px;">🍽️ %5$s</span>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>

                <!-- 구분선 -->
                <tr><td style="padding:0 22px"><hr style="border:none;border-top:1px solid #f0f0f0;margin:6px 0 0 0;"></td></tr>

                <!-- 상세 테이블 -->
                <tr>
                  <td style="padding:12px 22px 6px 22px;">
                    <table role="presentation" cellpadding="10" cellspacing="0" border="0" width="100%%" style="border-collapse:collapse;">
                      <tr>
                        <td style="width:110px;color:#666;font-size:13px;">📍 장소</td>
                        <td style="color:#222;font-size:14px;">%6$s</td>
                      </tr>
                      <tr>
                        <td style="color:#666;font-size:13px;">👥 상대</td>
                        <td style="color:#222;font-size:14px;">
                          %7$s
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>

                <!-- 안내 문구 -->
                <tr>
                  <td style="padding:6px 22px 2px 22px;color:#555;font-size:13px;line-height:1.6;font-family:system-ui,Segoe UI,Roboto,Apple SD Gothic Neo,Helvetica,Arial,sans-serif;">
                    %8$s
                  </td>
                </tr>

                
                <!-- 푸터 -->
                <tr>
                  <td style="background:#fafafa;padding:14px 22px;color:#999;font-size:12px;border-top:1px solid #eee;">
                    본 메일은 시스템에서 자동 발송되었습니다. 잘못 수신하셨다면 회신해 주세요.
                  </td>
                </tr>
              </table>
              <!-- 카드 끝 -->
            </td>
          </tr>
        </table>
        </body>
        </html>
        """)
        .formatted(
            BRAND,                      // %1$s: 브랜드 컬러
            escape(ds),                 // %2$s: 날짜
            escape(helloName),          // %3$s: 인사
            escape(slot),               // %4$s: 시간
            escape(safeMenu),           // %5$s: 메뉴
            escape(safeReg),            // %6$s: 장소
            escape(pList),              // %7$s: 파트너 목록
            escape(note),               // %8$s: 추가 안내 문구
            BRAND_DARK                  // %9$s: 버튼 테두리 대비 색
        );
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;")
                .replace("<","&lt;")
                .replace(">","&gt;");
    }
}