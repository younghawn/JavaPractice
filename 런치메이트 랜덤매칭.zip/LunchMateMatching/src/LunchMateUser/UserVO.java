package LunchMateUser;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
//UserVO → users 테이블
//
//역할: 회원 정보 저장
//	•	시스템에 가입한 사용자의 기본 정보, 위치(GPS) 좌표까지 포함.
//	•	매칭 시 성별·위치 정보 사용.
//
//주요 필드
//	•	id : PK(자동 증가)
//	•	name, email : 이름, 로그인/식별용 이메일
//	•	passwordHash : 암호화된 비밀번호
//	•	gender : 성별(MALE/FEMALE/OTHER)
//	•	latitude, longitude : GPS 좌표 (근처 맛집/위치 기반 매칭에 사용)
//	•	createdAt, updatedAt : 생성/수정 시각

public class UserVO implements Serializable, Comparable<UserVO> {
	
    private static final long serialVersionUID = 1L;
//- **직렬화**: 객체를 바이트 스트림으로 변환해서 파일 저장이나 네트워크 전송에 사용할 수 있게 만드는 것.
//- **역직렬화**: 저장된 바이트 스트림을 다시 객체로 복원하는 것.
//	  Serializable      → 객체를 직렬화/역직렬화 가능하게 함
//    serialVersionUID  → 직렬화 버전 호환성 유지
//    Comparable        → 정렬 가능한 객체로 만듦
    
    private Integer id;
    private String name;
    private String email;
    private String passwordHash;   // 비밀번호 해쉬저장
    private String gender;         
    private Double latitude;       
    private Double longitude;      
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public UserVO() {}

    public UserVO(String name, String email, String passwordHash, String gender) {
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
        this.gender = gender;
    }

    public UserVO(Integer id, String name, String email, String passwordHash, String gender,
                  Double latitude, Double longitude, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
        this.gender = gender;
        this.latitude = latitude;
        this.longitude = longitude;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // 게터/세터
    public Integer getId() { return id; }
    
    public void setId(Integer id) { this.id = id; }
    
    public String getName() { return name; }
    
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    
    public void setEmail(String email) { this.email = email; }
    
    public String getPasswordHash() { return passwordHash; }
    
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    
    public String getGender() { return gender; }
    
    public void setGender(String gender) { this.gender = gender; }
    
    public Double getLatitude() { return latitude; }
    
    public void setLatitude(Double latitude) { this.latitude = latitude; }
    
    public Double getLongitude() { return longitude; }
    
    public void setLongitude(Double longitude) { this.longitude = longitude; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    

    // equals/hashCode: id 우선, 없으면 email로 대체
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserVO)) return false;
        UserVO that = (UserVO) o;
        if (this.id != null && that.id != null) return Objects.equals(this.id, that.id);
        return Objects.equals(this.email, that.email);
    }
    @Override
    public int hashCode() { return (id != null) ? Objects.hash(id) : Objects.hash(email); }

    
    //toString()은 객체를 문자열로 표현할 때 쓰이는 규칙.
    @Override
    public String toString() {
        return "UserVO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", gender='" + gender + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }

    // 최신 가입일 순 정렬
    @Override
    public int compareTo(UserVO o) {
        if (createdAt == null && o.createdAt == null) return 0;
        if (createdAt == null) return 1;
        if (o.createdAt == null) return -1;
        return o.createdAt.compareTo(createdAt); // 최근순
    }
}