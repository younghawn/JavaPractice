package LunchMateUser;

import LunchMateConnInfo.ConnectionManager;
import LunchMateDB.PasswordUtil;

import java.sql.*;
//import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class JDBCUserDAO implements UserDAO {

    @Override
    public int insert(UserVO vo) throws Exception {
        String sql = "INSERT INTO users(name,email,password_hash,gender,latitude,longitude) VALUES (?,?,?,?,?,?)";
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, vo.getName());
            ps.setString(2, vo.getEmail());
            ps.setString(3, vo.getPasswordHash());
            ps.setString(4, vo.getGender());
            if (vo.getLatitude()==null)  ps.setNull(5, Types.DECIMAL); else ps.setDouble(5, vo.getLatitude());
            if (vo.getLongitude()==null) ps.setNull(6, Types.DECIMAL); else ps.setDouble(6, vo.getLongitude());
            int updated = ps.executeUpdate();
            
            try (ResultSet keys = ps.getGeneratedKeys()) {
            	if (keys.next()) vo.setId(keys.getInt(1)); }
            return updated;
        }
    }

    @Override
    public int update(UserVO v) throws Exception {
        String sql = "UPDATE users SET name=?, password_hash=?, gender=?, latitude=?, longitude=? WHERE id=?";
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, v.getName());
            ps.setString(2, v.getPasswordHash());
            ps.setString(3, v.getGender());
            if (v.getLatitude()==null)  ps.setNull(4, Types.DECIMAL); else ps.setDouble(4, v.getLatitude());
            if (v.getLongitude()==null) ps.setNull(5, Types.DECIMAL); else ps.setDouble(5, v.getLongitude());
            ps.setInt(6, v.getId());
            return ps.executeUpdate();
        }
    }

    
    @Override
    public int delete(int id) throws Exception {
        String selectMatches =
            "SELECT id FROM matches WHERE user_id_a=? OR user_id_b=? OR user_id_c=?";
        String deleteEmailNotifsByMatch =
            "DELETE FROM email_notifications WHERE match_id=?";
        String deleteMatches =
            "DELETE FROM matches WHERE id=?";
        String deleteEmailNotifsByUser =
            "DELETE FROM email_notifications WHERE user_id=?";
        String deleteParticipations =
            "DELETE FROM participations WHERE user_id=?";
        String deleteUser =
            "DELETE FROM users WHERE id=?";

        Connection c = ConnectionManager.getConnection();
        boolean oldAuto = c.getAutoCommit();
        try {
            c.setAutoCommit(false);

            // 1) 이 유저가 포함된 매치 목록
            List<Integer> matchIds = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(selectMatches)) {
                ps.setInt(1, id);
                ps.setInt(2, id);
                ps.setInt(3, id);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) matchIds.add(rs.getInt(1));
                }
            }

            // 2) 해당 매치에 연결된 이메일 알림 삭제 → 매치 삭제
            try (PreparedStatement psNotif = c.prepareStatement(deleteEmailNotifsByMatch);
                 PreparedStatement psMatch = c.prepareStatement(deleteMatches)) {
                for (Integer mid : matchIds) {
                    psNotif.setInt(1, mid);
                    psNotif.executeUpdate();

                    psMatch.setInt(1, mid);
                    psMatch.executeUpdate();
                }
            }

            // 3) 이 유저 개인에게 걸린 알림(혹시 남아있다면) 삭제
            try (PreparedStatement ps = c.prepareStatement(deleteEmailNotifsByUser)) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }

            // 4) 신청 기록 삭제 (스키마가 ON DELETE CASCADE라도 명시 삭제로 안전하게)
            try (PreparedStatement ps = c.prepareStatement(deleteParticipations)) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }

            // 5) 최종 사용자 삭제
            int affected;
            try (PreparedStatement ps = c.prepareStatement(deleteUser)) {
                ps.setInt(1, id);
                affected = ps.executeUpdate();
            }

            c.commit();
            return affected; // 1이면 성공, 0이면 해당 사용자 없음
        } catch (Exception e) {
            try { c.rollback(); } catch (Exception ignore) {}
            throw e;
        } finally {
            try { c.setAutoCommit(oldAuto); } catch (Exception ignore) {}
            try { c.close(); } catch (Exception ignore) {}
        }
    }
   

    @Override
    public UserVO findById(int id) throws Exception {
        try (Connection c = ConnectionManager.getConnection();
            PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        }
    }

    @Override
    public UserVO findByEmail(String email) throws Exception {
        try (Connection c = ConnectionManager.getConnection();
            PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE email=?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        }
    }
   
//        이메일/비밀번호로 사용자 인증.
//        저장된 password_hash가 해시인지(64자 hex) 평문인지에 상관없이 둘 다 비교해 하위호환.
//        일치하면 UserVO 반환, 아니면 null 반환.
   
    public UserVO authenticate(String email, String rawPassword) throws Exception {
	        UserVO u = findByEmail(email);
	        if (u == null) return null;

	        String stored = u.getPasswordHash();  // DB 저장값
	        String inputHash = PasswordUtil.sha256(rawPassword); // 입력값 해시

	        // 해시 비교
	        if (PasswordUtil.slowEquals(stored, inputHash)) return u;

	        return null;
    }
    
    //공통 매핑
    //매핑 = DB, 네트워크, JSON 같은 외부 데이터와 내부 객체를 이어주는 다리.
    //DB 컬럼 ↔ VO/DTO 변환 작업이 반복되니까 재사용/최적화를 위해 빼놓은 것.
    private UserVO map(ResultSet rs) throws SQLException {
        UserVO vo = new UserVO();
        vo.setId(rs.getInt("id"));
        vo.setName(rs.getString("name"));
        vo.setEmail(rs.getString("email"));
        vo.setPasswordHash(rs.getString("password_hash"));
        vo.setGender(rs.getString("gender"));
        Object lat = rs.getObject("latitude");  vo.setLatitude(lat==null?null:((Number)lat).doubleValue());
        Object lng = rs.getObject("longitude"); vo.setLongitude(lng==null?null:((Number)lng).doubleValue());
        
        Timestamp ct = rs.getTimestamp("created_at");
        if (ct!=null) vo.setCreatedAt(ct.toLocalDateTime());
  
        Timestamp ut = rs.getTimestamp("updated_at");
        if (ut!=null) vo.setUpdatedAt(ut.toLocalDateTime());
        return vo;
    }
}