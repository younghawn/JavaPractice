package LunchMateUser;

public interface UserDAO {
	
	//회원 신규 등록(회원가입)  중복 이메일은 DB UNIQUE 제약으로 방지
    int insert(UserVO vo) throws Exception;
    
    //회원 정보 수정(이름/비번/성별/좌표 등)
    int update(UserVO vo) throws Exception;
    
    // 회원 삭제
    int delete(int id) throws Exception;
    
    //PK로 단건 조회. 존재하지 않으면 null 반환.
    UserVO findById(int id) throws Exception;
    
    // 로그인/중복체크용. 이메일로 단건 조회.
    // 이메일로 가입한 사용자가 있는지 없는지 확인.
    UserVO findByEmail(String email) throws Exception;
    
}