package LunchMateRestaurant;

import java.util.List;

public interface RestaurantDAO {
    //맛집 등록 (vo.userId가 null이면 예외)
    int insert(RestaurantVO vo) throws Exception;

    //사용자 전용(지도 표시용)
    //특정 사용자의 모든 맛집
    List<RestaurantVO> findAllByUser(int userId) throws Exception;

    //특정 사용자 + 중심 좌표 반경 km 
    List<RestaurantVO> findNearByUser(int userId, double lat, double lng, double radiusKm) throws Exception;
}