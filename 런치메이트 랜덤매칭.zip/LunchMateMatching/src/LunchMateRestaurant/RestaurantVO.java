package LunchMateRestaurant;

import java.io.Serializable;
import java.util.Objects;

//RestaurantVO → restaurants 테이블
//
//역할: 메뉴별 맛집 정보 저장
//	•	추천 메뉴에 맞는 실제 가게 리스트.
//	•	지도 API에 표시될 좌표를 포함.
//
//주요 필드
//	•	id : PK
//	•	name : 가게 이름
//	•	menu : 대표 메뉴명
//	•	address : 가게 주소
//	•	latitude, longitude : 지도 표시용 좌표

//Serializable      → 객체를 직렬화/역직렬화 가능하게 함
//serialVersionUID  → 직렬화 버전 호환성 유지
//- **직렬화**: 객체를 바이트 스트림으로 변환해서 파일 저장이나 네트워크 전송에 사용할 수 있게 만드는 것.
//- **역직렬화**: 저장된 바이트 스트림을 다시 객체로 복원하는 것.


public class RestaurantVO implements Serializable {
	
    private static final long serialVersionUID = 1L;
    private Integer id;
    private Integer userId;
    private String name;
    private String menu;
    private String address;
    private Double latitude;
    private Double longitude;

    public RestaurantVO() {}

    public RestaurantVO(String name, String menu, String address, Double latitude, Double longitude) {
        this.name = name;
        this.menu = menu;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public RestaurantVO(Integer id, String name, String menu, String address, Double latitude, Double longitude) {
        this(name, menu, address, latitude, longitude);
        this.id = id;
    }

    // 게터/세터
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    
    public Integer getUserId() { return userId; } 
    public void setUserId(Integer userId) { this.userId = userId; } 
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getMenu() { return menu; }
    public void setMenu(String menu) { this.menu = menu; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }
    
    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    // equals/hashCode: id 우선, 없으면 (name+address)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RestaurantVO)) return false;
        RestaurantVO that = (RestaurantVO) o;
        if (this.id != null && that.id != null) return Objects.equals(this.id, that.id);
        return Objects.equals(name, that.name) && Objects.equals(address, that.address);
    }
    @Override
    public int hashCode() { return (id != null) ? Objects.hash(id) : Objects.hash(name, address); }
    
    //toString()은 객체를 문자열로 표현할 때 쓰이는 규칙.
    @Override
    public String toString() {
        return "RestaurantVO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", menu='" + menu + '\'' +
                ", address='" + address + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                '}';
    }
}