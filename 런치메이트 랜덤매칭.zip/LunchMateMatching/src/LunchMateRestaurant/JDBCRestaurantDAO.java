package LunchMateRestaurant;

import LunchMateConnInfo.ConnectionManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JDBCRestaurantDAO implements RestaurantDAO {

    //맛집등록 
    @Override
    public int insert(RestaurantVO vo) throws Exception {
        if (vo.getUserId() == null) {
            throw new IllegalArgumentException("RestaurantVO.userId 가 null 입니다. 저장 전에 setUserId() 하세요.");
        }

        String sql = "INSERT INTO restaurants(user_id, name, menu, address, latitude, longitude) " +
                     "VALUES (?,?,?,?,?,?)";

        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, vo.getUserId());
            ps.setString(2, vo.getName());
            ps.setString(3, vo.getMenu());
            ps.setString(4, vo.getAddress());
            ps.setDouble(5, vo.getLatitude());
            ps.setDouble(6, vo.getLongitude());

            int updated = ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) vo.setId(keys.getInt(1));
            }
            return updated;
        }
    }


    //사용자 전용 지도
    @Override
    public List<RestaurantVO> findAllByUser(int userId) throws Exception {
        String sql = "SELECT * FROM restaurants WHERE user_id=? ORDER BY id DESC";
        List<RestaurantVO> list = new ArrayList<>();
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    @Override
    public List<RestaurantVO> findNearByUser(int userId, double lat, double lng, double radiusKm) throws Exception {
        
    	// 로그인한 사용자가 등록한 식당 중에서, 현재 좌표에서 반경 N km 이내에 있는 식당들을 가까운 순서로 가져오는 SQL
    	String sql =
            "SELECT r.*, " +
            "       (6371 * ACOS( COS(RADIANS(?)) * COS(RADIANS(r.latitude)) " +
            "                      * COS(RADIANS(r.longitude) - RADIANS(?)) " +
            "                      + SIN(RADIANS(?)) * SIN(RADIANS(r.latitude)) )) AS distance " +
            "FROM restaurants r " +
            "WHERE r.user_id=? " +
            "HAVING distance <= ? " +
            "ORDER BY distance ASC";
        List<RestaurantVO> list = new ArrayList<>();
        try (Connection c = ConnectionManager.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setDouble(1, lat);
            ps.setDouble(2, lng);
            ps.setDouble(3, lat);
            ps.setInt(4, userId);
            ps.setDouble(5, radiusKm);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    //공통 매핑
    //DB 컬럼 ↔ VO/DTO 변환 작업이 반복되니까 재사용/최적화를 위해 빼놓은 것.
    
    private RestaurantVO map(ResultSet rs) throws SQLException {
        RestaurantVO vo = new RestaurantVO();
        vo.setId(rs.getInt("id"));

        int uid = rs.getInt("user_id");
        if (!rs.wasNull()) vo.setUserId(uid);

        vo.setName(rs.getString("name"));
        vo.setMenu(rs.getString("menu"));
        vo.setAddress(rs.getString("address"));
        vo.setLatitude(rs.getDouble("latitude"));
        vo.setLongitude(rs.getDouble("longitude"));
        return vo;
    }
}