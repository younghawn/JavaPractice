package LunchMateDB;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

// 	 (해시 비밀번호를 사용한 이유)
//	  데이터베이스가 유출되더라도 해시 값만 노출되어 원래 비밀번호를 알기 어렵다. 
//	  SHA-256 같은 해시 함수는 단방향 암호화라서 해시값 → 원문 복원이 불가능하다.

//  - 비밀번호 해시/검증 유틸
//  - SHA-256 해시(HEX) 생성
//  - 안전 비교(slowEquals)

public final class PasswordUtil {
    private PasswordUtil() {}

    /** 입력 비밀번호를 SHA-256 해시(64자 HEX 문자열)로 인코딩 */
    public static String sha256(String raw) {
        if (raw == null) throw new IllegalArgumentException("raw password is null");
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(raw.getBytes(StandardCharsets.UTF_8));

            // 성능을 위해 초기 용량을 정확히 잡음 (바이트 1개 → HEX 2자리)
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                // Locale 고정: OS 로케일 영향 제거
                sb.append(String.format(Locale.ROOT, "%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            // 알고리즘 이름 오타 등 예외를 런타임으로 래핑
            throw new RuntimeException("Failed to compute SHA-256 hash", e);
        }
    }

    /** 타이밍 공격 완화용 상수시간 비교 */
    public static boolean slowEquals(String a, String b) {
        if (a == null || b == null) return false;
        int diff = a.length() ^ b.length();
        int len = Math.min(a.length(), b.length());
        for (int i = 0; i < len; i++) {
            diff |= a.charAt(i) ^ b.charAt(i);
        }
        return diff == 0;
    }

    /** 64자 소문자 HEX(sha256) 여부 간단 체크 */
    public static boolean isHex256(String s) {
        if (s == null || s.length() != 64) return false;
        for (int i = 0; i < 64; i++) {
            char c = s.charAt(i);
            boolean hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
            if (!hex) return false;
        }
        return true;
    }

}