package edu.java.file07;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import edu.java.file04.MemberVO;

public class FileMain07 {
	
	// * 파일에서 데이터를 조회하는(읽어오는) 과정
	// 1. 사용할 파일을 확인
	// 2. 파일에 접근할 통로를 생성
	// 3. 파일에 저장된 데이터를 조회(읽기)
	// 4. 조회한 데이터를 활용
	// 5. 사용한 통로를 닫음
	public static void main(String[] args) {
		InputStream in = null;
		BufferedInputStream bin = null;
		ObjectInputStream oin = null;
		
		try {
			in = new FileInputStream("temp/list.txt");
			bin = new BufferedInputStream(in);
			oin = new ObjectInputStream(bin);
			
			ArrayList<MemberVO> list = (ArrayList<MemberVO>) oin.readObject();
			
			for(MemberVO vo : list) {
				System.out.println(vo);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				oin.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
