package edu.java.variable05;

public class CharacterMain {

	public static void main(String[] args) {
		System.out.println("문자(char) 자료형");
		
		char ch1 = 'A';
		System.out.println("ch1 = " + ch1);
		
		char ch2 = 67;
		System.out.println("ch2 = " + ch2);
		
		char ch3 = '1';
		System.out.println("ch3 = " + ch3);
		
		char ch4 = 1;
		System.out.println("ch4 = " + ch4);
		
		char ch5 = '\n';
		System.out.println("ch5 = " + ch5);
		System.out.println("줄바꿈");
		
		boolean b = '가' < '나';
		System.out.println("b = " + b);
		
		int a = '가';
		System.out.println(a);
		
		System.out.println("문자열(string) 자료형");
		String str = "안녕하세요";
		System.out.println("str = " + str);

	}

}
