package edu.java.variable04;

public class BooleanMain {

	public static void main(String[] args) {
		
		
		boolean b2 = false;
		System.out.println("b2 = " + b2);
		
		boolean b3 = 1<0;
		System.out.println("b3 = " + b3);

	}

}
