package edu.java.method03;

import java.util.Scanner;

public class MethodMain03 {
	
	public static void main(String[] args) {
		// 1. 국어, 영어, 수학 점수를 정수로 입력받아서 3개의 변수에 저장
		Scanner sc = new Scanner(System.in);

		System.out.print("국어점수 : ");
		int kor = sc.nextInt();
		
		System.out.print("영어점수 : ");
		int eng = sc.nextInt();
		
		System.out.print("수학점수 : ");
		int math = sc.nextInt();
		
		// 2. 메소드를 정의하여 세 과목의 총점을 출력
		int sum = calcTotal(kor, eng, math);
		System.out.println("총점 : " + sum);
		
		// 3. 메소드를 정의하여 세 과목의 평균을 출력(소수점까지)
		double avg = calcAverage(sum);
		System.out.println("평균 : " + avg);
		// 4. 메소드를 정의하여 평균에 따른 등급을 출력
		char grade = selectGrade(avg);
		System.out.println("등급 : " + grade);
	}
	
	// 메소드 이름 : calcTotal
	// 기능 : 전달받은 3개의 정수로 총점을 리턴하는 메소드
	private static int calcTotal(int x, int y, int z) {
		return x + y + z;
	}
	// 메소드 이름 : calcAverage
	// 기능 : 전달받은 총점으로 평균을 리턴하는 메소드
	private static double calcAverage(double total) {
		return total/3;
	}
	// 메소드 이름 : selectGrade
	// 기능 : 평균 점수에 따른 등급(char)을 리턴하는 메소드
	// 100 ~ 90 -> 'A'
	// 89 ~ 80 -> 'B'
	// 79 ~ 70 -> 'C'
	// 70 미만 -> 'F'
	private static char selectGrade(double avg) {
		char result = 0;
		if(avg > 90 && avg <= 100) {
			result = 'A';
		} else if(avg > 80 && avg <=89) {
			result = 'B';
		} else if(avg > 70 && avg <= 79) {
			result = 'C';
		} else
			result = 'F';
		return result;
	}

}
