package edu.java.homework;

public class MemberService {
	String id = "test";
	String pw = "1234";
	
	public boolean login(String id, String pw) {
		// id, pw 는 주소값이 전송됨
		// id == "test" : 주소값 비교
		// id.equals("test") : 실제 데이터 비교
		if(id.equals(this.id) && pw.equals(this.pw)) {
			return true;
		}else{
			return false;
		}
	}
	
	public void logout(String id) {
		System.out.println(id + "님이 로그아웃 되었습니다.");
	}
}
