package edu.java.access05;

public class TestPublic {

}

