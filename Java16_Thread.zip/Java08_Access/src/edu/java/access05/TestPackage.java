package edu.java.access05;

// 같은 package 내에서만 인스턴스 생성 가능
class TestPackage {

}
