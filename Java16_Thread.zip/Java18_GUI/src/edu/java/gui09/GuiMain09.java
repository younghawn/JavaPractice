package edu.java.gui09;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JCheckBox;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class GuiMain09 {

	private JFrame frame;
	private JTextArea textArea; // 아래에서 선언하면 그 위에 있는 곳에서 호출할 수 없음

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GuiMain09 window = new GuiMain09();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GuiMain09() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JCheckBox chckbxMusic = new JCheckBox("음악");
		chckbxMusic.setBounds(6, 6, 107, 23);
		frame.getContentPane().add(chckbxMusic);
		
		JCheckBox chckbxMovie = new JCheckBox("영화");
		chckbxMovie.setBounds(115, 6, 107, 23);
		frame.getContentPane().add(chckbxMovie);
		
		JCheckBox chckbxReading = new JCheckBox("독서");
		chckbxReading.setEnabled(false); // 비활성화
		chckbxReading.setBounds(224, 6, 107, 23);
		frame.getContentPane().add(chckbxReading);
		
		JButton btnOutput = new JButton("출력");
		btnOutput.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String result = "음악 : " + chckbxMusic.isSelected()
				+ "영화 : " + chckbxMovie.isSelected()
				+ "독서 : " + chckbxReading.isSelected();
				textArea.setText(result);
			}
		});
		btnOutput.setBounds(337, 6, 93, 23);
		frame.getContentPane().add(btnOutput);
		
		textArea = new JTextArea();
		textArea.setBounds(6, 47, 422, 208);
		frame.getContentPane().add(textArea);
	}
}
