package edu.java.gui08;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GuiMain08 {

	private JFrame frame;
	private static final ImageIcon[] IMAGE_ICONS = {
			new ImageIcon("res/dog1.jpg"), 
			new ImageIcon("res/dog2.jpg"),
			new ImageIcon("res/dog3.jpg"),
			new ImageIcon("res/dog4.jpg")
	};
	private int index;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GuiMain08 window = new GuiMain08();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GuiMain08() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblOutput = new JLabel();
		lblOutput.setIcon(IMAGE_ICONS[index]);
		lblOutput.setBounds(115, 20, 230, 230);
		frame.getContentPane().add(lblOutput);

		JButton btnPrev = new JButton("이전");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (index > 0) {
					index--;
				} else {
					index = IMAGE_ICONS.length - 1;
				}
				lblOutput.setIcon(IMAGE_ICONS[index]);
			}
		});
		btnPrev.setBounds(50, 255, 140, 140);
		btnPrev.setFont(new Font("굴림", Font.BOLD, 42));
		frame.getContentPane().add(btnPrev);

		JButton btnNext = new JButton("다음");
		btnNext.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(index < IMAGE_ICONS.length - 1) {
					index++;
				} else {
					index = 0;
				}
				lblOutput.setIcon(IMAGE_ICONS[index]);
			}
		});
		
		btnNext.setFont(new Font("굴림", Font.BOLD, 42));
		btnNext.setBounds(260, 255, 140, 140);
		frame.getContentPane().add(btnNext);

	}
}
