package edu.java.gui12;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class MyFrame extends JFrame {

	private JPanel contentPane;

	public MyFrame(String text) {
		
		// JFrame.EXIT_ON_CLOSE : 프로그램 전체 종료
		// JFrame.DISPOSE_ON_CLOSE : 현재 창만 종료
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel(); // frame.getContentPane()과 같은 의미
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JButton btntemp = new JButton(text);
		btntemp.setBounds(136, 97, 153, 71);
		contentPane.add(btntemp);
	      
	}

}
