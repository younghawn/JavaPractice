package edu.java.gui02;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.SwingConstants;

public class GuiMain02 {

	private JFrame frame;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GuiMain02 window = new GuiMain02();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GuiMain02() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblOutput = new JLabel("오늘은 금요일!");
		lblOutput.setHorizontalAlignment(SwingConstants.CENTER);
		lblOutput.setForeground(Color.BLUE);
		lblOutput.setFont(new Font("맑은 고딕", Font.BOLD, 18));
		lblOutput.setBounds(12, 10, 410, 43);
		frame.getContentPane().add(lblOutput);

		JTextField txtInput = new JTextField();
		txtInput.setFont(new Font("맑은 고딕", Font.PLAIN, 24));
		txtInput.setBounds(12, 64, 410, 58);
		txtInput.setColumns(10);
		frame.getContentPane().add(txtInput);

		JButton btnInput = new JButton("입력");
		
		btnInput.addMouseListener(new MouseAdapter() {
			
			// 이벤트 : 마우스로 버튼을 클릭했을 때
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("마우스 클릭됨");
				// 버튼을 틀릭했을 때 해야할 기능 작성
				// JTextFiled에 입력된 내용을 읽어서 JLabel에 쓰기
				String msg = txtInput.getText();
				lblOutput.setText(msg);
			}
		});

		btnInput.setFont(new Font("굴림", Font.PLAIN, 18));
		btnInput.setBounds(12, 145, 410, 81);
		frame.getContentPane().add(btnInput);
		
		System.out.println("initialize 메소드 호출 끝");
	}
}
