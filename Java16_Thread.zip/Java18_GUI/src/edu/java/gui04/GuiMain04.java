package edu.java.gui04;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class GuiMain04 {

	private JFrame frame;
	private JTextField txtNumber1;
	private JTextField txtNumber2;
	private JButton btnPlus;
	private JButton btnMinus;
	private JButton btnMultiple;
	private JButton btnDivide;
	private JTextArea textArea;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GuiMain04 window = new GuiMain04();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GuiMain04() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 600, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null); // Absolute layout

		int lblWidth = 245; // 레이블 넓이
		int lblHeight = 76; // 레이블 높이
		Font lblFont = new Font("굴림", Font.ITALIC, 48);

		JLabel lblNumber1 = new JLabel("Number 1");
		lblNumber1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNumber1.setBounds(12, 10, lblWidth, lblHeight);
		lblNumber1.setFont(lblFont);
		frame.getContentPane().add(lblNumber1);

		JLabel lblNumber2 = new JLabel("Number 2");
		lblNumber2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNumber2.setFont(lblFont);
		lblNumber2.setBounds(12, 96, lblWidth, lblHeight);
		frame.getContentPane().add(lblNumber2);

		int txtWidth = 203;
		int txtHeight = 76;
		Font txtFont = new Font("굴림", Font.ITALIC, 25);

		txtNumber1 = new JTextField();
		txtNumber1.setBounds(269, 10, txtWidth, txtHeight);
		txtNumber1.setFont(txtFont);
		frame.getContentPane().add(txtNumber1);
		txtNumber1.setColumns(10);

		txtNumber2 = new JTextField();
		txtNumber2.setFont(txtFont);
		txtNumber2.setColumns(10);
		txtNumber2.setBounds(269, 96, txtWidth, txtHeight);
		frame.getContentPane().add(txtNumber2);

		btnPlus = new JButton("+");
		btnPlus.setFont(txtFont);
		btnPlus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Float number1 = Float.parseFloat(txtNumber1.getText());
					Float number2 = Float.parseFloat(txtNumber2.getText());
					if (txtNumber1.getText().length() == 0 || txtNumber2.getText().length() == 0) {
						return;
					} else {
						Float sum = number1 + number2;
						String msg = number1 + " + " + number2 + " = " + sum + "\n";
						textArea.append(msg);
					}
				} catch (Exception e1) {
					return;

				}
			}
		});

		btnMinus = new JButton("-");
		btnMinus.setFont(txtFont);
		btnMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Float number1 = Float.parseFloat(txtNumber1.getText());
					Float number2 = Float.parseFloat(txtNumber2.getText());
					Float sum = number1 - number2;
					String msg = number1 + " - " + number2 + " = " + sum + "\n";

					textArea.append(msg);
				} catch (Exception e1) {
					return;
				}
			}
		});

		btnMultiple = new JButton("*");
		btnMultiple.setFont(txtFont);
		btnMultiple.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				try {
					Float number1 = Float.parseFloat(txtNumber1.getText());
					Float number2 = Float.parseFloat(txtNumber2.getText());
					Float sum = number1 * number2;
					String msg = number1 + " * " + number2 + " = " + sum + "\n";
					textArea.append(msg);
				} catch (Exception e1) {
					return;
				}
			}
		});

		btnDivide = new JButton("/");
		btnDivide.setFont(txtFont);
		btnDivide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Float number1 = Float.parseFloat(txtNumber1.getText());
					Float number2 = Float.parseFloat(txtNumber2.getText());
					Float sum = number1 / number2;
					String msg = number1 + " / " + number2 + " = " + sum + "\n";
					textArea.append(msg);
				} catch (Exception e1) {
					return;
				}
			}
		});

		btnPlus.setBounds(50, 200, 80, 80);
		frame.getContentPane().add(btnPlus);
		btnMinus.setBounds(180, 200, 80, 80);
		frame.getContentPane().add(btnMinus);
		btnMultiple.setBounds(310, 200, 80, 80);
		frame.getContentPane().add(btnMultiple);
		btnDivide.setBounds(440, 200, 80, 80);
		frame.getContentPane().add(btnDivide);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 300, 550, 130);
		frame.getContentPane().add(scrollPane);

		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);

	}

}
