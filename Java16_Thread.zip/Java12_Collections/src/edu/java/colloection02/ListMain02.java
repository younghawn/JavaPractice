package edu.java.colloection02;

import java.util.ArrayList;

public class ListMain02 {

	public static void main(String[] args) {
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		list1.add(100);
		
		ArrayList<String> list2 = new ArrayList<String>();
		list2.add("test");
		
		// Generic<>은 선언된 차입에 따라 연결되는 메소드나 멤버 변수 타입이
		// 변경되는 형태이다.
		
	}

}
