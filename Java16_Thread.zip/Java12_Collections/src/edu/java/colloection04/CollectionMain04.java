package edu.java.colloection04;

import java.util.ArrayList;
import java.util.Scanner;

public class CollectionMain04 {

	public static void main(String[] args) {
		// 1. Score 클래스 생성
		// - 멤버 변수(int math, int eng)
		// - 생성자, getter/setter, toString() 생성

		// 2. Student 클래스 생성
		// - 멤버 변수(String name, Score score)
		// - 생성자, getter/setter, toString(() 생성
		Scanner sc = new Scanner(System.in);

		// 3. ArrayList를 생성하여 학생 정보 3개를 입력받아 list애 저장
		ArrayList<Student> list = new ArrayList<Student>();

		for (int i = 0; i < 3; i++) {
			System.out.println("이름 입력> ");
			String name = sc.next();
			System.out.println("수학 점수 입력> ");
			int math = sc.nextInt();
			System.out.println("영어 점수 입력> ");
			int eng = sc.nextInt();
			System.out.println();
			
			Score score = new Score(math, eng);
			Student student = new Student(name, score);
			list.add(student);			 
		}
		// 4. 전체 학생 정보 검색(출력)
		for (int i = 0; i <list.size(); i++) {
			System.out.println("--- 학생[" + i + "] 정보 ---");
			Student student = list.get(i);
			System.out.println(student);
			System.out.println("이름 : " + student.getName());
			System.out.println("수학 : " + student.getScore().getMath());
			System.out.println("영어 : " + student.getScore().getEng());
		}
		
		// 5. list에 저장된 index 1번 학생의 데이터 수정
		// ex) 이름 : ~, 수학 : 100, 영어 : 50
		list.set(1, new Student("test", new Score(100, 50)));
		
		// 0번 인덱스 학생의 영어 점수만 변경
		list.get(0).getScore().setEng(50);
		
		// 6. 데이터 삭제 : 1번 학생의 데이터 삭제
		list.remove(1);
		
		// 7. 변경된 데이터 확인
		for(Student student : list) {
			System.out.println("이름 : " + student.getName());
		}
	}

}
