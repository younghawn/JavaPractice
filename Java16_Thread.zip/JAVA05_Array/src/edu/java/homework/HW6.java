package edu.java.homework;

import java.util.Scanner;

public class HW6 {

	public static void main(String[] args) {
		// 숫자 맞추기 게임
		Scanner sc = new Scanner(System.in);
		int target = (int) (Math.random() * 100 + 1);
		int match = 0;
		boolean check = true;
		System.out.println("숫자 맞추기 게임(1~100)");
		System.out.println("-------------------");

		while (check) {
			System.out.print("숫자를 입력하세요 (1~100) : ");
			match = sc.nextInt();
			if(match == target) {
				System.out.println("정답입니다!");
				break;
			}
			else if(match > target) {
				System.out.println("너무 큽니다.");
			}
			else
				System.out.println("너무 작습니다.");
			
		}
	}

}
