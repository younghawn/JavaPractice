package edu.java.homework;

public class HW4 {

	public static void main(String[] args) {
		// 별 피라미드 출력 프로그램

		for(int i=0; i < 6; i++) {
			for(int j = 0; j < i; j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		for(int i=0; i < 6; i++) {
			System.out.print(" ");
			for(int j = 5; j > i; j--) {
				System.out.print("*");
			}
			System.out.println("");
		}
	}

}
