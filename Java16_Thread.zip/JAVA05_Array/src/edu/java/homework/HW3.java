package edu.java.homework;

public class HW3 {

	public static void main(String[] args) {
		// 1 + (-2) + 3 + (-4) + 5 + ... + n의 합이 100 이상일 때 n과 합 출력
		int n = 0, sum=0;
		for(int i = 1; sum < 100; i++) {
			n=i;
			if(i%2==0) 
				sum += n;
			else
				sum -=n;
		}
		System.out.println("n = " + (n-1));
		System.out.println("sum = " + sum);
	}
}
