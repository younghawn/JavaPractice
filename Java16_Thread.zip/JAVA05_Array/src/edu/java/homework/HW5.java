package edu.java.homework;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class HW5 {

	public static void main(String[] args) {
		// 구구단 출력 프로그램

		Scanner sc = new Scanner(System.in);
		boolean run = true;
		while (run) {
			System.out.print("원하시는 숫자(2~9)를 입력해주세요 : ");
			int selectNo = sc.nextInt();
			switch (selectNo) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
				for (int i = 1; i <= 9; i++) {
					System.out.println(selectNo + " * " + i + " = " + selectNo * i);
				}
				break;
			case 0:
				run = false;
				System.out.println("프로그램 종료");
				break;
			default:
				System.out.println("잘못된 값을 입력하셨습니다.");
				break;
			}
		}
	}

}
