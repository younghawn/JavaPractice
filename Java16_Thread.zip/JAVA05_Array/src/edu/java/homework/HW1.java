package edu.java.homework;

public class HW1 {

	public static void main(String[] args) {
		// 반복문을 사용해서 'A'부터 'Z'까지 출력하는 프로그램
		char alphabet = 'A';
		System.out.println("A 부터 Z까지 출력");
		for(int i=0; i<26; i++) {
			System.out.println(alphabet);
			alphabet++;
		}
	}

}
