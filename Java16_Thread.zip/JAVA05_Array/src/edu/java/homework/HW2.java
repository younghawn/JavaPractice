package edu.java.homework;

public class HW2 {

	public static void main(String[] args) {
		// 두 개의 주사위를 던져 합이 5가 나올 때까지 반복하는 프로그램
		int dice1, dice2 = 0;
		while(true) {
			dice1 = (int)(Math.random()*6 + 1);
			dice2 = (int)(Math.random()*6 + 1);
			if(dice1+dice2 == 5) {
				System.out.println("주사위1 : " + dice1);
				System.out.println("주사위2 : " + dice2);
				System.out.println("주사위 합 : " + (dice1+dice2));
				break;
			}
			System.out.println("주사위1 : " + dice1);
			System.out.println("주사위2 : " + dice2);
			System.out.println("주사위 합 : " + (dice1+dice2));
		}
	}

}
