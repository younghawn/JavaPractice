package edu.java.contact06;

public interface MySQLConnInfo {
	public static final String URL = "jdbc:mysql://localhost:3306/example";
	public static final String USER = "root";
	public static final String PASSWORD = "choi0907";
}
