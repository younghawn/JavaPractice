package edu.java.contact02;

// VO(Value Object) : MVC 디자인 패턴에서 Model 클래스. 데이터 정보
// DTO(Data Transfer Object)라고도 불림.
public class ContactVO {
	// 멤버 변수(필드, 프로퍼티)
	private String id;
	private String phone; 
	private String email; 
	
	public ContactVO() {}
	
	public ContactVO(String id, String phone, String email) {
		super();
		this.id = id;
		this.phone = phone;
		this.email = email;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPhone() {
		return phone;
	}
	public void setphone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "ContactVO [id=" + id + ", phone=" + phone + ", email=" + email + "]";
	}
	
	
}
