package edu.java.contact02;

public interface Menu {
	int QUIT = 0;
	int INSERT = 1;
	int SELECT_ALL = 2;
	int SELECT_BY_INDEX = 3;
	int UPDATE = 4;
}
