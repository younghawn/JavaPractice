package edu.java.Inherit03;

public class InheritMain03 {

	public static void main(String[] args) {
		SmartPhone phone = new SmartPhone("010-1111-1111");
		
	} // end main()

} // end InheritMain03
