package edu.java.Inherit06;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class HybridCar extends Car{
	// 멤버 변수
	private int battery;

	public HybridCar() {}

	public HybridCar(int battery) {
		super();
		this.battery = battery;
	}

	public int getBattery() {
		return battery;
	}

	public void setBattery(int battery) {
		this.battery = battery;
	}

	@Override
	public String toString() {
		return "HybridCar [battery=" + battery + "]";
	}
	
	@Override
	public void display() {
		System.out.println("하이브리드 자동차 연료 : " + getFuel());
		System.out.println("하이브리드 자동차 배터리 : " + battery);
	}
	
	
}
