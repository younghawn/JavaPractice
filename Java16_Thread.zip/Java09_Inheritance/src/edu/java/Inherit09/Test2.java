package edu.java.Inherit09;

public class Test2 extends Test1{
	@Override
	public void display() {
//		System.out.println("a = " + a); // private 으로 선언되어있어 가져오기 불가능
		System.out.println("b = " + b);
		System.out.println("c = " + c);
		System.out.println("d = " + d);
	}
}
