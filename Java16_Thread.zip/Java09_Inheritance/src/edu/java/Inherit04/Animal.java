package edu.java.Inherit04;

public class Animal {
	
	public Animal() {}
	
	public void speak() {
		System.out.println("동물이 말을 합니다.");
	}
}
