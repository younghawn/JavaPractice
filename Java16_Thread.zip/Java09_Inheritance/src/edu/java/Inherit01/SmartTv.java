package edu.java.Inherit01;

public class SmartTv extends BasicTv{
	// 멤버 변수
	private String ip;
	
	// 생성자
	public SmartTv() {}
	
	public String getIP() {
		return ip;
	}
	
	public void setIp(String ip) {
		this.ip = ip;
	}
	
}
