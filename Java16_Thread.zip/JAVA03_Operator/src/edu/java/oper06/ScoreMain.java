package edu.java.oper06;

import java.util.Scanner;

public class ScoreMain {

	public static void main(String[] args) {
		
		System.out.println("총점 및 평균 계싼 프로그램");
		// 1. 입력받을 준비 : Scanner 변수 생성
		Scanner sc = new Scanner(System.in);
		System.out.println("점수를 입력하세요.");
		
		// 2. 국어, 영어, 수학 점수를 정수로 입력받아서 3개의 변수에 각기 저장
		int kor_sc, eng_sc, math_sc = 0;
		
		System.out.print("국어 점수 : ");
		kor_sc = sc.nextInt();
		System.out.print("영어 점수 : ");
		eng_sc = sc.nextInt();
		System.out.print("수학 점수 : ");
		math_sc = sc.nextInt();
		
		// 3. 국어, 영어, 수학 점수를 출력
		System.out.println("국어 점수 : " + kor_sc + 
				"\n" + "영어 점수 : " + eng_sc + 
				"\n" + "수학 점수 : " + math_sc);
		
		// 4. 총점을 계산하여 출력
		int sum = kor_sc + eng_sc + math_sc;
		System.out.println("총점 = " + sum);
		
		// 5. 평균을 계산하여 출력(소수점 셋째 자리까지)
		double avg = sum / 3.0;
		System.out.printf("평균 = %.3f", avg);
		
	}

}
