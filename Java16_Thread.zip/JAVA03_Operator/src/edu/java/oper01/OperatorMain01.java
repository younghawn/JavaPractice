package edu.java.oper01;

public class OperatorMain01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
