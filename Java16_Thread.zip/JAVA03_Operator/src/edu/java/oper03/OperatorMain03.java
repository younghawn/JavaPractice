package edu.java.oper03;

// 증감 연사자
// - 변수의 값을 1 증가 또는 감소할 때 사용하는 연산자
// - 변수의 아ㅠ(prefix)과 뒤(suffix)에 사용
// - ++, --

public class OperatorMain03 {

	public static void main(String[] args) {
		System.out.println("증감 연산자(++, --)");
		
		int num1 = 100;
		num1++;
		// num1 += 1;
		// num1 = num1 + 1;
		System.out.println("num1 = " + num1);
		
		int num2 = 100;
		++num2;
		System.out.println("num2 = " + num2);
		
		System.out.println(num1++);
		System.out.println(++num1);
		
		
		int x = 10;
		int result = x++ + 5 + ++x;
		// 1) x + 5 => 15
		// 2) x++ => x=11
		// 3) ++x => x=12
		// 4) 15+x => 27
		
	}

}
